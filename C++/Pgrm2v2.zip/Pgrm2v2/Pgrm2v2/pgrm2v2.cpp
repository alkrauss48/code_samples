//Aaron Krauss
//Honors CSE 2341

#include <iostream>
using namespace std;

void sequence(int* , int );
bool checkDivisor(int*, int, int);

int main()
{
	int num = 0;
	cout << "Please enter the amount of digits in the EKG sequence that you would like to generate: " << endl;
	cin >> num;
	int* numbers = new int[num]; //pointer to an integer array
	numbers[0] = 1;				 //manually entered the first 2 digits
	numbers[1] = 2;
	sequence(numbers, num);      //calls the most important method

	cout << "First " << num << " numbers of the EKG sequence:" << endl; //prints out EKG sequence
	for(int x = 0; x < num; x++)
		cout << numbers[x] << " ";
	cout << endl;

	delete [] numbers;			  //saves the program from a memory leak

	return 0;

}

void sequence(int* numbers, int num)
{
	int x = 2; //starts x off at two because 1 is a factor of every number
	bool answerFound = false; //var representing whether or not an answer has been found for one value of i
	bool xNotSeenYet = true;  //determines if the check number is already in the sequence
	bool checkDiv = false;    //returns true if it shares a common factor with the last entry
	for(int i = 2; i < num; i++) //loop for all of the ekg sequence 
	{
		x = 2;					 //starting the loop over at 2 to check for common factors
		xNotSeenYet = true;
		answerFound = false;
		checkDiv = false;

		while(answerFound != true) //loops until a value for i has been found
		{
			xNotSeenYet = true;
			for(int a = 0; a < num; a++)
			{
				if(x == numbers[a])
					xNotSeenYet = false; //will make the entire loop start over with x++. x can not already be in the sequence
			}
			if(xNotSeenYet == true)
			{
				checkDiv = checkDivisor(numbers, i-1, x); // return true if there is a common factor between i-1 and x
				if(checkDiv == true)					  // if there is a common factor between the last and new number
				{
					numbers[i] = x;
					answerFound = true; //this will end the loop once it finishes
				}
				else
					x++; 
			}
			else
			{
				x++;
			}
		}
	}
}


bool checkDivisor(int* numbers, int arrIndex, int value) //checks to see if value and numbers[arrIndex] share a common factor
{
	int tempLarge = 0;
	int tempSmall = 0;

	if(numbers[arrIndex] > value) //this entire if statement determines which value is larger out of the two, and assigns them to variables
	{
		tempLarge = numbers[arrIndex];
		tempSmall = value;
	}
	else
	{
		tempLarge = value;
		tempSmall = numbers[arrIndex];
	}

	for(int x = 2; x <= tempSmall; x++){ //checks to see if they are both divisble by a common factor.
		if((tempSmall % x == 0) && (tempLarge % x == 0))
			return true;				// returns true if they share a common factor
	}
	return false;						//if not, it returns false
}