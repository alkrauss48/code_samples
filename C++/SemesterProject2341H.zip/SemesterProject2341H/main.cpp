//Harrison, Paul, Aarron



#include <iostream>
#include "corpus.h"
#include "invertedFileIndex.h"
#include <fstream>

using namespace std;

int main () {
	cout << "Enter Search: ";
	string words;
	getline(cin, words);
	
	string directoryName;
	cout<< "\n\ndirectory: ?" <<endl;
	cin>> directoryName;
	cout<<endl;
	
	string selection;
	cout<<"Press one to create a new IFI,\npress any other key to continue\nusing current IFI: "<<endl;
	cin>>selection;
	if(selection=="1"){
	
	corpus corp = corpus(directoryName);
	corp.createIndex();
	//corp.printIndex();
	corp.writeIFI();
	cout<<endl;
		invertedFileIndex * newIndex;
		newIndex = corp.getP_IFI();
		newIndex->search(words);
		newIndex->viewReturns();
		
	
	}else{
	invertedFileIndex newIndex;
	newIndex.readIFI();
//	newIndex.printIFI();
		
	newIndex.search(words);
	newIndex.viewReturns();
	}
	
	string returnName;
	cout<<"Enter the name of the return file you would like to view:"<<endl;
	cin>>returnName;
	returnName= directoryName+"/"+returnName;
	fstream inputFile(returnName.c_str(), ios::in);
	
	string temp;
	if (!inputFile.is_open()) 
	{
		cout << "Error: cannot open file. Goodbye. " << endl;
        exit(1);
    }
	while(!inputFile.eof()){
		inputFile >> temp;
		cout << temp<<" ";
	}
	inputFile.close();
	
	

	
	//NEED TO VIEW RETURNS BY WEIGHT INSTEAD OF ALPHA
	//NEED TO BE ABLE TO PRINT SELECTED RETURN FILE BY NUMBER INPUT

	

}
