/*
 *  words.h
 *  SemesterProject2341H
 *
 *  Created by Harrison Jackson on 12/4/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */
#include <string>
using namespace std;
#ifndef WORDS_H
#define WORDS_H

class words{
private:
	string word;
	int frequency;
	
public:
	words(string);
	string getWord();
	void setWord(string);
	int getFreq();
	void operator++();
	void setFreq(int);
	
	
	
};

#endif