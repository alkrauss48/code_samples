/*
 *  indexWords.h
 *  SemesterProject2341H
 *
 *  Created by Harrison Jackson on 12/4/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include <string>
#include "documents.h"
#include <map>
#include <iostream>
using namespace std;

#ifndef INDEXWORDS_H
#define INDEXWORDS_H

class indexWords{
private:
	string wordObject;
	map <string, float> docNames;
	map <string, float> docTotalWords;
	map <string, float> weightedWords;
	
public:
	indexWords(){};
	indexWords(string);
//	indexWords(string wordT, int freq, string doc){
//		wordObject = wordT;
//		addDoc(freq,doc);
//	}
	void addDoc(float,string, float);
	void addDoc(string,string);
	int getSize();
	void constructWeight();
	string getWord();
	map<string, float> getMap();	
	void setMapsEqual();
	
	friend ostream &operator<<(ostream&, indexWords&);
	friend istream &operator>>(istream&, indexWords&);
	
	void printWeightedWords();
	string returnWeightedWords();



	
	
};

#endif