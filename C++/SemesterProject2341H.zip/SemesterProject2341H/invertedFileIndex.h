/*
 *  invertedFileIndex.h
 *  SemesterProject2341H
 *
 *  Created by Harrison Jackson on 12/4/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */
#include <map>
#include "indexWords.h"
#include <string>
#include "returnFiles.h"

using namespace std;


#ifndef INVERTEDFILEINDEX_H
#define INVERTEDFILEINDEX_H

class invertedFileIndex{
private:
	map <string, indexWords>iWords;
	returnFiles returnFs;
	vector<string>userInputWords;
	vector<string>notWords;
	vector<string>searchFor;
	
public:
	invertedFileIndex(){};
	void addWords(documents);
	void printIFI();
	void writeIFI(string);
	void readIFI();
	void search(string);
	void viewReturns();
	void printIFIWeighted();
	void writeIFIWeighted(string);
	
	
};

#endif