/*
 *  invertedFileIndex.cpp
 *  SemesterProject2341H
 *
 *  Created by Harrison Jackson on 12/4/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */
#include <map>
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

#include "invertedFileIndex.h"
void invertedFileIndex:: addWords(documents doc){
	string name = doc.getFile();	
	for (int i = 0; i < doc.getSize(); i++)
	{
		iWords[doc.getWord(i)].addDoc(doc.getFreq(i), name,doc.getTotal());
	}

}

void invertedFileIndex::printIFI(){
	map<string, indexWords>::iterator it;
	for(it = iWords.begin(); it!=iWords.end(); it++){
		cout << (*it).second<< endl;
	}

}

void invertedFileIndex::writeIFI(string file){
	iWords.erase("");
	ofstream fout (file.c_str(), ios::out);	
	if(!fout){
		cout<< "error opening file..."<< endl;
	}
	map<string, indexWords>::iterator it;
	for(it = iWords.begin(); it!=iWords.end(); it++){
		fout<< (*it).first<< (*it).second<<endl;
	}
	
}

//************************************************ PROBLEM WITH THE indexWords(string) constructor
void invertedFileIndex:: readIFI(){
	ifstream inputFile;
	inputFile.open("invertedFileIndex.txt");
	if(!inputFile.is_open())
	{
		cout << "File failed to open" << endl;
		
	}

	while(!inputFile.eof())
	{	
		string input;
		getline(inputFile, input);
		//cout<<"INPUT: ";
		//cout<< input<<endl;
		
		
		indexWords temp(input);
		
		iWords.insert( make_pair(temp.getWord(), temp));
		
	}
		
}


void invertedFileIndex:: search(string searchWords){
	
	//seperates words into seperate strings
	for(int i=0; i<searchWords.size(); i++){
		string temp;
		while(searchWords[i]!=' '&&i<searchWords.size()){
			temp+=searchWords[i];
			i++;
		}
		userInputWords.push_back(temp);
	}
	//seperates words into NOTwords and SearchForWords
	for(int j=0; j<userInputWords.size(); j++){
		if(userInputWords[j]=="not"&&(j<(userInputWords.size()-1))){
			notWords.push_back(userInputWords[j+1]);
			j++;
		   }else{
			searchFor.push_back(userInputWords[j]);
		   }
	}
	//passes indexWords to returnFiles to add more files
	for(int x=0; x<searchFor.size(); x++){
		returnFs.addFile(iWords[searchFor[x]]);
	}
	
	//passes indexWords to returnFiles to remove files
	for(int y=0; y<notWords.size(); y++){
		returnFs.deleteFile(iWords[notWords[y]]);						
	}
		
	
}

void invertedFileIndex:: viewReturns(){
	returnFs.printSort();
	
}



void invertedFileIndex::printIFIWeighted(){
	map<string, indexWords>::iterator it;
	for(it = iWords.begin(); it!=iWords.end(); it++){
		cout<<(*it).first<<" ";
		(*it).second.printWeightedWords();
	}
}

void invertedFileIndex::writeIFIWeighted(string file){
	iWords.erase("");
	ofstream fout (file.c_str(), ios::out);	
	if(!fout){
		cout<< "error opening file..."<< endl;
	}
	
	map<string, indexWords>::iterator it;
	for(it = iWords.begin(); it!=iWords.end(); it++){
		fout<<(*it).first<<" ";
		fout<<(*it).second.returnWeightedWords();

	}
}
	



