
#include "corpus.h"
#include <fstream>

void corpus::createIndex(){
	vector<documents>::iterator it;
	double i=0;
	for(it = doc.begin(); it< doc.end(); it++){
		//uncomment below to view percentage
		//i++;
		//double percent = i/38621*100;
		//cout<< percent << "%"<< endl;
		(*it).openDoc();
		(*it).parse(stopObject);
		
		//totalWords[it] += it.getSize();
		index.addWords(*it);
		
	}
	
	
	
}

void corpus::writeIFI(){
	index.writeIFIWeighted("invertedFileIndex.txt");

}

void corpus::printIndex(){
	index.printIFI();
}

invertedFileIndex* corpus::getP_IFI(){
	return &index;
}

