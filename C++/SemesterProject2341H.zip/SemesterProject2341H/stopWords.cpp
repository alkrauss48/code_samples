/*
 *  stopWords.cpp
 *  SemesterProject2341H
 *
 *  Created by Harrison Jackson on 12/4/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include "stopWords.h"
#include "words.h"
#include <iostream>
#include <fstream>
using namespace std;

bool stopWords::checkStopWords(char* word)
{
	for(int i = 0; i < wordCount; i++)
	{
		for (int x =0; x < strlen(stop[i]); x++) //converts to upper case - stopwords is a bad pointer
			stop[i][x] = tolower(stop[i][x]);
		
		if(strcmp(word, stop[i])==0)
			return true;
	}
	return false;
}

void stopWords::openWords()
{
	fstream stops;
	int stopIndex = 0;
	stops.open("stopWords.txt", ios::in); //open up stream to read in all 659 stop words
	if (!stops.is_open()) 
	{
		cout << "Error: cannot open stop words file. Goodbye. " << endl;
        exit(1);
    }
	while(!stops.eof())
	{
		char temp[20];
		stops >> temp;
		stop[stopIndex] = new char[strlen(temp) + 1]; //sets each string index of the array to the proper length
		strcpy(stop[stopIndex], temp);
		stopIndex++;
	}
	stops.close();
	
}
