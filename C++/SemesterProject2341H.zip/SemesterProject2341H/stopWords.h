/*
 *  stopWords.h
 *  SemesterProject2341H
 *
 *  Created by Harrison Jackson on 12/4/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef STOPWORDS_H
#define STOPWORDS_H

class stopWords{
private:
	char** stop;
	int wordCount;
public:
	stopWords(){};
	stopWords(int num)
	{
		wordCount = num;
		stop = new char*[wordCount];
		for(int i = 0; i < wordCount; i++)
			stop[i] = new char[20];
	}
	
	bool checkStopWords(char* );
	void openWords();
};

#endif