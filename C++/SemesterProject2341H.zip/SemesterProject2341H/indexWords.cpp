/*
 *  indexWords.cpp
 *  SemesterProject2341H
 *
 *  Created by Harrison Jackson on 12/4/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include <string>
#include <vector>
#include "documents.h"
#include <map>
#include <iostream>

using namespace std;


#include "indexWords.h"

//constructor to read IFI from file
indexWords::indexWords(string input){
	vector<string> inWords;
	int i=0;
	bool add=false;
	while(input[i]!='\0'){
		add=true;
		bool increase=false;
		string temp;
		while(input[i]!=' '){
			temp+=input[i];
			i++;
			increase=true;
		}
		if(increase){
			inWords.push_back(temp);
		}
		i++;
	}
	if(add){
	wordObject=inWords[0];
		//cout<<"WORDOBJECT   "<<wordObject<<endl;
	for(int i =1;i<inWords.size();i+=2){
		//cout<<"IIINNNNNNN"<<endl;
		addDoc(inWords[i+1],inWords[i]);
		}
	}
	constructWeight();
	setMapsEqual();
}
			

void indexWords:: addDoc(float freq, string docLoc, float totalWords){
	docNames[docLoc]+=freq;
	docTotalWords[docLoc]=totalWords;
	constructWeight();


}
void indexWords:: addDoc(string freq, string docLoc){
	docNames[docLoc]+= atof(freq.c_str()); 
	constructWeight();

}

int indexWords::getSize(){
	return docNames.size();
}

map<string, float> indexWords::getMap(){
	return weightedWords;
	
}

string indexWords::getWord(){
	return wordObject;
}


ostream &operator<<(ostream &out, indexWords &right){
	out<< right.wordObject<< " ";
	map<string, float>::iterator it;
	for(it=right.weightedWords.begin(); it!=right.weightedWords.end(); it++){
		out<< (*it).first << " " << (*it).second<< " ";
	}
	
	
	return out;
	
	
}



istream &operator>>(istream &input, indexWords &right){
	string f;
	string dL;
//	cout<< right.getWord()<<endl;
	return input;
	//right.addDoc(f, dL);
	
}

void indexWords::constructWeight(){
	map<string, float>::iterator it;
	map<string, float>::iterator it2;
	float temp;
	for(it=docNames.begin(); it!=docNames.end(); it++){
		for(it2=docTotalWords.begin(); it2!=docTotalWords.end(); it2++){
			temp= (*it).second/(*it2).second;
			weightedWords[(*it).first]=temp;
		}
	}
}


void indexWords::printWeightedWords(){
	map<string, float>::iterator it;
	for(it=weightedWords.begin(); it!=weightedWords.end(); it++){
		cout<< (*it).first << " " << (*it).second<<endl;
	}
	
}

string indexWords::returnWeightedWords(){
	string temp;
	map<string, float>::iterator it;
	for(it=weightedWords.begin(); it!=weightedWords.end(); it++){
		temp+= (*it).first;
		temp+=" ";
		
		
		char* str = new char[30];
		float flt = (*it).second;		
		sprintf(str, "%f", flt );    
		string temp2;
		temp2+=str;
		temp+=temp2;
		temp+=" ";
		
	}
	temp+="\n";
	return temp;
}

void indexWords:: setMapsEqual(){
	weightedWords= docNames;
//	cout<<"Size of weighted: " << int(weightedWords.size())<<endl;
//	cout<<"Size of docNames: " << int(docNames.size())<<endl;
									  
}

