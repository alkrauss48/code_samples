/*
 *  DirList.h
 *  semesterProject
 *
 *  Created by Harrison Jackson on 11/12/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include <sys/types.h>
#include <dirent.h>
#include <string>
#include <vector>
#include <iostream>
using namespace std;

#ifndef DIRLIST_H
#define DIRLIST_H

class DirList{
private:
	DIR* dp;
	dirent* dirp;
	string dir;
	vector<string> list;
	
public:
	DirList(string directory): dir(directory){};
	
	/** Getlist will parse the directory
	 and get the latest list of entries
	 some could potentially be other directories
	 */
	
	vector<string> getList(){
		//open the directory and store
		//return value in a directroy structure
		dp = opendir(dir.c_str());
		
		//make sure that it worked
		if(dp != NULL){
			//get a directory entry (priming read)
			dirp= readdir(dp);
			while(dirp!=NULL){
				//add the name of the directory from the directory entry
				//to a vector of strings
				list.push_back(string(dirp->d_name));
				//read the next entry
				dirp = readdir(dp);
			}
			//close the directory
			closedir(dp);
		}
		//return the list of strings that represent
		//the file names.
		return list;
	}
};

#endif /* DIRLIST_H_ */
	
