/*
 *  words.cpp
 *  SemesterProject2341H
 *
 *  Created by Harrison Jackson on 12/4/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */
#include <string>

using namespace std;
#include "words.h"


words::words(string w){
	word = w;
	frequency = 1;
}
string words::getWord(){
	return word;
}

void words::setWord(string w){
	word = w;
}

int words::getFreq(){
	return frequency;
}

void words::operator++(){
	this->frequency++;
}
void words::setFreq(int f){
	frequency = f;
}
