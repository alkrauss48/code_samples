/*
 *  returnFiles.cpp
 *  SemesterProject2341H
 *
 *  Created by Harrison Jackson on 12/6/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include <string>
#include <map>
#include "indexWords.h"

using namespace std;

#include "returnFiles.h"
void returnFiles::addFile(string doc, float weight){
	returnFilesList.insert( make_pair(doc, weight));
}
void returnFiles::deleteFile(string doc){
	returnFilesList.erase(doc);
}

void returnFiles::print(){
	for(int i = 0; i < sortedFiles.size(); i++){
		cout<< sortedFiles[i]<<endl;
	}

}


	
	



int returnFiles:: getSize(){
	int temp;
	temp=returnFilesList.size();
	return temp;
}

void returnFiles::addFile(indexWords addIndexWord){
	map<string,float> temp = addIndexWord.getMap();
	map<string,float> ::iterator it;
	for(it = temp.begin(); it!= temp.end(); it++){
		addFile((*it).first,(*it).second);
	}
	
	return;
	
}

void returnFiles::deleteFile(indexWords deleteIndexWord){
	map<string,float> temp = deleteIndexWord.getMap();
	map<string,float> ::iterator it;
	for(it = temp.begin(); it!= temp.end(); it++){
		deleteFile((*it).first);
	}
	
	return;

}

void returnFiles:: sortFiles(){

	map<string, float>::iterator it;
	map<string, float> temp;
	temp = returnFilesList;
	
}

void returnFiles::printSort(){
	cout<< "Search Results: " << endl;
	map<string, float>::iterator it, itr, max;
	map<string, float> temp;
	temp = returnFilesList;
	int i = temp.size();
	while ( i > 0 ) {
		itr = temp.begin(), max = temp.begin(), it = temp.begin();
		int j = temp.size();
		while ( j > 0 ) {
			if ( itr->second> it->second) {
				max = itr;
				it = itr;
			}
			++itr;
			--j;
		}
		
		cout << " " <<max->first << endl;
		temp.erase(max);
		--i;
	}
}




