/*
 *  corpus.h
 *  SemesterProject2341H
 *
 *  Created by Harrison Jackson on 12/4/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */
#include <vector>
#include "documents.h"
#include "invertedFileIndex.h"
#include "DirList.h"
#include "stopWords.h"
#include "fstream"
#include <iostream>

using namespace std;

#ifndef CORPUS_H
#define CORPUS_H


class corpus{
private:
	vector<documents> doc;
	string directory;
	string fileName;
	double totalFiles;
	invertedFileIndex index;
	stopWords stopObject;
public:
	corpus(string directoryName):stopObject(659){
		directory = directoryName;		
		//create new directory files list
		DirList d(directory);
		vector<string> v = d.getList();
		vector<string>::iterator i;
		totalFiles = v.size();
		//create stop words object
		stopObject.openWords();
		
		//create documents
		for(i = v.begin(); i != v.end(); i++){
			string temp = *i;
			//if its a .txt file
			if(temp.length()> 4 && temp.substr(temp.length() -4,4) == ".txt"&& temp!="stopWords.txt"){
				documents tempDoc(temp, directory);
				doc.insert(doc.end(),tempDoc);
			}
		}
	
		
	}
	
	void createIndex();
	void printIndex();
	void writeIFI();
	invertedFileIndex* getP_IFI();

};

#endif