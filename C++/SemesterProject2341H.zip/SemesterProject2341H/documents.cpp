/*
 *  documents.cpp
 *  SemesterProject2341H
 *
 *  Created by Harrison Jackson on 12/4/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */
#include "Stemming.h"
#include "stopWords.h"
#include "words.h"
#include <vector>
#include <string>
#include <iostream>
#include <fstream>

using namespace std;
#include "documents.h"

documents::documents(){
	
}


documents::documents(string fileN, string pathN){
	fileName= fileN;
	pathName= pathN;
	fileANDpath= pathN+"/"+fileN;
}

void documents::openDoc()
{
	
	fstream inputFile;
    inputFile.open(fileANDpath.c_str(), ios::in);
	if (!inputFile.is_open()) 
	{
		cout << "Error: cannot open file. Goodbye. " << endl;
        exit(1);
    }
}

void documents::parse(stopWords stopObject) //inputFile = main document read-in file
{
	total = 0;
	fstream inputFile(fileANDpath.c_str(), ios::in);
	bool repeatWord = false;
	string temp;
	
	while(!inputFile.eof())
	{
		repeatWord = false;
		inputFile >> temp;

		for (unsigned int i =0; i < temp.size(); i++){ //converts to lower case
			temp[i] = tolower(temp[i]);	
		while(ispunct(temp[i])&&temp[i]!='-'&&temp[i]!='\'') //removes the ending punctuation if there is any
			//while(!isalpha(temp[i])||ispunct(temp[i]))
		{
			temp.erase(i);
			i--;
		}
	}
		
		int i = temp.size()-1;
		char temp2[80];
		strcpy(temp2,temp.c_str());
		
		if(stopObject.checkStopWords(temp2))
			continue;//starts the loop again with the next word before the stop word is actually initialized to the Word object
		
		stemFile(temp2); //stems the word before it is added to the document array
		
		this->checkRepeat(temp2, repeatWord); //temp = current read-in word, repeatWord = boolean variable determining if the word has been seen before
		if(repeatWord == false)							    
		{
	//		cout<<"inserting word: "<< temp<< endl;
			words tempWord(temp2);
	//		cout<< "tempWord: " << tempWord.getWord()<< endl;
			this->word.push_back(tempWord);
	//		cout<< "word ADDDDDDDDEEEEDDD" << endl;
			//++word[]; //overridden ++ operator (increases frequency by 1)

		}
		total++;

	}
	inputFile.close();
//	cout<<total<<endl;
}

void documents::stemFile(char *temp)
{
	temp[stem(temp, 0, strlen(temp)-1)+1] = 0;
	
}

void documents::checkRepeat(string temp, bool& repeat)
{
	vector<words>::iterator it;

	for(it = word.begin(); it != word.end(); it++)
	{
		string temp1 = (*it).getWord();
		if(temp == temp1)		{
		   ++(*it);
			repeat = true;
		}
	}
}

int documents:: getSize(){
	return word.size();
	
}

string documents::getWord(int i){
	return word[i].getWord();
	
}

int documents::getFreq(int i){
	return word[i].getFreq();
	
}

string documents:: getFile(){
	return fileName;	
}

void documents:: printDocs(){
}

int documents::getTotal(){
	return total;
}

