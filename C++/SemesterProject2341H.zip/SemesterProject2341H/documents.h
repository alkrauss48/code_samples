/*
 *  documents.h
 *  SemesterProject2341H
 *
 *  Created by Harrison Jackson on 12/4/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include <vector>
#include <string>
#include "stopWords.h"
#include "words.h"

using namespace std;
#ifndef DOCUMENTS_H
#define DOCUMENTS_H



class documents{
private:
	vector<words> word;
	string fileName;
	string pathName;
	string fileANDpath;
	int total;
	
public:
	documents();
	documents(string, string);
	void openDoc();
	void parse(stopWords);
	void stemFile(char* );
	void checkRepeat(string, bool&);
	int getSize();
	string getWord(int);
	int getFreq(int);
	string getFile();
	void printDocs();
	int getTotal();


	
	
};

#endif