/*
 *  returnFiles.h
 *  SemesterProject2341H
 *
 *  Created by Harrison Jackson on 12/6/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include <string>
#include <map>
#include <vector>
#include "indexWords.h"
#ifndef RETURNFILES_H
#define RETURNFILES_H

class returnFiles{
private:
	map <string,float> returnFilesList;
	vector<string> sortedFiles;
public:
	returnFiles(){};
	void addFile(string, float);
	void addFile(indexWords);
	void deleteFile(string);
	void print();
	int getSize();
	void deleteFile(indexWords);
	void sortFiles();
	void printSort();

	

};
#endif