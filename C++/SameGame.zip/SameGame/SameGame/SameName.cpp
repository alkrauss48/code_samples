#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;


const int ROWSIZE = 10;
const int COLSIZE = 15;
const int NAMESIZE = 15;
const int NUM_SCORES = 10;


void createBoard(int [][COLSIZE], int );
void getCoord(int& , int& );
void printBoard(int [][COLSIZE]);
int checkBoard(int [][COLSIZE], int , int , int );
void cleanBoard(int [][COLSIZE]);
int checkMovesLeft(int [][COLSIZE]);
void openAndRead();
void openAndWrite(char[], int);


int main()
{
	int score = 0;
	int difficultyNum = 0;
	int userRow = 0;
	int userCol = 0;
	int gameOver = 0;
	int board[ROWSIZE][COLSIZE];
	char name[NAMESIZE];
	cout << "Please enter your name: " << endl;
	cin >> name;
	cout << "\nYour name is: " << endl;
	cout << name;
	

	cout << "\n\nPlease enter:" << endl;
	cout << "1 - easy difficulty - numbers between 1 and 5" << endl;
	cout << "Any other number - hard difficulty - numbers between 1 and 8" << endl;
	cin >> difficultyNum;
	createBoard(board,difficultyNum);

	while(gameOver != 1){ //while loop continues until there are no more moves left 
		cout << "\nEnter x <space> y" << endl;
		getCoord(userRow, userCol);
		cout << userRow << " , " << userCol << endl;
		cout << "The number you selected is " << board[userRow][userCol]<< "\n" << endl;
		score = checkBoard(board, userRow, userCol, score);
		cleanBoard(board);
		printBoard(board);
		cout << "\n Your score is: " << score << endl;
		gameOver = checkMovesLeft(board); //determines if the loop continues
	}

	cout <<"\n\n You don't have any more moves left! Your final score is " << score << endl;
	openAndWrite(name, score);
	openAndRead();

	return 0;
}

void createBoard(int board[][COLSIZE], int x) //creates the initial board and prints it out as well
{
	int numNumbers = 0;
	if(x == 1)
	{
		numNumbers = 5;
	}
	else
	{
		numNumbers = 8;
	}
	cout << "     0  1  2  3  4  5  6  7  8  9  10 11 12 13 14" << endl;
	cout << endl;
	for(int x = 0; x < ROWSIZE; x++)
	{
		cout << x << "    ";
		for(int y = 0; y < COLSIZE; y++)
		{
			board[x][y] = (rand()%numNumbers)+1; 
			cout << board[x][y]<< "  ";
		}
		cout << endl;
	}
}


void getCoord(int& x, int& y)//gets the coordinate from the user
{
	do{
	cin >> x >> y;
	}while(x <0 || y < 0);
}

void printBoard(int board[][COLSIZE]) //prints the board after every coordinate entry
{
	cout << "   0  1  2  3  4  5  6  7  8  9  10 11 12 13 14" << endl;
	cout << endl;
	for(int x = 0; x < ROWSIZE; x++)
	{
		cout << x << "  ";
		for(int y = 0; y < COLSIZE; y++)
		{ 
			cout << board[x][y] << "  ";
		}
		cout << endl;
	}
}

int checkBoard(int board[][COLSIZE], int row, int col, int score) //main recursion method, sets all similarly clicked #s to 0
{
	int value = board[row][col];
	board[row][col] = 0;

	
if(value != 0)
{
	score += 20;
	if(value == board[row + 1][col])
	{
		score = checkBoard(board, row+1, col, score);
	}

	if(value == board[row - 1][col])
	{
		score = checkBoard(board, row-1, col, score);
	}

	if(value == board[row][col + 1])
	{
		score = checkBoard(board, row, col+1, score);
	}

	if(value == board[row][col - 1])
	{
		score = checkBoard(board, row, col-1, score);
	}
}
else
{
	cout << "Please enter a coordinate that doesn't already equal 0\n" << endl; //error checking
}
	return score;

}

void cleanBoard(int board[][COLSIZE])
{
	int tempRow = 0;
	int columnCheck[10];

	for(int row = 0; row < ROWSIZE-1; row++) //shift all 0's up
	{
		for(int col = 0; col < COLSIZE; col++)
		{
			if(board[row+1][col] == 0)
			{
				board[row+1][col] = board[row][col];
				board[row][col] = 0;
				tempRow = row-1;
				while(tempRow != -1){
					board[tempRow+1][col] = board[tempRow][col];
					board[tempRow][col] = 0;
					tempRow--;
				}
			}
		}
	}

	for(int col = 0; col < COLSIZE-1; col++) //shift all empty columns to the right
	{
		columnCheck[col] = 0;
		for(int row = 0; row < ROWSIZE; row++)
		{
			columnCheck[col] += board[row][col];
		}

		if(columnCheck[col] == 0)
		{
			for(int row = ROWSIZE -1; row >= 0; row--)
			{
				
				board[row][col] = board[row][col+1];
				board[row][col+1] = 0;
			}
		}
	}

}

int checkMovesLeft(int board[][COLSIZE]) //if there are no more adjacent similar numbers, then the program breaks the coordinate loop
{
	for(int row = 0; row < ROWSIZE; row++)
	{
		for(int col = 0; col < COLSIZE; col++)
		{
			if(board[row][col] != 0)
			{
				if(board[row][col] == board[row+1][col])
				{
					return 0;
				}
				if(board[row][col] == board[row-1][col])
				{
					return 0;
				}
				if(board[row][col] == board[row][col+1])
				{
					return 0;
				}
				if(board[row][col] == board[row][col-1])
				{
					return 0;
				}

			}
		}
	}

	return 1;
}


void openAndRead() //opens and prints the scores on the console
{
	fstream dataFile;
	dataFile.open("scoreSheet.txt", ios::in);
	if(!dataFile.is_open())
	{
		cout << "Error opening file!" << endl;
		exit(1);
	}
	
	char tempName[NAMESIZE];
	int tempScore;

	//char highScoreNames[NUM_SCORES][NAMESIZE];
	//int highScoreScores[NUM_SCORES];

	cout << "\nSCORE LIST" << endl;
	while(!dataFile.eof())
	{
		dataFile >> tempName;
		dataFile >> tempScore;
		if(dataFile.bad())
		{
			cout << "error reading scores " << endl;
			exit(1);
		}
		if(!dataFile.eof())
		{
			cout << "\nName: " << tempName << "\nScore: " << tempScore << endl;
			
		}
	}

	dataFile.close();
}

void openAndWrite(char name[], int score) //opens and writes the names and scores into a text file
{
	fstream dataOut("scoreSheet.txt", ios::app);
	if(!dataOut.is_open())
	{
		cout << "Error opening file!" << endl;
		exit(1);
	}

	dataOut.setf(ios::fixed);
	dataOut.precision(2);
	
	dataOut << name << " " << score << endl;
	
	dataOut.close();
}
