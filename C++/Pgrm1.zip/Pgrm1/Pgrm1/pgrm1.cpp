//Aaron Krauss
//Honors CSE 2341

#include <iostream>
#include <cmath> //called this to use the pow function
using namespace std;

int calculateMedian(int*, int );
int calculateMode(int*, int );
double calculateMean(int*, int );
double calculateStandardDeviation(int*, int );
int* sort(int*, int);


int main()
{
	int num = 0;
	int mode = 0;
	int median = 0;
	double mean = 0.0;
	double SD = 0.0;
	cout << "Please enter the number of integers that you wish to put on the list." << endl;
	cin >> num;
	int* numbers = new int[num]; //pointer to an array of numbers since i have to use a variable to initialize it

	cout << "Please enter " << num << " numbers." << endl; //finds the individual elements in the array
	for (int x = 0; x < num; x++)
		cin >> numbers[x];

	for (int x = 0; x < num; x++)
		cout << numbers[x] << " "; //prints them out
	cout << endl;
	numbers = sort(numbers, num); //sorts the numbers with a selection sort
	cout << endl;

	mode = calculateMode(numbers, num);  //four method calls
	median = calculateMedian(numbers, num);
	mean = calculateMean(numbers, num);
	SD = calculateStandardDeviation(numbers, num);

	cout << "\n\nMode is: " << mode << endl; //display information
	cout << "Median is: " << median << endl;
	cout << "Mean is: " << mean << endl;
	cout << "Standard Deviation is: " << SD << endl;

	delete [] numbers;						//delete the pointer to save program from a memory leak
	return 0;
}

int calculateMode(int* numbers, int num)
{
	int countDecider = 0;
	int currentMode = 1; //set the temp modes = to 1 because there will always be a mode of at least 1
	int tempMode = 1;
	int currentVal = numbers[0];
	int tempVal = 0;
	int number1 = 0;
	int number2 = 0;
	for(int i = 1; i < num;)
	{
		number2 = i; 
		number1 = i - 1; //number2 will always be the number in front of number1
		tempMode = 1;
		tempVal = 0;
		if(numbers[number2] != numbers[number1]) //since the list is sorted, the modes will already be in order
			i++;								 //if they are not the same right next to each other then the method loop will start over
		while(numbers[number2] == numbers[number1])
		{
			tempMode++; 
			tempVal = numbers[number1];
			i++;		 //manually incremenet the loop again becasue it needs to be even in the loop
			number2 = i; //increments the variables to see if they are the same again
			number1 = i - 1;
		}

		if(tempMode > currentMode) //if it's greater, then a new mode will be found
		{
			currentMode = tempMode;
			currentVal = tempVal;
		}
	}

	return currentVal;
}

int calculateMedian(int* numbers, int num)
{
	int medianIndex = 0;
	int median = 0;
	medianIndex = num / 2; //median is just the medium element in the pointer array
	median = numbers[medianIndex];

	return median;

}

double calculateMean(int* numbers, int num)
{
	double total = 0.0;
	for (int x = 0; x < num; x++)
		total += numbers[x]; //finding the summation of numbers
	num = (double)num;		 // casting num as a double to make num have a double answer

	return (double)total/num;

}

double calculateStandardDeviation(int* numbers, int num)
{
	double mean = calculateMean(numbers, num);
	double* tempArr = new double[num]; //created a second array because the numerator of SD involves all of the elements
	double totalNumer = 0.0;			//numerator variable
	double SD = 0.0;
	for (int x = 0; x < num; x++)
	{
		tempArr[x] = ((double)numbers[x]) - mean; //this is the SD formula (sqrt((sigma(x-xbar)^2) / (num-1)))
		tempArr[x] = pow(tempArr[x],2);
		totalNumer += tempArr[x];
	}
	SD = totalNumer / (((double)num) - 1);
	SD = pow(SD,.5);
	return SD;
}

int* sort(int* numbers, int num)	  //selection sort
{
	  int i = 0;
	  int j = 0;
	  int first = 0;
	  int temp = 0;
      for (i= num - 1; i > 0; i--)
     {
           first = 0;                 // initialize to subscript of first element
           for (j=1; j<=i; j++)		  // locate smallest between positions 1 and i.
          {
                 if (numbers[j] < numbers[first])
                 first = j;
          }
         temp = numbers[first];		   // Swap smallest found with element in position i.
         numbers[first] = numbers[i];
         numbers[i] = temp;

	}

	cout << "sorted list:" << endl;
		for(int x = 0; x < num; x++)
			cout << numbers[x] << " ";

	return numbers;
}
