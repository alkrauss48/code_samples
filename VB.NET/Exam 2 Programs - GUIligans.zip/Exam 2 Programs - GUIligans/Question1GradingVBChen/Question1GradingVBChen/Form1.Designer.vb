﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGrades
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SortToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ofd1 = New System.Windows.Forms.OpenFileDialog()
        Me.sfd1 = New System.Windows.Forms.SaveFileDialog()
        Me.lstRawData = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lstCalcData = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblExam1 = New System.Windows.Forms.Label()
        Me.lblExam2 = New System.Windows.Forms.Label()
        Me.lblExam3 = New System.Windows.Forms.Label()
        Me.lblExam4 = New System.Windows.Forms.Label()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.btnSearchID = New System.Windows.Forms.Button()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.btnSearchName = New System.Windows.Forms.Button()
        Me.btnSaveToFile = New System.Windows.Forms.Button()
        Me.lblHighScore = New System.Windows.Forms.Label()
        Me.lblLowScore = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.lblFound = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.DataToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(762, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(111, 22)
        Me.OpenToolStripMenuItem.Text = "Open"
        '
        'DataToolStripMenuItem
        '
        Me.DataToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SortToolStripMenuItem})
        Me.DataToolStripMenuItem.Name = "DataToolStripMenuItem"
        Me.DataToolStripMenuItem.Size = New System.Drawing.Size(42, 20)
        Me.DataToolStripMenuItem.Text = "Data"
        '
        'SortToolStripMenuItem
        '
        Me.SortToolStripMenuItem.Enabled = False
        Me.SortToolStripMenuItem.Name = "SortToolStripMenuItem"
        Me.SortToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.SortToolStripMenuItem.Text = "Calculate and Sort"
        '
        'ofd1
        '
        Me.ofd1.FileName = "OpenFileDialog1"
        '
        'lstRawData
        '
        Me.lstRawData.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstRawData.FormattingEnabled = True
        Me.lstRawData.ItemHeight = 14
        Me.lstRawData.Location = New System.Drawing.Point(12, 67)
        Me.lstRawData.Name = "lstRawData"
        Me.lstRawData.Size = New System.Drawing.Size(736, 186)
        Me.lstRawData.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(36, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Raw Data"
        '
        'lstCalcData
        '
        Me.lstCalcData.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstCalcData.FormattingEnabled = True
        Me.lstCalcData.ItemHeight = 14
        Me.lstCalcData.Location = New System.Drawing.Point(12, 291)
        Me.lstCalcData.Name = "lstCalcData"
        Me.lstCalcData.Size = New System.Drawing.Size(736, 186)
        Me.lstCalcData.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(36, 275)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(263, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Weighted Averages, Curved Scores, and Letter Grade"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(52, 499)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(110, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Exam 1 Raw Average"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(52, 526)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(110, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Exam 2 Raw Average"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(52, 552)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(110, 13)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Exam 3 Raw Average"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(52, 575)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(110, 13)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Exam 4 Raw Average"
        '
        'lblExam1
        '
        Me.lblExam1.BackColor = System.Drawing.Color.White
        Me.lblExam1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblExam1.Location = New System.Drawing.Point(168, 499)
        Me.lblExam1.Name = "lblExam1"
        Me.lblExam1.Size = New System.Drawing.Size(222, 23)
        Me.lblExam1.TabIndex = 9
        '
        'lblExam2
        '
        Me.lblExam2.BackColor = System.Drawing.Color.White
        Me.lblExam2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblExam2.Location = New System.Drawing.Point(168, 525)
        Me.lblExam2.Name = "lblExam2"
        Me.lblExam2.Size = New System.Drawing.Size(222, 23)
        Me.lblExam2.TabIndex = 10
        '
        'lblExam3
        '
        Me.lblExam3.BackColor = System.Drawing.Color.White
        Me.lblExam3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblExam3.Location = New System.Drawing.Point(168, 551)
        Me.lblExam3.Name = "lblExam3"
        Me.lblExam3.Size = New System.Drawing.Size(222, 23)
        Me.lblExam3.TabIndex = 11
        '
        'lblExam4
        '
        Me.lblExam4.BackColor = System.Drawing.Color.White
        Me.lblExam4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblExam4.Location = New System.Drawing.Point(168, 574)
        Me.lblExam4.Name = "lblExam4"
        Me.lblExam4.Size = New System.Drawing.Size(222, 23)
        Me.lblExam4.TabIndex = 12
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(555, 497)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(159, 20)
        Me.txtID.TabIndex = 13
        '
        'btnSearchID
        '
        Me.btnSearchID.Location = New System.Drawing.Point(434, 494)
        Me.btnSearchID.Name = "btnSearchID"
        Me.btnSearchID.Size = New System.Drawing.Size(115, 23)
        Me.btnSearchID.TabIndex = 14
        Me.btnSearchID.Text = "Search by ID"
        Me.btnSearchID.UseVisualStyleBackColor = True
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(555, 523)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(159, 20)
        Me.txtName.TabIndex = 15
        '
        'btnSearchName
        '
        Me.btnSearchName.Location = New System.Drawing.Point(434, 521)
        Me.btnSearchName.Name = "btnSearchName"
        Me.btnSearchName.Size = New System.Drawing.Size(115, 23)
        Me.btnSearchName.TabIndex = 16
        Me.btnSearchName.Text = "Search by Name"
        Me.btnSearchName.UseVisualStyleBackColor = True
        '
        'btnSaveToFile
        '
        Me.btnSaveToFile.Location = New System.Drawing.Point(269, 646)
        Me.btnSaveToFile.Name = "btnSaveToFile"
        Me.btnSaveToFile.Size = New System.Drawing.Size(280, 33)
        Me.btnSaveToFile.TabIndex = 17
        Me.btnSaveToFile.Text = "Save Grades To File"
        Me.btnSaveToFile.UseVisualStyleBackColor = True
        '
        'lblHighScore
        '
        Me.lblHighScore.BackColor = System.Drawing.Color.White
        Me.lblHighScore.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHighScore.Location = New System.Drawing.Point(168, 597)
        Me.lblHighScore.Name = "lblHighScore"
        Me.lblHighScore.Size = New System.Drawing.Size(222, 23)
        Me.lblHighScore.TabIndex = 18
        '
        'lblLowScore
        '
        Me.lblLowScore.BackColor = System.Drawing.Color.White
        Me.lblLowScore.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblLowScore.Location = New System.Drawing.Point(168, 620)
        Me.lblLowScore.Name = "lblLowScore"
        Me.lblLowScore.Size = New System.Drawing.Size(222, 23)
        Me.lblLowScore.TabIndex = 19
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(88, 598)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(74, 13)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Highest Score"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(88, 621)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 13)
        Me.Label14.TabIndex = 21
        Me.Label14.Text = "Lowest Score"
        '
        'lblFound
        '
        Me.lblFound.AutoSize = True
        Me.lblFound.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFound.Location = New System.Drawing.Point(555, 559)
        Me.lblFound.Name = "lblFound"
        Me.lblFound.Size = New System.Drawing.Size(2, 15)
        Me.lblFound.TabIndex = 22
        '
        'frmGrades
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(762, 703)
        Me.Controls.Add(Me.lblFound)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.lblLowScore)
        Me.Controls.Add(Me.lblHighScore)
        Me.Controls.Add(Me.btnSaveToFile)
        Me.Controls.Add(Me.btnSearchName)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.btnSearchID)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.lblExam4)
        Me.Controls.Add(Me.lblExam3)
        Me.Controls.Add(Me.lblExam2)
        Me.Controls.Add(Me.lblExam1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lstCalcData)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lstRawData)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmGrades"
        Me.Text = "Grades"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ofd1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents sfd1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents lstRawData As System.Windows.Forms.ListBox
    Friend WithEvents DataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SortToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lstCalcData As System.Windows.Forms.ListBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblExam1 As System.Windows.Forms.Label
    Friend WithEvents lblExam2 As System.Windows.Forms.Label
    Friend WithEvents lblExam3 As System.Windows.Forms.Label
    Friend WithEvents lblExam4 As System.Windows.Forms.Label
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents btnSearchID As System.Windows.Forms.Button
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents btnSearchName As System.Windows.Forms.Button
    Friend WithEvents btnSaveToFile As System.Windows.Forms.Button
    Friend WithEvents lblHighScore As System.Windows.Forms.Label
    Friend WithEvents lblLowScore As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents lblFound As System.Windows.Forms.Label

End Class
