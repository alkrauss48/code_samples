﻿'Programmed by: Aaron Krauss, William Heath, and Ying Chen
'Team: GUIligans
'Problem 1


Public Class frmGrades

    'declare form level variables
    Private mstrName() As String
    Private mstrID() As String
    Private mdblGrade1() As Double
    Private mdblGrade2() As Double
    Private mdblGrade3() As Double
    Private mdblGrade4() As Double
    Private mdblHomework() As Double
    Private mdblAbsences() As Double

    'declare constants
    Const EXAM1WEIGHT As Double = 0.1
    Const EXAM2WEIGHT As Double = 0.2
    Const EXAM3WEIGHT As Double = 0.25
    Const EXAM4WEIGHT As Double = 0.35
    Const HOMEWORKWEIGHT As Double = 0.1

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click

        'declare local variables and begin output list
        Dim index As Integer = 0
        Dim fmtStr1 As String = "{0,-25}{1,-15}{2,-10}{3,-10}{4,-10}{5,-10}{6,-10}{7,-10}"
        Dim fmtStr2 As String = "{0,-25}{1,-15}{2,-10:N0}{3,-10:N0}{4,-10:N0}{5,-10:N0}{6,-10:N0}{7,-10:N0}"
        lstRawData.Items.Add(String.Format(fmtStr1, "Name", "Student ID", "Exam 1", "Exam 2", "Exam 3", "Exam 4", "Homework", "Absences"))

        'declare sub to read file and populate arrays
        ReadFile()

        'display data
        For index = 0 To mstrID.GetUpperBound(0)

            lstRawData.Items.Add(String.Format(fmtStr2, mstrName(index), mstrID(index), mdblGrade1(index), mdblGrade2(index), mdblGrade3(index), mdblGrade4(index), mdblHomework(index), mdblAbsences(index)))

        Next

        'enable the sort menu item
        SortToolStripMenuItem.Enabled = True

    End Sub

    Private Sub ReadFile()

        'declare local variables
        Dim index As Integer = 0
        Dim ResponseDialogResult As DialogResult
        Dim temp1 As String
        Dim temp2 As String

        Dim sr As IO.StreamReader

        'set format of open file dialog
        With ofd1
            .Title = "Select Grades File"
            .Filter = "Text Files(*.txt)|*.txt"
            ResponseDialogResult = .ShowDialog()
        End With

        If ResponseDialogResult = Windows.Forms.DialogResult.OK Then
            Dim fileName As String = ofd1.FileName
            sr = IO.File.OpenText(fileName)
        Else
            Exit Sub
        End If

        temp1 = sr.ReadLine()
        temp2 = sr.ReadLine()

        'iterate through the file and populate the arrays 
        Do While sr.Peek <> -1

            'redim the arrays as they grow in size
            ReDim Preserve mstrName(index)
            ReDim Preserve mstrID(index)
            ReDim Preserve mdblGrade1(index)
            ReDim Preserve mdblGrade2(index)
            ReDim Preserve mdblGrade3(index)
            ReDim Preserve mdblGrade4(index)
            ReDim Preserve mdblHomework(index)
            ReDim Preserve mdblAbsences(index)


            'populate the arrays
            mstrName(index) = sr.ReadLine
            mstrID(index) = sr.ReadLine
            mdblGrade1(index) = CDbl(sr.ReadLine)
            mdblGrade2(index) = CDbl(sr.ReadLine)
            mdblGrade3(index) = CDbl(sr.ReadLine)
            mdblGrade4(index) = CDbl(sr.ReadLine)
            mdblHomework(index) = CDbl(sr.ReadLine)
            mdblAbsences(index) = CDbl(sr.ReadLine)

            index += 1


        Loop

        MessageBox.Show("File Successfully Loaded")

        sr.Close()


    End Sub


    Private Function CalculateWeighted(ByVal exam1 As Double, ByVal exam2 As Double, ByVal exam3 As Double, ByVal exam4 As Double, ByVal Homework As Double, ByVal absences As Double) As Double

        Dim dblWeighted As Double
        Dim dblExams As Double

        'function to calculate exam grades for one person
        dblExams = CalculateExams(exam1, exam2, exam3, exam4, absences)

        'calculate weighted average
        dblWeighted = dblExams + (Homework * HOMEWORKWEIGHT)

        Return dblWeighted

    End Function

    Private Function CalculateExams(ByVal e1 As Double, ByVal e2 As Double, ByVal e3 As Double, ByVal e4 As Double, ByVal a1 As Double) As Double
        Dim dblExams As Double
        Dim dblAbsences As Double

        'calculate weighted exam grade
        dblExams = (e1 * EXAM1WEIGHT) + (e2 * EXAM2WEIGHT) + (e3 * EXAM3WEIGHT) + (e4 * EXAM4WEIGHT)
        dblAbsences = dblExams - a1

        Return dblAbsences

    End Function

    Private Function LetterGrade(ByRef grade As Double)
        Dim strLetter As String

        'select case statement to get letter grade
        Select Case grade
            Case Is >= 91
                strLetter = "A"
            Case Is >= 81
                strLetter = "B"
            Case Is >= 71
                strLetter = "C"
            Case Is >= 61
                strLetter = "D"
            Case Else
                strLetter = "F"
        End Select

        Return strLetter

    End Function

    Private Sub SortToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SortToolStripMenuItem.Click

        'local variables
        Dim index As Integer = 0
        Dim fmtStr1 As String = "{0,-25}{1,-15}{2,-20}{3,-20}{4,-10}"
        Dim fmtStr2 As String = "{0,-25}{1,-15}{2,-20:N0}{3,-20:N0}{4,-10}"
        lstCalcData.Items.Add(String.Format(fmtStr1, "Name", "Student ID", "Weighted Average", "Curved Score", "Letter Grade"))

        'more variables
        Dim dblWeighted(mstrID.GetUpperBound(0)) As Double
        Dim dblweightedmax As Double
        Dim dblweightedmin As Double
        Dim dblrange As Double
        Dim dblCurve As Double
        Dim dblCurvedGrades(mstrID.GetUpperBound(0)) As Double
        Dim strLetterGrades(mstrID.GetUpperBound(0)) As String

        'calculate weighted average for all students and store them in an array
        For index = 0 To mstrID.GetUpperBound(0)
            dblWeighted(index) = CalculateWeighted(mdblGrade1(index), mdblGrade2(index), mdblGrade3(index), mdblGrade4(index), mdblHomework(index), mdblAbsences(index))
        Next

        'gather required information
        dblweightedmax = dblWeighted.Max
        dblweightedmin = dblWeighted.Min

        dblrange = dblweightedmax - dblweightedmin

        dblCurve = dblrange * (1 / 10)

        'get curved averages and letter grades through functions
        For index = 0 To mstrID.GetUpperBound(0)
            dblCurvedGrades(index) = dblWeighted(index) + dblCurve
        Next

        For index = 0 To mstrID.GetUpperBound(0)
            strLetterGrades(index) = LetterGrade(dblCurvedGrades(index))
        Next

        'display data in labels
        lblHighScore.Text = dblweightedmax
        lblLowScore.Text = dblweightedmin


        lblExam1.Text = CStr(mdblGrade1.Average)
        lblExam2.Text = CStr(mdblGrade2.Average)
        lblExam3.Text = CStr(mdblGrade3.Average)
        lblExam4.Text = CStr(mdblGrade4.Average)


        'Sort the grades by descending order

        'preliminary values for shell sort
        Dim gap As Integer, doneFlag As Boolean
        Dim temp1, temp2, temp3 As String
        Dim temp4 As String, temp7 As Double

        'begin shell sort
        gap = CInt((dblWeighted.Length) / 2)

        Do While gap >= 1

            Do

                doneFlag = True

                For index = 0 To dblWeighted.Length - (gap + 1)

                    If dblWeighted(index) < dblWeighted(index + gap) Then

                        temp1 = mstrName(index)
                        temp2 = mstrID(index)
                        temp3 = dblCurvedGrades(index)
                        temp4 = strLetterGrades(index)
                        temp7 = dblWeighted(index)

                        mstrName(index) = mstrName(index + gap)
                        mstrID(index) = mstrID(index + gap)
                        dblCurvedGrades(index) = dblCurvedGrades(index + gap)
                        strLetterGrades(index) = strLetterGrades(index + gap)
                        dblWeighted(index) = dblWeighted(index + gap)

                        mstrName(index + gap) = temp1
                        mstrID(index + gap) = temp2
                        dblCurvedGrades(index + gap) = temp3
                        strLetterGrades(index + gap) = temp4
                        dblWeighted(index + gap) = temp7

                        doneFlag = False

                    End If

                Next index

            Loop Until doneFlag = True

            gap = CInt(gap / 2)

        Loop
        'end shell sort

        'redisplay all array data in sorted order
        For index = 0 To mstrID.GetUpperBound(0)
            lstCalcData.Items.Add(String.Format(fmtStr2, mstrName(index), mstrID(index), dblWeighted(index), dblCurvedGrades(index), strLetterGrades(index)))
        Next
        

    End Sub
  
    Private Sub btnSearchID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchID.Click

        'local variables
        Dim strIDToLook As String = txtID.Text.ToUpper
        Dim index As Integer
        Dim blnflag As Boolean = False
        Dim i As Integer

        'loop to find the whether the ID was found
        Do While Not (blnflag) And (i < mstrID.Length)

            If strIDToLook = mstrID(i) Then
                blnflag = True
                index = i
            End If

            i += 1

        Loop

        If blnflag Then
            lblFound.Text = "Found"
        Else
            lblFound.Text = "Not Found"
        End If

    End Sub

    Private Sub btnSearchName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchName.Click

        Dim strNameToLook As String = txtName.Text.ToUpper
        Dim index As Integer
        Dim blnflag As Boolean = False
        Dim i As Integer

        'loop to find whether the name was found
        Do While Not (blnflag) And (i < mstrName.Length)

            If strNameToLook = mstrName(i).ToUpper Then
                blnflag = True
                index = i
            End If

            i += 1

        Loop

        If blnflag Then
            lblFound.Text = "Found"
        Else
            lblFound.Text = "Not Found"
        End If

    End Sub

    Private Sub btnSaveToFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveToFile.Click
        Dim sw As IO.StreamWriter

        With sfd1
            .Title = "Save File"
            .Filter = "Text Files(*.txt)|*.txt"
            .ShowDialog()
        End With
        'set stream reader to the file name of the chosen file

        sw = IO.File.CreateText(sfd1.FileName)

        Dim i As Integer

        'loop through listbox using iterator
        For i = 0 To lstCalcData.Items.Count - 1
            sw.WriteLine(lstCalcData.Items.Item(i))
        Next

        sw.Close()
    End Sub
End Class
