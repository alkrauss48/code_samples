﻿Public Class frmProblem4
    'Group:     GUIligans
    'Members:   Aaron Krauss, Ying-Ting Chen, Will Heath

    Const FICARATE As Double = 0.0765
    'name, ID, worker type, total collection, Gross Salary, FICA, Net Salary
    Private strFmt As String = "{0,-20}{1,-15}{2,-15}{3,-20}{4, -15}{5,-15}{6,-15}"

    'declare arrays
    Private strNames() As String
    Private strIDs() As String
    Private strType() As String
    Private dblCollections() As Double
    Private dblGross() As Double
    Private dblTaxes() As Double
    Private dblNet() As Double

    'accumulator for array indexes
    Private numElements As Integer = 0

    Private Sub btnEnterData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEnterData.Click

        'check to see if any text boxes were left empty
        If (txtFName.Text = "" Or txtLname.Text = "" Or txtID.Text = "" Or txtWeek1.Text = "" Or _
            txtWeek2.Text = "" Or txtWeek3.Text = "" Or txtWeek4.Text = "") Then

            MessageBox.Show("Please fill in all the required fields", "Missing Fields")
            Exit Sub

        End If

        'declare local variables
        Dim strFName, strLName, strFullName As String
        Dim dblWeek1, dblWeek2, dblWeek3, dblWeek4 As Double
        Dim dblTotalCollections As Double
        Dim dblGrossSalary, dblFICA, dblNetSalary As Double

        Dim strID As String
        Dim strWorkerType As String = ""
        Dim blnCorrectFormat As Boolean

        'get name values
        strFName = txtFName.Text
        strLName = txtLname.Text
        strFullName = strFName & " " & strLName

        strID = txtID.Text

        'check to see if the array strIDs has any values
        If Not (IsNothing(strIDs)) Then
            'check to see if the ID is already in the array. if so, then it exits the sub
            For i As Integer = 0 To strIDs.Length - 1
                If strID.ToUpper = strIDs(i) Then
                    MessageBox.Show("ID has already been used. Please enter a different ID.", "ID Already Used")
                    Exit Sub
                End If
            Next
        End If

        'function which validates the format of the ID
        blnCorrectFormat = validateID(strID, strLName, strWorkerType)

        'if formatted incorrectly, it will display a message and exit sub
        If Not blnCorrectFormat Then
            MessageBox.Show("Please use the correct format when entering User ID", "Bad Format")
            txtID.SelectAll()
            txtID.Focus()
            Exit Sub
        End If

        'gather collections data
        dblWeek1 = CDbl(txtWeek1.Text)
        dblWeek2 = CDbl(txtWeek2.Text)
        dblWeek3 = CDbl(txtWeek3.Text)
        dblWeek4 = CDbl(txtWeek4.Text)

        dblTotalCollections = dblWeek1 + dblWeek2 + dblWeek3 + dblWeek4

        'call function to calculate gross salary/commissions, depending on employee type
        dblGrossSalary = calculateGrossSalary(dblTotalCollections, strWorkerType)

        'calculate taxes and net salary
        dblFICA = dblGrossSalary * FICARATE * -1
        dblNetSalary = dblGrossSalary + dblFICA


        'redim the arrays
        ReDim Preserve strNames(numElements)
        ReDim Preserve strIDs(numElements)
        ReDim Preserve strType(numElements)
        ReDim Preserve dblCollections(numElements)
        ReDim Preserve dblGross(numElements)
        ReDim Preserve dblTaxes(numElements)
        ReDim Preserve dblNet(numElements)

        'add values to the arrays
        strNames(numElements) = strFullName
        strIDs(numElements) = strID
        strType(numElements) = strWorkerType
        dblCollections(numElements) = dblTotalCollections
        dblGross(numElements) = dblGrossSalary
        dblTaxes(numElements) = dblFICA
        dblNet(numElements) = dblNetSalary

        'increment the total number of elements in all arrays
        numElements += 1

        'sort the output list each time a new entry has been made
        sortBySalary()

        'I realize that the document said to sort after at least 10 entries have been made, 
        'but I figured it would be better practice for the business world if I went ahead and
        'sorted all of the entries as they were entered. It doesn't change the runtime but a tiny
        'fraction of a second

        'clear the input fields to aid the user in entering data
        semiClear()

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click

        lstSearch.Items.Clear()
        lstOutput.Items.Clear()
        lstOutput.Items.Add(String.Format(strFmt, "Name", "ID", "Worker Type", "Total Collections", "Gross Salary", "FICA", "Net Salary"))

        'redimension the array w/o preserving the values
        ReDim strNames(0)
        ReDim strIDs(0)
        ReDim strType(0)
        ReDim dblCollections(0)
        ReDim dblGross(0)
        ReDim dblTaxes(0)
        ReDim dblNet(0)

        'resets number of elements
        numElements = 0

        'calls sub to clear input fields
        semiClear()

    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        Dim sw As IO.StreamWriter

        With saveFD
            .Title = "Save File"
            .Filter = "Text Files(*.txt)|*.txt"
            .ShowDialog()
        End With
        'set stream reader to the file name of the chosen file

        sw = IO.File.CreateText(saveFD.FileName)

        Dim i As Integer

        'loop through listbox using iterator
        For i = 0 To lstOutput.Items.Count - 1
            sw.WriteLine(lstOutput.Items.Item(i))
        Next

        sw.Close()

    End Sub

    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click

        'gather preliminary data
        Dim strSearch = InputBox("Please enter an Employee ID that you wish to search by", "Search For Employee").ToUpper
        Dim strSearchFmt As String = "{0, -25}{1, -25}"
        Dim index, i As Integer
        Dim blnFlag As Boolean = False

        lstSearch.Items.Clear()

        'loop to see the position of the search query. if not there, then the flag stays false
        Do While Not (blnFlag) And (i < strIDs.Length)

            If strSearch = strIDs(i) Then
                blnFlag = True
                index = i
            End If

            i += 1

        Loop

        'display the data of the person found, or display "no result found" if the entry is  not found
        If blnFlag Then
            lstSearch.Items.Add(String.Format(strSearchFmt, "Name:", strNames(index)))
            lstSearch.Items.Add(String.Format(strSearchFmt, "ID:", strIDs(index)))
            lstSearch.Items.Add(String.Format(strSearchFmt, "Worker Type:", strType(index)))
            lstSearch.Items.Add(String.Format(strSearchFmt, "Total Collections:", dblCollections(index).ToString("C2")))
            lstSearch.Items.Add(String.Format(strSearchFmt, "Gross Salary:", dblGross(index).ToString("C2")))
            lstSearch.Items.Add(String.Format(strSearchFmt, "FICA Amount:", dblTaxes(index).ToString("C2")))
            lstSearch.Items.Add(String.Format(strSearchFmt, "Net Salary:", dblNet(index).ToString("C2")))
        Else
            lstSearch.Items.Add("No Result Found")
        End If

    End Sub

    Private Sub semiClear()

        'basic input field clearing
        txtFName.Clear()
        txtLname.Clear()
        txtID.Clear()
        txtWeek1.Clear()
        txtWeek2.Clear()
        txtWeek3.Clear()
        txtWeek4.Clear()
        txtFName.Focus()

    End Sub

    Private Function validateID(ByRef strID As String, ByVal strLName As String, ByRef workerType As String) As Boolean

        'local variables
        Dim iterator As Integer = 0
        Dim firstThree As String

        'set strings to upper so that initial case doesn't matter
        firstThree = strLName.Substring(0, 3).ToUpper
        strID = strID.ToUpper

        'check first 4 characters of ID
        While iterator < 4

            'make sure that there are enough letters in the word so that a runtime error doesnt occur
            If (strID.Length <= iterator) Then
                Return False
            End If

            'if any of the first 4 are not letters, then it kicks out
            If Not Char.IsLetter(strID.Substring(iterator, 1)) Then
                Return False
            End If

            iterator += 1

        End While

        'checks 5th char to see if it's a "-"
        If Not strID.Chars(iterator) = "-" Then
            Return False
        End If
        iterator += 1

        'checks if next two values are either 12 or 13
        If Val(strID.Substring(5, 2) = 12) Then
            workerType = "Monthly"
        ElseIf Val(strID.Substring(5, 2) = 13) Then
            workerType = "Commission"
        Else
            Return False
        End If

        iterator += 2

        'checks if 8th char is a "-"
        If Not strID.Chars(iterator) = "-" Then
            Return False
        End If

        iterator += 1

        'checks last part of ID to see if it matches the last name
        If Not (strID.Substring(iterator).ToUpper = firstThree) Then
            Return False
        End If

        'if all the conditions are met, then the ID is in the proper format
        Return True

    End Function

    Private Function calculateGrossSalary(ByVal dblAmount As Double, ByVal strType As String) As Double

        'local variables for monthly worker
        Dim dblBasePay As Double = 500
        Dim dblMonthlyRate As Double = 0.15

        Dim dblSalary As Double = 0

        'different salary depending on worker type
        If strType = "Monthly" Then
            dblSalary = dblBasePay + (dblMonthlyRate * dblAmount)
            Return dblSalary
        Else

            Select Case dblAmount

                Case Is <= 10000
                    dblSalary = (0.05 * dblAmount)
                Case 10000 To 30000
                    dblSalary = (0.1 * (dblAmount - 10000)) + 500
                Case Is > 30000
                    dblSalary = (0.125 * (dblAmount - 30000)) + 2500

            End Select

            Return dblSalary

        End If

    End Function

    Private Sub sortBySalary()

        lstOutput.Items.Clear()
        lstOutput.Items.Add(String.Format(strFmt, "Name", "ID", "Worker Type", "Total Collections", "Gross Salary", "FICA", "Net Salary"))

        'preliminary values for shell sort
        Dim gap, index As Integer, doneFlag As Boolean
        Dim temp1, temp2, temp3 As String
        Dim temp4, temp5, temp6, temp7 As Double

        'begin shell sort
        gap = CInt((dblNet.Length) / 2)

        Do While gap >= 1

            Do

                doneFlag = True

                For index = 0 To dblNet.Length - (gap + 1)

                    If dblNet(index) < dblNet(index + gap) Then

                        temp1 = strNames(index)
                        temp2 = strIDs(index)
                        temp3 = strType(index)
                        temp4 = dblCollections(index)
                        temp5 = dblGross(index)
                        temp6 = dblTaxes(index)
                        temp7 = dblNet(index)

                        strNames(index) = strNames(index + gap)
                        strIDs(index) = strIDs(index + gap)
                        strType(index) = strType(index + gap)
                        dblCollections(index) = dblCollections(index + gap)
                        dblGross(index) = dblGross(index + gap)
                        dblTaxes(index) = dblTaxes(index + gap)
                        dblNet(index) = dblNet(index + gap)

                        strNames(index + gap) = temp1
                        strIDs(index + gap) = temp2
                        strType(index + gap) = temp3
                        dblCollections(index + gap) = temp4
                        dblGross(index + gap) = temp5
                        dblTaxes(index + gap) = temp6
                        dblNet(index + gap) = temp7

                        doneFlag = False

                    End If

                Next index

            Loop Until doneFlag = True

            gap = CInt(gap / 2)

        Loop
        'end shell sort

        'redisplay all array data in sorted order
        For index = 0 To dblNet.Length - 1

            lstOutput.Items.Add(String.Format(strFmt, strNames(index), strIDs(index), strType(index), _
                                              dblCollections(index).ToString("C2"), dblGross(index).ToString("C2"), _
                                              dblTaxes(index).ToString("C2"), dblNet(index).ToString("C2")))

        Next

    End Sub

    Private Sub frmProblem4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'initializes the values of the output listbox
        lstOutput.Items.Add(String.Format(strFmt, "Name", "ID", "Worker Type", "Total Collections", "Gross Salary", "FICA", "Net Salary"))
    End Sub

    Private Sub validateNumberTxtBox(ByVal txt As TextBox)

        'checks to see if the txtbox is an invalid numerical value
        If txt.Text = "" Then
            Exit Sub
        ElseIf Not IsNumeric(txt.Text) Then
            MessageBox.Show("Please enter a valid numerical value", "Error - Non-Numerical Value")
            txt.Focus()
            txt.SelectAll()
        ElseIf Val(txt.Text) < 0 Then
            MessageBox.Show("Please enter a non-negative numerical value", "Error - Negative Value")
            txt.Focus()
            txt.SelectAll()
        End If

    End Sub

    Private Sub validateLetterTxtBox(ByVal txt As TextBox)

        'checks to see if the txtbox is an invalid string value
        If txt.Text = "" Then
            Exit Sub
        ElseIf IsNumeric(txt.Text) Then
            MessageBox.Show("Please enter a valid name", "Error - Non-Acceptable Name Value")
            txt.Focus()
            txt.SelectAll()
        End If

    End Sub

    Private Sub txtFName_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtFName.Validating
        validateLetterTxtBox(txtFName)
    End Sub

    Private Sub txtLname_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtLname.Validating
        validateLetterTxtBox(txtLname)
    End Sub

    Private Sub txtWeek1_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtWeek1.Validating
        validateNumberTxtBox(txtWeek1)
    End Sub

    Private Sub txtWeek2_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtWeek2.Validating
        validateNumberTxtBox(txtWeek2)
    End Sub

    Private Sub txtWeek3_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtWeek3.Validating
        validateNumberTxtBox(txtWeek3)
    End Sub

    Private Sub txtWeek4_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtWeek4.Validating
        validateNumberTxtBox(txtWeek4)
    End Sub
End Class
