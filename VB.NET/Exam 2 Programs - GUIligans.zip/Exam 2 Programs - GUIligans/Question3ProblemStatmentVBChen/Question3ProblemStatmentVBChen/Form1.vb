﻿'Ying-Ting Chen, William Heath, Aaron Krauss
'Team GUIligans

Public Class Form1
    'defining arrays to be used in the program
    Private mstrID() As String
    Private mdblCost() As Double
    Private mstrModel() As String
    Private mdblBegstock() As Double
    Private mdblEndStock() As Double
    Private dblAverage() As Double
    Private dblTurnover() As Double

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click
        lstOutput.Items.Clear() 'clear the listbox for multiple uses
        Dim index As Integer = 0 'defining index to count arrays with
        'defining formats for listbox
        Dim fmtStr1 As String = "{0,-10}{1,-10}{2,2}{3,-50}{4,10}{5,10}{6,20}{7,2}{8,-10}"
        Dim fmtStr2 As String = "{0,-10}{1,10:C2}{2,2}{3,-50}{4,10:C2}{5,10:C2}{6,20:C2}{7,2}{8,-10:n0}"
        'adding header to the listbox
        lstOutput.Items.Add(String.Format(fmtStr1, "Prod ID", "Cost", "", "Model", "BegStock", "EndStock", "Average Inventory", " ", "Turnover"))

        'initializing the subprocedure to read the file from the text file to the array
        ReadFile()

        'redefining arrays to use them in calculations
        ReDim Preserve dblAverage(mstrID.GetUpperBound(0))
        ReDim Preserve dblTurnover(mstrID.GetUpperBound(0))

        'calculating average inventory based on value of beginning stock and value of ending stock
        For index = 0 To mstrID.GetUpperBound(0)
            dblAverage(index) = CalculateAverage(mdblBegstock(index), mdblEndStock(index))
        Next

        'calculating turnover based on cost of goods sold and average stock.
        For index = 0 To mstrID.GetUpperBound(0)
            dblTurnover(index) = CalculateTurnover(mdblCost(index), dblAverage(index))
        Next

        'adding items to listbox
        For index = 0 To mstrID.GetUpperBound(0)

            lstOutput.Items.Add(String.Format(fmtStr2, mstrID(index), mdblCost(index), "", mstrModel(index), mdblBegstock(index), mdblEndStock(index), dblAverage(index), " ", dblTurnover(index)))

        Next



    End Sub

    Private Sub ReadFile() 'readfile sub procedure to pull data from text file to the array
        Dim index As Integer = 0 'defining index to count the arrays with
        Dim ResponseDialogResult As DialogResult
        Dim temp1 As String 'defining a placeholder for the text headers
        Dim temp2 As String

        Dim sr As IO.StreamReader 'initializing a streamreader

        With ofd1 'openfildialog function
            .Title = "Select Inventory File"
            ResponseDialogResult = .ShowDialog()
        End With
        'validation for the openfiledialog
        If ResponseDialogResult = Windows.Forms.DialogResult.OK Then
            Dim fileName As String = ofd1.FileName
            sr = IO.File.OpenText(fileName)
        Else
            Exit Sub
        End If

        temp1 = sr.ReadLine() 'clearing the text headers
        temp2 = sr.ReadLine()

        'do while statement for adding the items from the text file into the arrays
        Do While sr.Peek <> -1
            'redefining the arrays
            ReDim Preserve mstrID(index)
            ReDim Preserve mdblCost(index)
            ReDim Preserve mstrModel(index)
            ReDim Preserve mdblBegstock(index)
            ReDim Preserve mdblEndStock(index)


            'adding items into the arrays using readline functions
            mstrID(index) = sr.ReadLine
            mdblCost(index) = CDbl(sr.ReadLine)
            mstrModel(index) = sr.ReadLine
            mdblBegstock(index) = CDbl(sr.ReadLine)
            mdblEndStock(index) = CDbl(sr.ReadLine)

            'increasing the array count
            index += 1


        Loop
        'show no error confirmation
        MessageBox.Show("File Successfully Loaded")
        'closeing the streamreader so it can be used again
        sr.Close()


    End Sub
    'function for calculating average inventory cost
    Private Function CalculateAverage(ByVal BegInv As Double, ByVal EndInv As Double)
        Dim dblAverage As Double
        'setting average inventory equal to beginning inventroy dollar value and ending inventory dollar value
        dblAverage = ((BegInv) + (EndInv)) / 2

        Return dblAverage

    End Function
    'function for calculating the turnover 
    Private Function CalculateTurnover(ByVal CoGS As Double, ByVal AvgInv As Double)
        Dim dblTurnover As Double
        'setting the turnover equal to cost of goods sold divided by the average inventory
        dblTurnover = CoGS / AvgInv

        Return dblTurnover

    End Function

    'subrouting for saving the new text file from the array.
    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click
        'defining the response dialog
        Dim ResponseDialogResult As DialogResult
        'initializing the streamwriter
        Dim tw As IO.StreamWriter
        'defining the filename
        Dim filename As String = ""
        'starting the savefiledialog
        With sfd1
            .Filter = "Text Files|*.txt"
            .Title = "Save file"
            ResponseDialogResult = .ShowDialog()
        End With
        'validating teh savefiledialog
        If (Not (sfd1.FileName = Nothing)) Then
            filename = sfd1.FileName
        Else
            Exit Sub

        End If
        'creating the file from the streamreader
        tw = IO.File.CreateText(filename)
        'defining and index to count the arrays with
        Dim index As Integer
        'writing a header to the title of the document
        tw.WriteLine("FileDescription")
        tw.WriteLine("Prod ID, Cost, Model, BegStock, EndStock, Average Inventory, Turnover")
        'writing the data directly from the arrays into the document
        For index = 0 To mstrID.GetUpperBound(0)
            tw.WriteLine(mstrID(index))
            tw.WriteLine(mdblCost(index))
            tw.WriteLine(mstrModel(index))
            tw.WriteLine(mdblBegstock(index))
            tw.WriteLine(mdblEndStock(index))
            tw.WriteLine(dblAverage(index))
            tw.WriteLine(dblTurnover(index))

        Next index
        'closing the streamwriter so it can be used again
        tw.Close()

    End Sub

    'subroutine for closing the document
    Private Sub CloseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseToolStripMenuItem.Click
        Close()
    End Sub

    'subroutine for printing the document
    Private Sub PrintToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintToolStripMenuItem.Click
        'definintions and constants go here
        Const ONE_INCH As Integer = 100
        Const LINE_HEIGHT As Integer = 10
        Dim gr As Graphics = e.Graphics
        Dim x1 As Integer = ONE_INCH
        Dim x2 As Integer = 3 * ONE_INCH
        Dim y As Integer = ONE_INCH
        'redefining the font
        Dim font As New Font("Courier New", 14, FontStyle.Bold)
        gr.DrawString("INVENTORY STATEMENT", font, Brushes.OrangeRed, x1 + 100, y)
        gr.DrawString("GUILIGAN TRADING, LLC.", font, Brushes.OrangeRed, x1 + 10, y + 40)
        gr.DrawString("308 COW TIPPING LANE, STILLWATER, OKLAHOMA 74074", font, Brushes.OrangeRed, x1 + 10, y + 60)
        'adding items
        y += ONE_INCH
        'defining a new font
        Dim font2 As New Font("Courier New", 12, FontStyle.Regular)
        'defining and index for the array
        Dim index As Integer
        'using an array to populate the print box
        For index = 0 To mstrID.GetUpperBound(0)
            gr.DrawString("Item: " & mstrModel(index), font, Brushes.Blue, x1, y + 50)
            font = New Font("courier New", 10, FontStyle.Regular)
            y += 6 * LINE_HEIGHT
            gr.DrawString("ID: " & mstrID(index), font, Brushes.Blue, x1, y)
            y += LINE_HEIGHT
            gr.DrawString("Cost: $" & mdblCost(index), font, Brushes.Blue, x1, y)
            y += LINE_HEIGHT
            gr.DrawString("BegStock: $" & mdblBegstock(index), font, Brushes.Blue, x1, y)
            y += LINE_HEIGHT
            gr.DrawString("EndStock: $" & mdblEndStock(index), font, Brushes.Blue, x1, y)
            y += LINE_HEIGHT
            gr.DrawString("Avg Inv: $" & dblAverage(index), font, Brushes.Blue, x1, y)
            y += LINE_HEIGHT
            gr.DrawString("Turnover: $" & dblTurnover(index), font, Brushes.Blue, x1, y)
            y += 400
            font = New Font("Courier New", 12, FontStyle.Bold)
            gr.DrawLine(Pens.CadetBlue, x1, y, x1 + 700, y)
        Next index
    End Sub

    'subroutine for a print preview
    Private Sub PrintPreviewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintPreviewToolStripMenuItem.Click
        PrintPreviewDialog1.Document.Print()
        PrintPreviewDialog1.ShowDialog()
    End Sub
End Class
