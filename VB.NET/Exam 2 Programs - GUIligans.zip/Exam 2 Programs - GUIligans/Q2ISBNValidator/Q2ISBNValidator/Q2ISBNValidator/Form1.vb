﻿Public Class Form1

 

    Private Sub btnValidate_Click(sender As System.Object, e As System.EventArgs) Handles btnValidate.Click


        'To make sure the ISBN number is only numeric values.
        Dim strISBN As String
        strISBN = txtISBN.Text

        Dim strCleanISBN As String = ""
        Dim index As Integer

        For index = 0 To strISBN.Length - 1

            If Char.IsDigit(strISBN.Substring(index, 1)) Or strISBN.Substring(index, 1).ToUpper = "X" Then
                strCleanISBN = strCleanISBN & strISBN.Substring(index, 1)
            End If

        Next

        Dim charArray() As Char

        charArray = strCleanISBN.ToCharArray

        For index = 0 To charArray.GetUpperBound(0)

            lblOutput.Text &= Val(charArray(index))
        Next

        'To make sure the length of the ISBN number is only ten digits.
        Dim len As Integer
        len = strCleanISBN.Length

        If len <> 10 Then

            MessageBox.Show("Invalid ISBN number")
            lblOutput.Text = ""
            txtISBN.Focus()
        End If

        Dim intArray(charArray.GetUpperBound(0)) As Integer

        For index = 0 To charArray.GetUpperBound(0)
            If IsNumeric(charArray(index)) Then
                intArray(index) = Val(charArray(index))
            Else
                intArray(index) = 10
            End If
        Next index

        Dim gap = intArray.Length
        Dim intTotal = 0

        For index = 0 To intArray.GetUpperBound(0)
            intTotal += (intArray(index) * gap)
            gap -= 1
        Next

        If (intTotal Mod 11 = 0) Then
            MessageBox.Show("your ISBN is valid!!!")
        Else
            MessageBox.Show("Invalid ISBN - Doesn't add up correctly")
        End If

    End Sub

End Class
