﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProblem4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtpCheckOut = New System.Windows.Forms.DateTimePicker()
        Me.dtpCheckIn = New System.Windows.Forms.DateTimePicker()
        Me.radNo = New System.Windows.Forms.RadioButton()
        Me.radYes = New System.Windows.Forms.RadioButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.grpInput2 = New System.Windows.Forms.GroupBox()
        Me.chkInternet = New System.Windows.Forms.CheckBox()
        Me.chkMiniBar = New System.Windows.Forms.CheckBox()
        Me.chkChannels = New System.Windows.Forms.CheckBox()
        Me.chkBreakfast = New System.Windows.Forms.CheckBox()
        Me.radTwoRoom = New System.Windows.Forms.RadioButton()
        Me.radTopFloor = New System.Windows.Forms.RadioButton()
        Me.radLuxury = New System.Windows.Forms.RadioButton()
        Me.radDeluxe = New System.Windows.Forms.RadioButton()
        Me.lstOutput = New System.Windows.Forms.ListBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpInput2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.dtpCheckOut)
        Me.GroupBox1.Controls.Add(Me.dtpCheckIn)
        Me.GroupBox1.Controls.Add(Me.radNo)
        Me.GroupBox1.Controls.Add(Me.radYes)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtName)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(2, 294)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(371, 159)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Input"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(156, 84)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(84, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Check Out Time"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(153, 19)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Check In Time"
        '
        'dtpCheckOut
        '
        Me.dtpCheckOut.Location = New System.Drawing.Point(153, 102)
        Me.dtpCheckOut.Name = "dtpCheckOut"
        Me.dtpCheckOut.Size = New System.Drawing.Size(196, 20)
        Me.dtpCheckOut.TabIndex = 8
        '
        'dtpCheckIn
        '
        Me.dtpCheckIn.Location = New System.Drawing.Point(153, 36)
        Me.dtpCheckIn.Name = "dtpCheckIn"
        Me.dtpCheckIn.Size = New System.Drawing.Size(199, 20)
        Me.dtpCheckIn.TabIndex = 7
        '
        'radNo
        '
        Me.radNo.AutoSize = True
        Me.radNo.Location = New System.Drawing.Point(13, 126)
        Me.radNo.Name = "radNo"
        Me.radNo.Size = New System.Drawing.Size(39, 17)
        Me.radNo.TabIndex = 6
        Me.radNo.TabStop = True
        Me.radNo.Text = "No"
        Me.radNo.UseVisualStyleBackColor = True
        '
        'radYes
        '
        Me.radYes.AutoSize = True
        Me.radYes.Location = New System.Drawing.Point(13, 102)
        Me.radYes.Name = "radYes"
        Me.radYes.Size = New System.Drawing.Size(43, 17)
        Me.radYes.TabIndex = 5
        Me.radYes.TabStop = True
        Me.radYes.Text = "Yes"
        Me.radYes.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 85)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(115, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "OU Student or Alumni?"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(13, 36)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Name:"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Problem2AaronKrauss.My.Resources.Resources.hotelPic
        Me.PictureBox1.Location = New System.Drawing.Point(3, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(380, 276)
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        '
        'grpInput2
        '
        Me.grpInput2.Controls.Add(Me.chkInternet)
        Me.grpInput2.Controls.Add(Me.chkMiniBar)
        Me.grpInput2.Controls.Add(Me.chkChannels)
        Me.grpInput2.Controls.Add(Me.chkBreakfast)
        Me.grpInput2.Controls.Add(Me.radTwoRoom)
        Me.grpInput2.Controls.Add(Me.radTopFloor)
        Me.grpInput2.Controls.Add(Me.radLuxury)
        Me.grpInput2.Controls.Add(Me.radDeluxe)
        Me.grpInput2.Location = New System.Drawing.Point(386, 294)
        Me.grpInput2.Name = "grpInput2"
        Me.grpInput2.Size = New System.Drawing.Size(288, 159)
        Me.grpInput2.TabIndex = 14
        Me.grpInput2.TabStop = False
        Me.grpInput2.Text = "Room Type + Extras"
        '
        'chkInternet
        '
        Me.chkInternet.AutoSize = True
        Me.chkInternet.Location = New System.Drawing.Point(128, 108)
        Me.chkInternet.Name = "chkInternet"
        Me.chkInternet.Size = New System.Drawing.Size(106, 17)
        Me.chkInternet.TabIndex = 7
        Me.chkInternet.Text = "Internet Services"
        Me.chkInternet.UseVisualStyleBackColor = True
        '
        'chkMiniBar
        '
        Me.chkMiniBar.AutoSize = True
        Me.chkMiniBar.Location = New System.Drawing.Point(128, 85)
        Me.chkMiniBar.Name = "chkMiniBar"
        Me.chkMiniBar.Size = New System.Drawing.Size(64, 17)
        Me.chkMiniBar.TabIndex = 6
        Me.chkMiniBar.Text = "Mini Bar"
        Me.chkMiniBar.UseVisualStyleBackColor = True
        '
        'chkChannels
        '
        Me.chkChannels.AutoSize = True
        Me.chkChannels.Location = New System.Drawing.Point(128, 60)
        Me.chkChannels.Name = "chkChannels"
        Me.chkChannels.Size = New System.Drawing.Size(145, 17)
        Me.chkChannels.TabIndex = 5
        Me.chkChannels.Text = "Premium Movie Channels"
        Me.chkChannels.UseVisualStyleBackColor = True
        '
        'chkBreakfast
        '
        Me.chkBreakfast.AutoSize = True
        Me.chkBreakfast.Location = New System.Drawing.Point(128, 36)
        Me.chkBreakfast.Name = "chkBreakfast"
        Me.chkBreakfast.Size = New System.Drawing.Size(141, 17)
        Me.chkBreakfast.TabIndex = 4
        Me.chkBreakfast.Text = "Room Service Breakfast"
        Me.chkBreakfast.UseVisualStyleBackColor = True
        '
        'radTwoRoom
        '
        Me.radTwoRoom.AutoSize = True
        Me.radTwoRoom.Location = New System.Drawing.Point(6, 108)
        Me.radTwoRoom.Name = "radTwoRoom"
        Me.radTwoRoom.Size = New System.Drawing.Size(104, 17)
        Me.radTwoRoom.TabIndex = 3
        Me.radTwoRoom.TabStop = True
        Me.radTwoRoom.Text = "Two Room Suite"
        Me.radTwoRoom.UseVisualStyleBackColor = True
        '
        'radTopFloor
        '
        Me.radTopFloor.AutoSize = True
        Me.radTopFloor.Location = New System.Drawing.Point(6, 84)
        Me.radTopFloor.Name = "radTopFloor"
        Me.radTopFloor.Size = New System.Drawing.Size(97, 17)
        Me.radTopFloor.TabIndex = 2
        Me.radTopFloor.TabStop = True
        Me.radTopFloor.Text = "Top Floor Suite"
        Me.radTopFloor.UseVisualStyleBackColor = True
        '
        'radLuxury
        '
        Me.radLuxury.AutoSize = True
        Me.radLuxury.Location = New System.Drawing.Point(6, 60)
        Me.radLuxury.Name = "radLuxury"
        Me.radLuxury.Size = New System.Drawing.Size(87, 17)
        Me.radLuxury.TabIndex = 1
        Me.radLuxury.TabStop = True
        Me.radLuxury.Text = "Luxury Room"
        Me.radLuxury.UseVisualStyleBackColor = True
        '
        'radDeluxe
        '
        Me.radDeluxe.AutoSize = True
        Me.radDeluxe.Location = New System.Drawing.Point(6, 36)
        Me.radDeluxe.Name = "radDeluxe"
        Me.radDeluxe.Size = New System.Drawing.Size(89, 17)
        Me.radDeluxe.TabIndex = 0
        Me.radDeluxe.TabStop = True
        Me.radDeluxe.Text = "Deluxe Room"
        Me.radDeluxe.UseVisualStyleBackColor = True
        '
        'lstOutput
        '
        Me.lstOutput.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstOutput.FormattingEnabled = True
        Me.lstOutput.ItemHeight = 14
        Me.lstOutput.Location = New System.Drawing.Point(402, 13)
        Me.lstOutput.Name = "lstOutput"
        Me.lstOutput.Size = New System.Drawing.Size(386, 270)
        Me.lstOutput.TabIndex = 15
        '
        'frmProblem4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(816, 501)
        Me.Controls.Add(Me.lstOutput)
        Me.Controls.Add(Me.grpInput2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmProblem4"
        Me.Text = "Roach Motel"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpInput2.ResumeLayout(False)
        Me.grpInput2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents radNo As System.Windows.Forms.RadioButton
    Friend WithEvents radYes As System.Windows.Forms.RadioButton
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dtpCheckOut As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpCheckIn As System.Windows.Forms.DateTimePicker
    Friend WithEvents grpInput2 As System.Windows.Forms.GroupBox
    Friend WithEvents chkInternet As System.Windows.Forms.CheckBox
    Friend WithEvents chkMiniBar As System.Windows.Forms.CheckBox
    Friend WithEvents chkChannels As System.Windows.Forms.CheckBox
    Friend WithEvents chkBreakfast As System.Windows.Forms.CheckBox
    Friend WithEvents radTwoRoom As System.Windows.Forms.RadioButton
    Friend WithEvents radTopFloor As System.Windows.Forms.RadioButton
    Friend WithEvents radLuxury As System.Windows.Forms.RadioButton
    Friend WithEvents radDeluxe As System.Windows.Forms.RadioButton
    Friend WithEvents lstOutput As System.Windows.Forms.ListBox

End Class
