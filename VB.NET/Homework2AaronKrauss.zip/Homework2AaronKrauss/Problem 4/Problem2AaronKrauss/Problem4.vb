﻿Public Class frmProblem4
    'Aaron Krauss ID: 112-71-2284
    'This is the code for Problem 4 on HW 2

    'form level variable for the number of breakfasts the user has eaten
    Private pintNumBreakfasts As Integer = 0

    'declares constants used through the rest of the program
    Const TAXRATE = 0.0825
    Const OUDISCOUNT = 0.15
    'room prices
    Const DELUXEPRICE As Double = 50.0
    Const LUXURYPRICE As Double = 85.0
    Const TOPFLOORPRICE As Double = 150.0
    Const TWOROOMPRICE As Double = 200.0
    'Additional amenities' prices
    Const BREAKFASTPRICE As Double = 13.99
    Const MOVIEPRICE As Double = 9.99
    Const MINIBARPRICE As Double = 20.99
    Const INTERNETPRICE As Double = 7.99


    Private Sub displayOutput()
        'key method which runs everytime something is changed

        'checks if user forgot to click a type of room
        If (radDeluxe.Checked = False And radLuxury.Checked = False And _
            radTopFloor.Checked = False And radTwoRoom.Checked = False) Then
            MessageBox.Show("You must pick a type of room to reserve!", "Forgot Room type")
            Exit Sub
        End If

        'clears current output list in order to display a new one
        lstOutput.Items.Clear()

        Dim strName As String
        Dim intNumNights As Integer
        Dim dtmCheckIn, dtmCheckout As DateTime
        Dim blnOU As Boolean
        Dim dblSubtotal As Double = 0
        Dim dblTaxes As Double
        Dim dblTotal As Double
        Dim strFormat As String = "{0,-35}{1,-10}"
        Dim strOUStudent As String = "No"
        Dim dblDiscountAmt As Double = 0

        'delcare variables to be passed ByRef to sub functions
        Dim strRoomType As String
        Dim dblRoomCost As Double
        Dim dblBreakfastCost, dblMovieCost, dblMiniBarCost, dblInternetCost As Double

        'gets checkin/checkout times
        strName = txtName.Text
        dtmCheckIn = dtpCheckIn.Value.Date
        dtmCheckout = dtpCheckOut.Value.Date

        intNumNights = DateDiff(DateInterval.Day, dtmCheckIn, dtmCheckout)

        'check to see if there is a discount
        If radYes.Checked Then
            blnOU = True
            strOUStudent = "Yes"
        Else
            blnOU = False
        End If

        'created function to calculate the room rate
        dblSubtotal += calculateRoomRate(intNumNights, strRoomType, dblRoomCost)

        'created function to calculate the extras
        dblSubtotal += calculateExtras(intNumNights, dblBreakfastCost, dblMovieCost, dblMiniBarCost, dblInternetCost)

        'if OU student, then adjust the discount and the subtotal
        If blnOU Then
            dblDiscountAmt = dblSubtotal * 0.15 * -1
            dblSubtotal += dblDiscountAmt
        End If

        dblTaxes = dblSubtotal * TAXRATE

        dblTotal = dblSubtotal + dblTaxes

        'display output
        lstOutput.Items.Add(String.Format(strFormat, "Name:", strName))
        lstOutput.Items.Add(String.Format(strFormat, "OU Student:", strOUStudent))
        lstOutput.Items.Add(String.Format(strFormat, "Number of Nights", intNumNights))
        lstOutput.Items.Add(String.Format(strFormat, "Room Type:", strRoomType))
        lstOutput.Items.Add(String.Format(strFormat, "Room Cost:", FormatCurrency(dblRoomCost * intNumNights, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Room Service Breakfast Cost:", FormatCurrency(dblBreakfastCost, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Premium Movie Channels Cost:", FormatCurrency(dblMovieCost, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Mini Bar Cost:", FormatCurrency(dblMiniBarCost, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Internet Services Cost:", FormatCurrency(dblInternetCost, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "OU Student Discount:", FormatCurrency(dblDiscountAmt, 2)))
        lstOutput.Items.Add("********************")
        lstOutput.Items.Add(String.Format(strFormat, "Subtotal:", FormatCurrency(dblSubtotal, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Taxes:", FormatCurrency(dblTaxes, 2)))
        lstOutput.Items.Add("********************")
        lstOutput.Items.Add(String.Format(strFormat, "Grand Total:", FormatCurrency(dblTotal, 2)))

    End Sub

    Private Function calculateRoomRate(ByVal intNights As Integer, ByRef strType As String, ByRef dblCost As Double) As Double
        'Function to calculate room type and cost

        Dim dblRoomTotal As Double = 0.0

        'determines the room total, and sets the byref variables strType and dblCost accordingly
        If (radTwoRoom.Checked = True) Then
            dblRoomTotal += (intNights * TWOROOMPRICE)
            strType = "Two Room Suite"
            dblCost = TWOROOMPRICE

        ElseIf (radTopFloor.Checked = True) Then
            dblRoomTotal += (intNights * TOPFLOORPRICE)
            strType = "Top Floor Suite"
            dblCost = TOPFLOORPRICE

        ElseIf (radLuxury.Checked = True) Then
            dblRoomTotal += (intNights * LUXURYPRICE)
            strType = "Luxury Room"
            dblCost = LUXURYPRICE

        Else
            dblRoomTotal += (intNights * DELUXEPRICE)
            strType = "Deluxe Room"
            dblCost = DELUXEPRICE
        End If

        Return dblRoomTotal

    End Function

    Private Function calculateExtras(ByVal intNights As Integer, ByRef dblBreakfast As Double, _
                                     ByRef dblMovie As Double, ByRef dblMiniBar As Double, _
                                     ByRef dblInternet As Double) As Double
        'Function to calculate total costs of extra amenities

        Dim dblExtrasTotal As Double = 0.0

        'determines the totals for the checked boxes, along with setting the byref variables
        If (chkBreakfast.Checked = True) Then
            dblBreakfast += (pintNumBreakfasts * BREAKFASTPRICE)
            dblExtrasTotal += dblBreakfast
        End If

        If (chkChannels.Checked = True) Then
            'this cost is on a per-night basis
            dblMovie += (MOVIEPRICE * intNights)
            dblExtrasTotal += dblMovie
        End If

        If (chkMiniBar.Checked = True) Then
            dblMiniBar += MINIBARPRICE
            dblExtrasTotal += dblMiniBar
        End If

        If (chkInternet.Checked = True) Then
            'this cost is on a per-night basis
            dblInternet += (INTERNETPRICE * intNights)
            dblExtrasTotal += dblInternet
        End If

        Return dblExtrasTotal

    End Function

    Private Sub frmProblem2_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        'message box to make sure that you meant to exit
        Dim intResp As Int32
        intResp = MessageBox.Show("Did you mean to exit?", "Closing Form", MessageBoxButtons.YesNo, _
                                  MessageBoxIcon.Question)
        If intResp = vbNo Then
            e.Cancel = True
        Else
            End
        End If
    End Sub

    Private Sub frmProblem2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'sets default check out dates and sets focus to name text box
        dtpCheckIn.Value = Now
        dtpCheckOut.Value = dtpCheckIn.Value.AddDays(1)
        txtName.Focus()

    End Sub

    Private Sub chkBreakfast_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkBreakfast.CheckedChanged
        If (chkBreakfast.Checked = True) Then

            'gathers info to see if the total days is more than 1
            Dim intNumNights As Integer
            Dim dtmCheckIn, dtmCheckout As DateTime
            Dim strInputAnswer As String

            dtmCheckIn = dtpCheckIn.Value.Date
            dtmCheckout = dtpCheckOut.Value.Date

            intNumNights = DateDiff(DateInterval.Day, dtmCheckIn, dtmCheckout)

            'if days are more than 1, then the program asks user how many breakfasts the client ate
            If (intNumNights > 1) Then

                'I use a string in case the user enters a non-numerical value
                strInputAnswer = InputBox("How many breakfasts did you order?", "Room Service Breakfast Count")

                'if the answer is non-numerical, then exit
                If Not IsNumeric(strInputAnswer) Then
                    MessageBox.Show("Please Enter a valid number number for breakfasts", "Error")
                    chkBreakfast.Checked = False
                    Exit Sub

                    'now that we have determined that it is numerical, if it is negative, then exit
                ElseIf CDbl(strInputAnswer) < 0 Then
                    MessageBox.Show("Please Enter a valid number number for breakfasts", "Error")
                    chkBreakfast.Checked = False
                    Exit Sub
                Else
                    'finally sets the form level variable equal to the number of breakfasts, after much error checking
                    pintNumBreakfasts = CDbl(strInputAnswer)
                End If
            ElseIf (intNumNights = 1) Then
                'based on Mano's Homework 2 document, if it is just one night, then we can assume that 1 breakfast was ordered if this option is checked
                pintNumBreakfasts = 1
            End If

        Else
            'if the check box is unselected, then there will be no desired breakfasts
            pintNumBreakfasts = 0
        End If

        displayOutput()

    End Sub

    Private Sub dtpCheckIn_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpCheckIn.ValueChanged

        'changes the check out time to 1 + the current date, and also deselects breakfast checkbox
        dtpCheckOut.Value = dtpCheckIn.Value.AddDays(1)

        'unchecks the breakfast checkbox so that the user can enter a new number of breakfasts
        chkBreakfast.Checked = False

        'only activates the main function if a room type has been selected
        If Not (radDeluxe.Checked = False And radLuxury.Checked = False And _
            radTopFloor.Checked = False And radTwoRoom.Checked = False) Then
            displayOutput()
        End If

    End Sub

    Private Sub dtpCheckOut_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpCheckOut.ValueChanged

        'checks if user entered an invalid checkout time
        If dtpCheckIn.Value.Date >= dtpCheckOut.Value.Date Then
            MessageBox.Show("You can't check out before you ever check in!", "Duration Error")
            'disables the input group box until the user enters a valid checkout date
            grpInput2.Enabled = False
            radYes.Enabled = False
            radNo.Enabled = False
            Exit Sub
        Else
            grpInput2.Enabled = True
            'unchecks the breakfast checkbox so that the user can enter a new number of breakfasts
            chkBreakfast.Checked = False
            radYes.Enabled = True
            radNo.Enabled = True
        End If

        'only activates the main function if a room type has been selected
        If Not (radDeluxe.Checked = False And radLuxury.Checked = False And _
            radTopFloor.Checked = False And radTwoRoom.Checked = False) Then
            displayOutput()
        End If

    End Sub

    Private Sub radDeluxe_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radDeluxe.CheckedChanged
        displayOutput()
    End Sub

    Private Sub radLuxury_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radLuxury.CheckedChanged
        displayOutput()
    End Sub

    Private Sub radTopFloor_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radTopFloor.CheckedChanged
        displayOutput()
    End Sub

    Private Sub radTwoRoom_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radTwoRoom.CheckedChanged
        displayOutput()
    End Sub

    Private Sub chkChannels_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkChannels.CheckedChanged
        displayOutput()
    End Sub

    Private Sub chkMiniBar_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkMiniBar.CheckedChanged
        displayOutput()
    End Sub

    Private Sub chkInternet_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkInternet.CheckedChanged
        displayOutput()
    End Sub

    Private Sub txtName_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtName.Validating
        'checks if user forgot his/her name
        If txtName.Text = "" Then
            MessageBox.Show("Please enter your name", "Forgot Name")
            txtName.Focus()
            Exit Sub
        End If

        'only activates the main function if a room type has been selected
        If Not (radDeluxe.Checked = False And radLuxury.Checked = False And _
            radTopFloor.Checked = False And radTwoRoom.Checked = False) Then
            displayOutput()
        End If
    End Sub

    Private Sub radYes_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radYes.CheckedChanged

        'only activates the main function if a room type has been selected
        If Not (radDeluxe.Checked = False And radLuxury.Checked = False And _
             radTopFloor.Checked = False And radTwoRoom.Checked = False) Then
            displayOutput()
        End If

    End Sub

    Private Sub radNo_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radNo.CheckedChanged

        'only activates the main function if a room type has been selected
        If Not (radDeluxe.Checked = False And radLuxury.Checked = False And _
            radTopFloor.Checked = False And radTwoRoom.Checked = False) Then
            displayOutput()
        End If

    End Sub
End Class
