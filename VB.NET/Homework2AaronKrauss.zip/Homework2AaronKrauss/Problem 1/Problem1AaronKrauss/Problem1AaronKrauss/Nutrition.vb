﻿Public Class frmProblem1

    'Aaron Krauss
    'ID# 112-71-2284
    'This is problem 1 for homework 2

    Const FATCALSPERGRAM As Integer = 9
    Const SUGGESTEDPERCENTAGE As Double = 0.3

    Private Function calculateFatCalories(ByVal dblGrams As Double) As Double

        'returns the total fat calories for the food
        Return (dblGrams * FATCALSPERGRAM)

    End Function

    Private Function calculateFatPercent(ByVal dblTotalCals As Double, ByVal dblFatCals As Double) As Double

        'returns the total percentage of fat to calories in the food
        Return (dblFatCals / dblTotalCals)

    End Function

    Private Function meetsOrExceeds(ByVal dblFatPerc As Double) As Boolean

        'determines if the percentage meets or exceeds the AHA recommendation
        If (dblFatPerc > SUGGESTEDPERCENTAGE) Then
            Return True
        Else
            Return False
        End If

    End Function

    Private Sub displayOutput(ByVal blnExceeds As Boolean, ByVal dblFatPercentage As Double)

        'displays the total percentage of fat
        lstOutput.Items.Add(FormatPercent(dblFatPercentage, 2) & " calories from fat")

        'displays whether it meets or exceeds the AHA recommendation
        If blnExceeds Then
            lstOutput.Items.Add("exceeds AHA recommendation")
        Else
            lstOutput.Items.Add("satisfies AHA recommendation")
        End If

    End Sub

    Private Sub btnCompute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCompute.Click

        'makes sure that no text boxes were left blank
        If txtName.Text = "" Then
            MessageBox.Show("Please enter a name", "Forgot Name")
            Exit Sub
        End If

        If txtCalories.Text = "" Then
            MessageBox.Show("Please enter total calories", "Forgot Calories")
            Exit Sub
        End If

        If txtGrams.Text = "" Then
            MessageBox.Show("Please enter total grams of fat", "Forgot Grams of Fat")
            Exit Sub
        End If

        'variable declarations
        Dim dblCalories As Double
        Dim dblGramsFat As Double
        Dim dblFatCalories As Double
        Dim dblFatPercentage As Double
        Dim blnExceeds As Boolean = False

        lstOutput.Items.Clear()

        'gather initial info from text boxes
        dblCalories = CDbl(txtCalories.Text)
        dblGramsFat = CDbl(txtGrams.Text)

        'call function to calculate fat calories
        dblFatCalories = calculateFatCalories(dblGramsFat)

        'call function to calculate fat percentage
        dblFatPercentage = calculateFatPercent(dblCalories, dblFatCalories)

        'call function to determine if the percentage meets or exceeds the AHA recommendation
        blnExceeds = meetsOrExceeds(dblFatPercentage)

        'call sub to display output
        displayOutput(blnExceeds, dblFatPercentage)

    End Sub

    Private Sub txtCalories_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtCalories.Validating

        'checks to see if the txtbox is an invalid numerical value
        If txtCalories.Text = "" Then
            Exit Sub
        ElseIf Not IsNumeric(txtCalories.Text) Then
            MessageBox.Show("Please enter a valid numerical value", "Error - Non-Numerical Value")
            txtCalories.Focus()
            txtCalories.SelectAll()
        ElseIf Val(txtCalories.Text) < 0 Then
            MessageBox.Show("Please enter a non-negative numerical value", "Error - Negative Value")
            txtCalories.Focus()
            txtCalories.SelectAll()
        End If
    End Sub

    Private Sub txtGrams_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtGrams.Validating

        'checks to see if the txtbox is an invalid numerical value
        If txtGrams.Text = "" Then
            Exit Sub
        ElseIf Not IsNumeric(txtGrams.Text) Then
            MessageBox.Show("Please enter a valid numerical value", "Error - Non-Numerical Value")
            txtGrams.Focus()
            txtGrams.SelectAll()
        ElseIf Val(txtGrams.Text) < 0 Then
            MessageBox.Show("Please enter a non-negative numerical value", "Error - Negative Value")
            txtGrams.Focus()
            txtGrams.SelectAll()
        End If
    End Sub

    Private Sub txtName_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtName.Validating

        'checks to see if the txtbox is an invalid name value
        If txtName.Text = "" Then
            Exit Sub
        ElseIf IsNumeric(txtName.Text) Then
            MessageBox.Show("Please enter a valid name", "Error - Non-Acceptable Food Name")
            txtName.Focus()
            txtName.SelectAll()
        End If

    End Sub
End Class
