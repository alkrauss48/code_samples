﻿Public Class frmProblem2

    'Aaron Krauss
    'ID# 112-71-2284
    'This program is the answer to problem 2 in Homework 2

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click

        'makes sure that the user enters in a value before the calculate sub runs
        If (txtInput.Text = "") Then
            MessageBox.Show("Please enter a value for taxable income", "Forgot to Enter Income")
            Exit Sub
        End If

        Dim dblTaxableIncome, dblFederalTax As Double

        'gathers input value
        dblTaxableIncome = CDbl(txtInput.Text)

        'determines the federal tax based on income, which is sent to a function below
        dblFederalTax = calculateFederFedalTax(dblTaxableIncome)

        lblOutput.Text = dblFederalTax.ToString("C2")

    End Sub

    Private Function calculateFederFedalTax(ByVal dblInput As Double) As Double
        'this function takes in a user's taxable income and then returns their federal income tax based
        'on their income

        Dim dblFedTax As Double

        'sets federal tax equal to a certain value depending on how much it is
        Select Case dblInput

            Case 0 To 8025
                dblFedTax = dblInput * 0.1
            Case 8025 To 32550
                dblFedTax = 802.5 + ((dblInput - 8025) * 0.15)
            Case 32550 To 78850
                dblFedTax = 4481.25 + ((dblInput - 32550) * 0.25)
            Case 78850 To 164550
                dblFedTax = 16056.25 + ((dblInput - 78850) * 0.28)
            Case 164550 To 357700
                dblFedTax = 40052.25 + ((dblInput - 164550) * 0.33)
            Case Is > 357700
                dblFedTax = 103791.75 + ((dblInput - 357700) * 0.35)

        End Select

        Return dblFedTax

    End Function

    Private Sub txtInput_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtInput.Validating
        'checks to see if the user has entered anything, and if not, then it exits the sub
        If txtInput.Text = "" Then
            Exit Sub
        End If

        'checks to see if the user entered a negative value
        If Val(txtInput.Text) < 0 Then
            MessageBox.Show("Please enter a valid taxable income", "Error-Negative Value")
            txtInput.Focus()
            txtInput.SelectAll()
            Exit Sub
        End If

        'checks to see if the user entered a non-numerical value
        If Not IsNumeric(txtInput.Text) Then
            MessageBox.Show("Please enter a valid numerical value for taxable income", "Error")
            txtInput.Focus()
            txtInput.SelectAll()
        End If

    End Sub

    Private Sub txtClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtClear.Click
        'clears out the input text box and the output label
        txtInput.Clear()
        lblOutput.Text = ""
    End Sub
End Class
