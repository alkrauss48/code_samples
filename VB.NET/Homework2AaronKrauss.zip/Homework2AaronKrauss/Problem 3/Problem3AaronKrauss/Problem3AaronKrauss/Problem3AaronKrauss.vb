﻿Public Class frmProblem3

    'Aaron Krauss ID# 112-71-2284
    'this is program 3 for Homework 2

    'declare form-level constants
    Const PIZZACOST As Double = 1.75
    Const FRIESCOST As Double = 2.0
    Const DRINKCOST As Double = 1.25

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click

        'if any fields are left blank, an error message pops up and then exits the sub
        If (txtPizzas.Text = "" Or txtDrinks.Text = "" Or txtFries.Text = "") Then
            MessageBox.Show("Please enter all required values before computing your total cost", "Not All Fields Filled In")
            Exit Sub
        End If

        'local variable declarations
        Dim intNumPizzas, intNumFries, intNumDrinks As Integer
        Dim dblTotPizzaCost, dblTotFriesCost, dblTotDrinkCost As Double
        Dim dblTotal As Double

        'pass variables byref to sub in order to set their values equal to the text boxes
        gatherAmounts(intNumPizzas, intNumFries, intNumDrinks)

        'gather total from function which takes in the number of items (byval) and will set their individual total costs (byref)
        dblTotal = getTotal(intNumPizzas, intNumFries, intNumDrinks, dblTotPizzaCost, dblTotFriesCost, dblTotDrinkCost)

        'displays data via sub which takes in total number of items, their individual costs, and a grand total (all byval)
        displayOutput(intNumPizzas, intNumFries, intNumDrinks, dblTotPizzaCost, dblTotFriesCost, dblTotDrinkCost, dblTotal)

    End Sub

    Private Sub gatherAmounts(ByRef intPizzas As Integer, ByRef intFries As Integer, ByRef intDrinks As Integer)

        'sets all byref variables equal to their respective text boxes
        intPizzas = CInt(txtPizzas.Text)
        intFries = CInt(txtFries.Text)
        intDrinks = CInt(txtDrinks.Text)

    End Sub

    Private Function getTotal(ByVal intPizzas As Integer, ByVal intFries As Integer, ByVal intDrinks As Integer, _
                              ByRef dblPizzaCost As Double, ByRef dblFriesCost As Double, ByRef dblDrinkCost As Double) As Double

        Dim dblTotalPayment As Double

        'sets the individual costs, which are passed byref
        dblPizzaCost = intPizzas * PIZZACOST
        dblFriesCost = intFries * FRIESCOST
        dblDrinkCost = intDrinks * DRINKCOST

        'adds together all the individual costs in order to gather a grand total
        dblTotalPayment = dblPizzaCost + dblFriesCost + dblDrinkCost

        'returns total to main event
        Return dblTotalPayment

    End Function

    Private Sub displayOutput(ByVal intPizzas As Integer, ByVal intFries As Integer, ByVal intDrinks As Integer, _
                              ByVal dblPizzaCost As Double, ByVal dblFriesCost As Double, ByVal dblDrinkCost As Double, ByVal dblGrandTotal As Double)

        'format for listbox
        Dim strFormat As String = "{0,-15}{1,-10}{2,-10}"

        'clears the listbox before updating it
        lstOutput.Items.Clear()

        'updates list box with required information, with all monetary values in the proper format
        lstOutput.Items.Add(String.Format(strFormat, "ITEM", "QUANTITY", "PRICE"))
        lstOutput.Items.Add(String.Format(strFormat, "Pizza Slices:", intPizzas, dblPizzaCost.ToString("C2")))
        lstOutput.Items.Add(String.Format(strFormat, "Fries:", intFries, dblFriesCost.ToString("C2")))
        lstOutput.Items.Add(String.Format(strFormat, "Soft Drinks:", intDrinks, dblDrinkCost.ToString("C2")))
        lstOutput.Items.Add(String.Format(strFormat, "TOTAL:", "", dblGrandTotal.ToString("C2")))

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click

        'clears out all text boxes and listbox
        txtPizzas.Clear()
        txtFries.Clear()
        txtDrinks.Clear()
        lstOutput.Items.Clear()

    End Sub


    Private Sub txtPizzas_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtPizzas.Validating

        'checks to see if the txtbox is an invalid numerical value
        If txtPizzas.Text = "" Then
            Exit Sub
        ElseIf Not IsNumeric(txtPizzas.Text) Then
            MessageBox.Show("Please enter a valid numerical value", "Error - Non-Numerical Value")
            txtPizzas.Focus()
            txtPizzas.SelectAll()
        ElseIf Val(txtPizzas.Text) < 0 Then
            MessageBox.Show("Please enter a non-negative numerical value", "Error - Negative Value")
            txtPizzas.Focus()
            txtPizzas.SelectAll()
        End If

    End Sub

    Private Sub txtFries_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtFries.Validating

        'checks to see if the txtbox is an invalid numerical value
        If txtFries.Text = "" Then
            Exit Sub
        ElseIf Not IsNumeric(txtFries.Text) Then
            MessageBox.Show("Please enter a valid numerical value", "Error - Non-Numerical Value")
            txtFries.Focus()
            txtFries.SelectAll()
        ElseIf Val(txtFries.Text) < 0 Then
            MessageBox.Show("Please enter a non-negative numerical value", "Error - Negative Value")
            txtFries.Focus()
            txtFries.SelectAll()
        End If

    End Sub

    Private Sub txtDrinks_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtDrinks.Validating

        'checks to see if the txtbox is an invalid numerical value
        If txtDrinks.Text = "" Then
            Exit Sub
        ElseIf Not IsNumeric(txtDrinks.Text) Then
            MessageBox.Show("Please enter a valid numerical value", "Error - Non-Numerical Value")
            txtDrinks.Focus()
            txtDrinks.SelectAll()
        ElseIf Val(txtDrinks.Text) < 0 Then
            MessageBox.Show("Please enter a non-negative numerical value", "Error - Negative Value")
            txtDrinks.Focus()
            txtDrinks.SelectAll()
        End If

    End Sub
End Class
