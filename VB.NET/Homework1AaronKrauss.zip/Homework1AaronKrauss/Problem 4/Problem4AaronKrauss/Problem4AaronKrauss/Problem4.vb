﻿Public Class frmProblem4
    'Aaron Krauss ID# 112-71-2284
    'this program is the answer to problem 4 on HW 1

    Const WEIGHT1 As Double = 0.35

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Dim intResp As Int32
        intResp = MessageBox.Show("Did you mean to exit?", "Closing Form", MessageBoxButtons.YesNo, _
                                  MessageBoxIcon.Question)
        If intResp = vbNo Then
            Exit Sub
        Else
            MessageBox.Show("Bye Bye baby", "End Application")
            End
        End If
    End Sub

    Private Sub frmProblem4_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim intResp As Int32
        intResp = MessageBox.Show("Did you mean to exit?", "Closing Form", MessageBoxButtons.YesNo, _
                                  MessageBoxIcon.Question)
        If intResp = vbNo Then
            e.Cancel = True
        Else
            MessageBox.Show("Bye Bye baby", "End Application")
            e.Cancel = False
            End
        End If
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        lstOutput.Items.Clear()

    End Sub

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        Dim strName As String
        Dim dblExam1, dblExam2 As Double
        Dim dblWeightedAvg As Double
        Dim strDecision As String
        Dim fmtStr As String

        fmtStr = "{0,-25}{1,-10}{2,-10}{3,-20}{4,-10}"

        Dim sr As IO.StreamReader
        sr = IO.File.OpenText("Problem4File.txt")

        lstOutput.Items.Add(sr.ReadLine)
        lstOutput.Items.Add(String.Format(fmtStr, "Name", "Exam 1", "Exam 2", "Weighted Avg", "Admitted/Rejected"))
        sr.ReadLine()
        sr.ReadLine()

        While sr.Peek <> -1
            strName = sr.ReadLine
            dblExam1 = Val(sr.ReadLine)
            dblExam2 = Val(sr.ReadLine)
            dblWeightedAvg = (dblExam1 * WEIGHT1) + (dblExam2 * (1 - WEIGHT1))
            If dblWeightedAvg >= 75 Then
                strDecision = "Admitted"
            Else
                strDecision = "Rejected"
            End If

            lstOutput.Items.Add(String.Format(fmtStr, strName, dblExam1, dblExam2, dblWeightedAvg, strDecision))

        End While
    End Sub
End Class
