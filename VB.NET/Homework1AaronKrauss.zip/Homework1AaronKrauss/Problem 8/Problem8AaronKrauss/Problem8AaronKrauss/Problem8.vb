﻿Public Class frmProblem8
    Const BILLRATE As Double = 35
    Const TAXRATE As Double = 0.05

    Private Sub btnDisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisplay.Click

        Dim fmtStr1 As String = "{0,-25}{1,-10}"
        Dim strName As String
        Dim dblHours As Double
        Dim dblLaborCost As Double
        Dim dblPartsCost As Double
        Dim dblTotalCost As Double

        strName = txtName.Text
        dblHours = CDbl(txtHours.Text)
        dblPartsCost = CDbl(txtCost.Text)
        dblPartsCost *= (1 + TAXRATE)

        dblLaborCost = dblHours * BILLRATE

        dblTotalCost = dblLaborCost + dblPartsCost

        lstOutput.Items.Add(String.Format(fmtStr1, "Customer", strName))
        lstOutput.Items.Add(String.Format(fmtStr1, "Labor Cost", dblLaborCost.ToString("C2")))
        lstOutput.Items.Add(String.Format(fmtStr1, "Parts Cost", dblPartsCost.ToString("C2")))
        lstOutput.Items.Add(String.Format(fmtStr1, "Total Cost", dblTotalCost.ToString("C2")))

    End Sub
End Class
