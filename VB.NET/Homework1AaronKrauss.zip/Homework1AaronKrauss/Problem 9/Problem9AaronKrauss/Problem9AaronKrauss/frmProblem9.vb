﻿Public Class frmConversion
    'Aaron Krauss ID# 112-71-2284
    'this program is for problem 9 on HW 1 and #4 in the book on page 100

    Private Sub btnConvert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConvert.Click
        Dim dblMiles As Double
        Dim dblYards As Double
        Dim dblFeet As Double
        Dim dblInches As Double

        Dim dblKilometers As Double
        Dim dblMeters As Double
        Dim dblCentimeters As Double

        Dim dblTotalInches As Double

        dblMiles = CDbl(txtMiles.Text)
        dblYards = CDbl(txtYards.Text)
        dblFeet = CDbl(txtFeet.Text)
        dblInches = CDbl(txtInches.Text)

        dblTotalInches = (63360 * dblMiles) + (36 * dblYards) + (12 * dblFeet) + dblInches
        dblMeters = dblTotalInches / 39.37
        dblKilometers = Int(dblMeters / 1000)

        dblCentimeters = (dblMeters - Int(dblMeters)) * 100
        dblMeters = Int(Int(dblMeters) - (dblKilometers * 1000))

        lblDisplay.Text = String.Format("The metric length is" & _
                                        Environment.NewLine & "{0} kilometers" & _
                                        Environment.NewLine & "{1} meters" & _
                                        Environment.NewLine & "{2} centimeters." _
                                        , dblKilometers, dblMeters, Math.Round(dblCentimeters, 1))


    End Sub
End Class
