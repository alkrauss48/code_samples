﻿Public Class frmProblem2
    'Aaron Krauss ID: 112-71-2284
    'This is the code for Problem 2 on HW 1

    Const TAXRATE = 0.0825
    Const OUDISCOUNT = 0.15
    Const DAILYPRICE = 45

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtName.Clear()
        txtNights.Clear()
        radYes.Checked = False
        radNo.Checked = False
        lblName.Text = ""
        lblSubtotal.Text = "$0.00"
        lblTaxes.Text = "$0.00"
        lblTotal.Text = "$0.00"

    End Sub

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click

        If txtName.Text = "" Then
            MessageBox.Show("Please enter your name", "Forgot Name")
            Exit Sub
        ElseIf txtNights.Text = "" Then
            MessageBox.Show("Please enter the number of nights you will be staying", "Forgot Number of Nights")
            Exit Sub
        End If

        Dim strName As String
        Dim intNumNights As Integer
        Dim blnOU As Boolean
        Dim dblSubtotal As Double
        Dim dblTaxes As Double
        Dim dblTotal As Double

        strName = txtName.Text
        intNumNights = Val(txtNights.Text)

        If radYes.Checked Then
            blnOU = True
        Else
            blnOU = False
        End If

        lblName.Text = strName

        If blnOU = True Then
            dblSubtotal = (intNumNights * DAILYPRICE) * (1 - OUDISCOUNT)
        Else
            dblSubtotal = (intNumNights * DAILYPRICE)
        End If

        lblSubtotal.Text = dblSubtotal.ToString("C2")

        dblTaxes = dblSubtotal * TAXRATE
        lblTaxes.Text = dblTaxes.ToString("C2")

        dblTotal = dblSubtotal + dblTaxes
        lblTotal.Text = dblTotal.ToString("C2")

    End Sub

    Private Sub txtNights_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtNights.Leave
        If txtNights.Text = "" Then
            Exit Sub
        End If

        If Val(txtNights.Text) < 0 Then
            MessageBox.Show("Please enter a valid amount of days", "Error-Negative Value")
            txtNights.Focus()
            txtNights.SelectAll()
            Exit Sub
        End If

        If Not IsNumeric(txtNights.Text) Then
            MessageBox.Show("Please enter a valid numerical amount of days", "Error")
            txtNights.Focus()
            txtNights.SelectAll()
        End If
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Dim intResp As Int32
        intResp = MessageBox.Show("Did you mean to exit?", "Closing Form", MessageBoxButtons.YesNo, _
                                  MessageBoxIcon.Question)
        If intResp = vbNo Then
            Exit Sub
        Else
            MessageBox.Show("Bye Bye baby", "End Application")
            End
        End If
    End Sub

    Private Sub frmProblem2_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim intResp As Int32
        intResp = MessageBox.Show("Did you mean to exit?", "Closing Form", MessageBoxButtons.YesNo, _
                                  MessageBoxIcon.Question)
        If intResp = vbNo Then
            e.Cancel = True
        Else
            MessageBox.Show("Bye Bye baby", "End Application")
            End
        End If
    End Sub
End Class
