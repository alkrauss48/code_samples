﻿Public Class frmTrafficLight
    'Aaron Krauss ID# 112-71-2284
    'this program is problem 6 on HW 1 and #40 on page 51 in the book
    
    Private Sub frmTrafficLight_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtGreen.Focus()

    End Sub

    Private Sub txtGreen_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtGreen.GotFocus
        txtGreen.BackColor = Color.Green
        txtRed.BackColor = Color.DarkGray
        txtYellow.BackColor = Color.DarkGray
    End Sub

    Private Sub txtYellow_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtYellow.GotFocus
        txtGreen.BackColor = Color.DarkGray
        txtRed.BackColor = Color.DarkGray
        txtYellow.BackColor = Color.Yellow
    End Sub

    Private Sub txtRed_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRed.GotFocus
        txtGreen.BackColor = Color.DarkGray
        txtRed.BackColor = Color.Red
        txtYellow.BackColor = Color.DarkGray
    End Sub
End Class
