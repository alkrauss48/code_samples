﻿Public Class frmProblem1
    'Aaron Krauss ID: 112-71-2284
    'This program answers Question 1 on HW 1

    Const WIDGETWEIGHT = 9.2
    Const WIDGETPRICE = 2.25

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click

        Dim dblWeightAlone As Double
        Dim dblWeightTogether As Double
        Dim intTotalWidgets As Integer
        Dim dblPrice As Double

        If txtPallet.Text = "" Then
            MessageBox.Show("Please enter a value for the weight of the pallet", "Forgot Pallet Weight")
            Exit Sub
        ElseIf txtTotalWeight.Text = "" Then
            MessageBox.Show("Please enter a value for the weight of the pallet and widgets together" _
                            , "Forgot Pallet Weight")
            Exit Sub
        End If

        dblWeightAlone = CDbl(txtPallet.Text)
        dblWeightTogether = CDbl(txtTotalWeight.Text)

        intTotalWidgets = (dblWeightTogether - dblWeightAlone) / WIDGETWEIGHT

        dblPrice = CDbl(intTotalWidgets) * WIDGETPRICE

        lblWidgets.Text = intTotalWidgets
        lblPrice.Text = dblPrice.ToString("C2")

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click

        txtPallet.Clear()
        txtTotalWeight.Clear()
        lblWidgets.Text = "0"
        lblPrice.Text = "$0.00"

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Dim intResp As Int32
        intResp = MessageBox.Show("Did you mean to exit?", "Closing Form", MessageBoxButtons.YesNo, _
                                  MessageBoxIcon.Question)
        If intResp = vbNo Then
            Exit Sub
        Else
            MessageBox.Show("Bye Bye baby", "End Application")
            End
        End If
    End Sub

    Private Sub txtPallet_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtPallet.Validating
        'checks to see if the txtbox is an invalid numerical value
        If txtPallet.Text = "" Then
            Exit Sub
        ElseIf Not IsNumeric(txtPallet.Text) Then
            MessageBox.Show("Please enter a valid numerical value", "Error - Non-Numerical Value")
            txtPallet.Focus()
            txtPallet.SelectAll()
        ElseIf Val(txtPallet.Text) < 0 Then
            MessageBox.Show("Please enter a non-negative numerical value", "Error - Negative Value")
            txtPallet.Focus()
            txtPallet.SelectAll()
        End If
    End Sub

    Private Sub txtTotalWeight_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtTotalWeight.Validating
        'checks to see if the txtbox is an invalid numerical value

        If txtTotalWeight.Text = "" Then
            Exit Sub
        ElseIf Not IsNumeric(txtTotalWeight.Text) Then
            MessageBox.Show("Please enter a valid numerical value", "Error - Non-Numerical Value")
            txtTotalWeight.Focus()
            txtTotalWeight.SelectAll()
        ElseIf Val(txtTotalWeight.Text) < 0 Then
            MessageBox.Show("Please enter a non-negative numerical value", "Error - Negative Value")
            txtTotalWeight.Focus()
            txtTotalWeight.SelectAll()
        End If
    End Sub
End Class
