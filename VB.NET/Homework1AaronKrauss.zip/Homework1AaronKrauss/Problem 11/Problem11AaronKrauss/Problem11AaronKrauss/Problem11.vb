﻿Public Class frmProblem11
    'Aaron Krauss ID: 112-71-2284
    'This program is the answer to Problem 11 on HW 1

    Dim x As Integer = 0

    Private Sub lblMiddle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblMiddle.Click

        If (x Mod 2 = 0) Then lblTop.Text = "SOONER!" : lblBottom.Text = "BOOMER!"
        If (x Mod 2 = 1) Then lblTop.Text = "BOOMER!" : lblBottom.Text = "SOONER!"
        x = x + 1

    End Sub

    Private Sub frmProblem11_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim intResp As Int32
        intResp = MessageBox.Show("Did you mean to exit?", "Closing Form", MessageBoxButtons.YesNo, _
                                  MessageBoxIcon.Question)
        If intResp = vbNo Then
            e.Cancel = True
        Else
            MessageBox.Show("Bye Bye baby", "End Application")
            End
        End If
    End Sub
End Class
