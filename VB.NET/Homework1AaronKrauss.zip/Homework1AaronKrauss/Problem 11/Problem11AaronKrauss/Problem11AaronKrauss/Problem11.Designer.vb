﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProblem11
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTop = New System.Windows.Forms.Label()
        Me.lblMiddle = New System.Windows.Forms.Label()
        Me.lblBottom = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblTop
        '
        Me.lblTop.BackColor = System.Drawing.Color.DarkRed
        Me.lblTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTop.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTop.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblTop.Location = New System.Drawing.Point(40, 39)
        Me.lblTop.Name = "lblTop"
        Me.lblTop.Size = New System.Drawing.Size(121, 38)
        Me.lblTop.TabIndex = 0
        Me.lblTop.Text = "BOOMER!"
        Me.lblTop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMiddle
        '
        Me.lblMiddle.BackColor = System.Drawing.Color.White
        Me.lblMiddle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMiddle.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMiddle.Location = New System.Drawing.Point(40, 76)
        Me.lblMiddle.Name = "lblMiddle"
        Me.lblMiddle.Size = New System.Drawing.Size(121, 38)
        Me.lblMiddle.TabIndex = 1
        Me.lblMiddle.Text = "OU CHANT?"
        Me.lblMiddle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblBottom
        '
        Me.lblBottom.BackColor = System.Drawing.Color.DarkRed
        Me.lblBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBottom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBottom.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblBottom.Location = New System.Drawing.Point(40, 112)
        Me.lblBottom.Name = "lblBottom"
        Me.lblBottom.Size = New System.Drawing.Size(121, 38)
        Me.lblBottom.TabIndex = 2
        Me.lblBottom.Text = "SOONER!"
        Me.lblBottom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmProblem11
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(207, 198)
        Me.Controls.Add(Me.lblBottom)
        Me.Controls.Add(Me.lblMiddle)
        Me.Controls.Add(Me.lblTop)
        Me.Name = "frmProblem11"
        Me.Text = "BOOMER SOONER!"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblTop As System.Windows.Forms.Label
    Friend WithEvents lblMiddle As System.Windows.Forms.Label
    Friend WithEvents lblBottom As System.Windows.Forms.Label

End Class
