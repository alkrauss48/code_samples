﻿Public Class frmProblem7
    'Aaron Krauss ID# 112-71-2284
    'this is problem 7 of HW 1 and #42 in the book on page 51

    Private Sub txtName_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtName.GotFocus
        lblDisplay.Text = "Enter your full name"
    End Sub

    Private Sub txtPhoneNumber_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPhoneNumber.GotFocus
        lblDisplay.Text = "Enter your phone number, including area code"
    End Sub

End Class
