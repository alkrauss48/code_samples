﻿Public Class frmBusinessTravel
    'Aaron Krauss ID# 112-71-2284
    'this program answers problem 10 in HW 1 and also # 5 in the book on page 101

    Const ONE_INCH As Integer = 100
    Const LINE_HEIGHT As Integer = 25

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        prtDoc1.Print()

    End Sub

    Private Sub btnPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreview.Click

        PrintPreviewDialog1.Document = prtDoc1
        PrintPreviewDialog1.ShowDialog()

    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles prtDoc1.PrintPage

        Dim strOrganizations, strDates, strLocation As String
        Dim dblMeals, dblAirplane, dblLodging, dblTaxi As Double
        Dim dblTotal, dblMealsDeduct, dblTotalExpenses As Double

        strOrganizations = txtOrganizations.Text
        strDates = txtDates.Text
        strLocation = txtLocation.Text
        dblMeals = CDbl(txtMeals.Text)
        dblAirplane = CDbl(txtAirplane.Text)
        dblLodging = CDbl(txtLodging.Text)
        dblTaxi = CDbl(txtTaxi.Text)

        dblTotal = dblAirplane + dblLodging + dblTaxi
        dblMealsDeduct = dblMeals * 0.5
        dblTotalExpenses = (dblTotal + dblMealsDeduct)

        Dim gr As Graphics = e.Graphics
        Dim x1 As Integer = ONE_INCH
        Dim x2 As Integer = 5 * ONE_INCH
        Dim y As Integer = ONE_INCH
        Dim font As New Font("Courier New", 10, FontStyle.Bold)

        gr.DrawString("Business Travel Expenses", font, Brushes.Black, x1, y)
        y += (2 * LINE_HEIGHT)

        gr.DrawString("Trip to attend meeting of", font, Brushes.Black, x1, y)
        y += LINE_HEIGHT
        gr.DrawString(strOrganizations, font, Brushes.Black, x1, y)
        y += LINE_HEIGHT
        gr.DrawString(strDates & " in " & strLocation, font, Brushes.Black, x1, y)
        y += (2 * LINE_HEIGHT)

        gr.DrawString("Meals and Entertainment:", font, Brushes.Black, x1, y)
        gr.DrawString(dblMeals.ToString("C2"), font, Brushes.Black, x2, y)
        y += LINE_HEIGHT

        gr.DrawString("Airplane Fare:", font, Brushes.Black, x1, y)
        gr.DrawString(dblAirplane.ToString("C2"), font, Brushes.Black, x2, y)
        y += LINE_HEIGHT

        gr.DrawString("Lodging:", font, Brushes.Black, x1, y)
        gr.DrawString(dblLodging.ToString("C2"), font, Brushes.Black, x2, y)
        y += LINE_HEIGHT

        gr.DrawString("Taxi Fares:", font, Brushes.Black, x1, y)
        gr.DrawString(dblTaxi.ToString("C2"), font, Brushes.Black, x2, y)
        y += (2 * LINE_HEIGHT)

        gr.DrawString("Total other than meals and entertainment:", font, Brushes.Black, x1, y)
        gr.DrawString(dblTotal.ToString("C2"), font, Brushes.Black, x2, y)
        y += LINE_HEIGHT

        gr.DrawString("50% of meals and entertainment:", font, Brushes.Black, x1, y)
        gr.DrawString(dblMealsDeduct.ToString("C2"), font, Brushes.Black, x2, y)
        y += (2 * LINE_HEIGHT)

        gr.DrawString("TOTAL DEDUCTIBLE EXPENSES:", font, Brushes.Black, x1, y)
        gr.DrawString(dblTotalExpenses.ToString("C2"), font, Brushes.Black, x2, y)

    End Sub
End Class
