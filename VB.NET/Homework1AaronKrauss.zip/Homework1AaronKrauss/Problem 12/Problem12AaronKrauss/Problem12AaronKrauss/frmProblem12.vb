﻿Public Class frmProblem12
    'Aaron Krauss
    'This is the answer to Problem 12 on HW 1

    Const DOLLARVAL = 1
    Const QUARTERVAL = 0.25
    Const DIMEVAL = 0.1
    Const NICKELVAL = 0.05
    Const PENNYVAL = 0.01

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Dim intResp As Int32
        intResp = MessageBox.Show("Did you mean to exit?", "Closing Form", MessageBoxButtons.YesNo, _
                                  MessageBoxIcon.Question)
        If intResp = vbNo Then
            Exit Sub
        Else
            MessageBox.Show("Bye Bye baby", "End Application")
            End
        End If
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtInput.Text = ""
        lblDollars.Text = "0"
        lblQuarters.Text = "0"
        lblDimes.Text = "0"
        lblNickels.Text = "0"
        lblPennies.Text = "0"

    End Sub

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click

        If (txtInput.Text = "") Then
            MessageBox.Show("Please enter a monetary value", "Error - Forgot To Enter Amount")
            Exit Sub
        End If

        Dim dblAmount As Double = 0
        Dim intNumDollars As Integer = 0
        Dim intNumQuarters As Integer = 0
        Dim intNumDimes As Integer = 0
        Dim intNumNickels As Integer = 0
        Dim intNumPennies As Integer = 0

        dblAmount = Val(txtInput.Text)
        dblAmount = Math.Round(dblAmount, 2)

        Do While (dblAmount >= DOLLARVAL)
            dblAmount = dblAmount - DOLLARVAL
            dblAmount = Math.Round(dblAmount, 2)
            intNumDollars = intNumDollars + 1
        Loop

        Do While (dblAmount >= QUARTERVAL)
            dblAmount = dblAmount - QUARTERVAL
            dblAmount = Math.Round(dblAmount, 2)
            intNumQuarters = intNumQuarters + 1
        Loop

        Do While (dblAmount >= DIMEVAL)
            dblAmount = dblAmount - DIMEVAL
            dblAmount = Math.Round(dblAmount, 2)
            intNumDimes = intNumDimes + 1
        Loop

        Do While (dblAmount >= NICKELVAL)
            dblAmount = dblAmount - NICKELVAL
            dblAmount = Math.Round(dblAmount, 2)
            intNumNickels = intNumNickels + 1
        Loop

        Do While (dblAmount >= PENNYVAL)
            dblAmount = dblAmount - PENNYVAL
            dblAmount = Math.Round(dblAmount, 2)
            intNumPennies = intNumPennies + 1
        Loop

        lblDollars.Text = intNumDollars
        lblQuarters.Text = intNumQuarters
        lblDimes.Text = intNumDimes
        lblNickels.Text = intNumNickels
        lblPennies.Text = intNumPennies

    End Sub


    Private Sub txtInput_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtInput.Leave
        If txtInput.Text = "" Then
            Exit Sub
        End If

        If Val(txtInput.Text) < 0 Then
            MessageBox.Show("Please enter a non-negative monetary value", "Error-Negative Value")
            txtInput.Focus()
            txtInput.SelectAll()
            Exit Sub
        End If

        If Not IsNumeric(txtInput.Text) Then
            MessageBox.Show("Please enter a valid monetary value", "Error")
            txtInput.Focus()
            txtInput.SelectAll()
        End If
    End Sub

    Private Sub frmProblem12_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim intResp As Int32
        intResp = MessageBox.Show("Did you mean to exit?", "Closing Form", MessageBoxButtons.YesNo, _
                                  MessageBoxIcon.Question)
        If intResp = vbNo Then
            e.Cancel = True
        Else
            MessageBox.Show("Bye Bye baby", "End Application")
            End
        End If
    End Sub
End Class
