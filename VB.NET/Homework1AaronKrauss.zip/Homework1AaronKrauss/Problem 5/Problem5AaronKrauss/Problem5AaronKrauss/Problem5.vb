﻿Public Class frm123

    'Aaron Krauss ID# 112-71-2284
    'This program is the answer to problem 5 on HW 1, and #36 in the book on p. 50

    Private Sub btnLeft_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLeft.Click
        txtOne.TextAlign = HorizontalAlignment.Left
        txtTwo.TextAlign = HorizontalAlignment.Left
        txtThree.TextAlign = HorizontalAlignment.Left
    End Sub

    Private Sub btnRight_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRight.Click
        txtOne.TextAlign = HorizontalAlignment.Right
        txtTwo.TextAlign = HorizontalAlignment.Right
        txtThree.TextAlign = HorizontalAlignment.Right
    End Sub

    Private Sub txtOne_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtOne.GotFocus
        txtOne.SelectAll()
        txtOne.ForeColor = Color.Red

    End Sub

    Private Sub txtTwo_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTwo.GotFocus
        txtTwo.SelectAll()
        txtTwo.ForeColor = Color.Red
    End Sub

    Private Sub txtThree_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtThree.GotFocus
        txtThree.SelectAll()
        txtThree.ForeColor = Color.Red
    End Sub

    Private Sub txtOne_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtOne.LostFocus
        txtOne.SelectAll()
        txtOne.ForeColor = Color.Black
    End Sub

    Private Sub txtTwo_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTwo.LostFocus
        txtTwo.SelectAll()
        txtTwo.ForeColor = Color.Black
    End Sub

    Private Sub txtThree_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtThree.LostFocus
        txtThree.SelectAll()
        txtThree.ForeColor = Color.Black
    End Sub
End Class
