﻿Public Class frmProblem3
    'Aaron Krauss ID: 112-71-2284
    'this program correlates to Program 3 on HW 1

    Const COUNTYTAX = 0.02
    Const STATETAX = 0.04

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Dim intResp As Int32
        intResp = MessageBox.Show("Did you mean to exit?", "Closing Form", MessageBoxButtons.YesNo, _
                                  MessageBoxIcon.Question)
        If intResp = vbNo Then
            Exit Sub
        Else
            MessageBox.Show("Bye Bye baby", "End Application")
            End
        End If
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtSales.Text = ""
        lblCountyTax.Text = "$0.00"
        lblStateTax.Text = "$0.00"
        lblTotalTax.Text = "$0.00"

    End Sub

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click

        If txtSales.Text = "" Then
            MessageBox.Show("Please enter a value for total monthly sales", "Forgot Monthly Sales")
            txtSales.Focus()
            Exit Sub
        End If

        Dim dblSales As Double
        Dim dblCTax As Double
        Dim dblSTax As Double
        Dim dblTotalTax As Double

        dblSales = Val(txtSales.Text)
        dblCTax = dblSales * COUNTYTAX
        dblSTax = dblSales * STATETAX
        dblTotalTax = dblCTax + dblSTax

        lblCountyTax.Text = dblCTax.ToString("C2")
        lblStateTax.Text = dblSTax.ToString("C2")
        lblTotalTax.Text = dblTotalTax.ToString("C2")

    End Sub

    Private Sub txtSales_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtSales.Leave
        If txtSales.Text = "" Then
            Exit Sub
        End If

        If Val(txtSales.Text) < 0 Then
            MessageBox.Show("Please enter a valid value for sales", "Error-Negative Value")
            txtSales.Focus()
            txtSales.SelectAll()
            Exit Sub
        End If

        If Not IsNumeric(txtSales.Text) Then
            MessageBox.Show("Please enter a valid numerical value for sales", "Error-Invalid Value")
            txtSales.Focus()
            txtSales.SelectAll()
        End If
    End Sub

    Private Sub frmProblem3_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim intResp As Int32
        intResp = MessageBox.Show("Did you mean to exit?", "Closing Form", MessageBoxButtons.YesNo, _
                                  MessageBoxIcon.Question)
        If intResp = vbNo Then
            e.Cancel = True
        Else
            MessageBox.Show("Bye Bye baby", "End Application")
            End
        End If
    End Sub
End Class
