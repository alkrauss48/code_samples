﻿Public Class frmProblem3

    'Aaron Krauss ID# 112-71-2284
    'this is the answer to problem 3 for take home exam 1

    Private Sub readFile(ByRef sr As IO.StreamReader, ByVal strFormat As String)

        'declarelocal variables
        Dim strName As String

        Dim dblExam1, dblExam2, dblExam3, dblExam4 As Double
        Dim dblResult As Double
        Dim strLetterGrade As String

        'gather data for each individual person - assuming he is listed properly in the input file
        While sr.Peek <> -1

            'read a series of 5 lines for every iteration of the loop
            strName = sr.ReadLine
            dblExam1 = sr.ReadLine
            dblExam2 = sr.ReadLine
            dblExam3 = sr.ReadLine
            dblExam4 = sr.ReadLine
            
            'call functions to return weighted average and letter grade, all paramaters passed by value
            dblResult = calculateWeightedAverage(dblExam1, dblExam2, dblExam3, dblExam4)
            strLetterGrade = getLetterGrade(dblResult)

            'outputs this line for every iteration of the while loop
            lstOutput.Items.Add(String.Format(strFormat, strName, dblExam1, dblExam2, dblExam3, dblExam4, _
                                              dblResult, strLetterGrade))
        End While

    End Sub

    Private Function calculateWeightedAverage(ByVal dblOne As Double, ByVal dblTwo As Double, ByVal dblThree As Double, ByVal dblFour As Double) As Double

        'declare constant exam weights
        Const EXAM1WEIGHT As Double = 0.1
        Const EXAM2WEIGHT As Double = 0.2
        Const EXAM3WEIGHT As Double = 0.3
        Const EXAM4WEIGHT As Double = 0.4

        Dim dblResult As Double = 0

        'calculate weighted average
        dblResult = (dblOne * EXAM1WEIGHT) + (dblTwo * EXAM2WEIGHT) + (dblThree * EXAM3WEIGHT) + (dblFour * EXAM4WEIGHT)

        'this was added per Mano's request in the problem description
        dblResult += 1

        Return dblResult

    End Function

    Private Function getLetterGrade(ByVal dblRes As Double) As String

        'return proper letter grade based on their weighted average
        Select Case dblRes
            Case Is >= 92
                Return "A"
            Case 82 To 92
                Return "B"
            Case 70 To 82
                Return "C"
            Case 58 To 70
                Return "D"
            Case Else
                Return "F"
        End Select

    End Function

    Private Sub mnuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuExit.Click
        End
    End Sub

    Private Sub mnuClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuClear.Click
        lstOutput.Items.Clear()
    End Sub


    Private Sub mnuOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuOpen.Click

        Dim strFileName As String
        Dim strFormat As String = "{0,-20}{1,-10}{2,-10}{3,-10}{4,-10}{5,-20}{6,-15}"
        Dim sr As IO.StreamReader

        'set basic attributes of the open dialog box
        openFD.Title = "Open a File"
        openFD.Filter = "Text Files(*.txt)|*.txt"
        openFD.ShowDialog()

        'set stream reader to the file name of the chosen file
        strFileName = openFD.FileName
        sr = IO.File.OpenText(strFileName)

        'read the file's first line, skip the next, and then display the list headers
        lstOutput.Items.Add(sr.ReadLine)
        sr.ReadLine()
        lstOutput.Items.Add(String.Format(strFormat, "Name", "Exam 1", "Exam 2", "Exam 3", "Exam 4", "Weighted Average", "Letter Grade"))

        'calls the sub procedure that will read the file and fill out the rest of the listbox
        readFile(sr, strFormat)

        sr.Close()
    End Sub

    Private Sub mnuSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSave.Click

        Dim sw As IO.StreamWriter

        'sets format for the save file dialog box and then opens it

        saveFD.Title = "Save File"
        saveFD.Filter = "Text Files(*.txt)|*.txt"
        saveFD.ShowDialog()

        'set stream reader to the file name of the chosen file

        sw = IO.File.CreateText(saveFD.FileName)

        Dim i As Integer

        'loop through listbox using iterator
        For i = 0 To lstOutput.Items.Count - 1
            sw.WriteLine(lstOutput.Items.Item(i))
        Next

        sw.Close()

    End Sub
End Class
