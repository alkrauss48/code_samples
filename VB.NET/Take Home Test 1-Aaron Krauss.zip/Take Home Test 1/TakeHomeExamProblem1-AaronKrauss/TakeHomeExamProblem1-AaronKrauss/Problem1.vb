﻿Public Class frmProblem1

    'Aaron Krauss ID# 112-71-2284
    'This is Problem 1 for Take Home Part for Exam 1

    'declare form-level variables because they are used in 
    Private intTotalCount As Integer = 0
    Private dblTotalPaid As Double = 0.0
    Private strFormat As String = "{0,-25}{1,-20}{2,-10}"

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        'exit the function
        End
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click

        'calls sub method to clear all necessary data
        clear()

    End Sub

    Private Sub clear()

        'clears out all form-level variables and sets displays to their default texts
        intTotalCount = 0
        dblTotalPaid = 0.0
        lstOutput.Items.Clear()
        txtName.Clear()
        txtYears.Clear()
        lstOutput.Items.Add(String.Format(strFormat, "Employee name", "Years Worked", "Bonus Paid"))
        lblEmployees.Text = ""
        lblTotalPaid.Text = ""

    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click

        'exits sub if any of the input fields are left blank
        If (txtYears.Text = "" Or txtName.Text = "") Then
            MessageBox.Show("Please enter valid information", "Error - Missing Values")
            Exit Sub
        End If

        'declares local variables
        Dim strName As String
        Dim intYears As Integer
        Dim dblBonus As Double

        'gather inputs
        strName = txtName.Text
        intYears = Math.Ceiling(CDbl(txtYears.Text))

        'function to calculate the bonus
        dblBonus = calculateBonus(intYears)

        'update form level variables
        intTotalCount += 1
        dblTotalPaid += dblBonus

        'display in the output list
        lstOutput.Items.Add(String.Format(strFormat, strName, intYears, FormatCurrency(dblBonus, 2)))

        'display form level variables in the labels
        lblEmployees.Text = intTotalCount
        lblTotalPaid.Text = FormatCurrency(dblTotalPaid, 2)

    End Sub

    Private Function calculateBonus(ByVal intYears As Integer) As Integer

        Dim dblBonus As Double

        'uses problem criteria to give a value to dblBonus based on the number of years an employee has worked
        Select Case intYears
            Case 1 To 10
                dblBonus += intYears * 20000
            Case 10 To 20
                dblBonus += 20 * 20000
                dblBonus += (intYears - 10) * 30000
            Case Is > 20
                dblBonus += 20 * 20000
                dblBonus += (intYears - 10) * 30000
                dblBonus += 50000
            Case Else
                dblBonus = 0
        End Select

        'returns the bonus to the main event
        Return dblBonus

    End Function

    Private Sub frmProblem1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'sets default display to the output list
        lstOutput.Items.Add(String.Format(strFormat, "Employee name", "Years Worked", "Bonus Paid"))

    End Sub

    Private Sub txtYears_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtYears.Validating

        'checks to see if the txtbox is an invalid numerical value
        If txtYears.Text = "" Then
            Exit Sub
        ElseIf Not IsNumeric(txtYears.Text) Then
            MessageBox.Show("Please enter a valid numerical value", "Error - Non-Numerical Value")
            txtYears.Focus()
            txtYears.SelectAll()
        ElseIf Val(txtYears.Text) < 0 Then
            MessageBox.Show("Please enter a non-negative numerical value", "Error - Negative Value")
            txtYears.Focus()
            txtYears.SelectAll()
        End If

    End Sub

    Private Sub txtName_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtName.Validating

        'checks to see if the txtbox is an invalid string value
        If txtName.Text = "" Then
            Exit Sub
        ElseIf IsNumeric(txtName.Text) Then
            MessageBox.Show("Please enter a valid value for the Name field", "Error - Numerical Value")
            txtName.Focus()
            txtName.SelectAll()
        End If

    End Sub

    Private Sub mnuWrite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuWrite.Click

        Dim sw As IO.StreamWriter

        saveFD.Title = "Save File"
        saveFD.Filter = "Text Files(*.txt)|*.txt"
        saveFD.ShowDialog()

        'set stream reader to the file name of the chosen file

        sw = IO.File.CreateText(saveFD.FileName)

        Dim i As Integer

        'loop through listbox using iterator
        For i = 0 To lstOutput.Items.Count - 1
            sw.WriteLine(lstOutput.Items.Item(i))
        Next

        sw.Close()

    End Sub
End Class
