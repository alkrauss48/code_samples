﻿Public Class frmProblem2

    'Aaron Krauss ID# 112-71-2284
    'this is the answer to problem 2 for take home exam 1

    Private strFormat As String = "{0,-40}{1,-15}"

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        'calls sub method to clear contents
        clear()
    End Sub

    Sub clear()

        'resets display and input fields
        txtHouseLength.Clear()
        txtHouseWidth.Clear()
        txtHouseAge.Clear()
        txtLandLength.Clear()
        txtLandWidth.Clear()
        lstOutput.Items.Clear()

    End Sub

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click

        'checks to see if any of the text boxes were left blank
        If (txtHouseAge.Text = "" Or txtHouseLength.Text = "" Or txtHouseWidth.Text = "" Or _
           txtLandLength.Text = "" Or txtLandWidth.Text = "") Then
            MessageBox.Show("Please enter in all data into the necessary fields", "Forgot Field")
            Exit Sub
        End If

        'declare local variables
        Dim intHouseLength, intHouseWidth As Integer
        Dim intLotlength, intLotWidth As Integer
        Dim intHouseSF, intLotSF As Integer
        Dim intHouseAge As Integer

        Dim dblHouseTaxes, dblLotTaxes As Double
        Dim dblTotalTaxes As Double

        Dim dblHouseDiscount, dblLotDiscount As Double
        Dim dblTotalDiscount As Double

        Dim dblGrandTotal As Double


        'clear out listbox items
        lstOutput.Items.Clear()

        'sub method which passes all initial variables byref
        gatherInputs(intHouseLength, intHouseWidth, intLotlength, intLotWidth, _
                     intHouseSF, intLotSF, intHouseAge)

        'function to calculate property taxes from the house
        dblHouseTaxes = calculateHomeTaxes(intHouseSF)
        'function to calculate property taxes from the lot
        dblLotTaxes = calculateLandTaxes(intLotSF)

        'total taxes
        dblTotalTaxes = dblHouseTaxes + dblLotTaxes

        'sub method which passes all necessary variables byref to calculate house and lot discount
        calculateDiscount(intHouseAge, dblHouseTaxes, dblLotTaxes, dblHouseDiscount, dblLotDiscount)

        'total discount
        dblTotalDiscount = dblHouseDiscount + dblLotDiscount

        'grand total of taxes minus the discount (discount is a negative number)
        dblGrandTotal = dblTotalTaxes + dblTotalDiscount

        'display in the listbox
        lstOutput.Items.Add(String.Format(strFormat, "House Square Feet:", intHouseSF))
        lstOutput.Items.Add(String.Format(strFormat, "Lot Square Feet:", intLotSF))
        lstOutput.Items.Add("----------")
        lstOutput.Items.Add(String.Format(strFormat, "Property Taxes From House:", FormatCurrency(dblHouseTaxes, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Property Taxes From Lot:", FormatCurrency(dblLotTaxes, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Total Property Taxes:", FormatCurrency(dblTotalTaxes, 2)))
        lstOutput.Items.Add("----------")
        lstOutput.Items.Add(String.Format(strFormat, "Discount From House", FormatCurrency(dblHouseDiscount, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Discount From Lot", FormatCurrency(dblLotDiscount, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Total Discount", FormatCurrency(dblTotalDiscount, 2)))
        lstOutput.Items.Add("----------")
        lstOutput.Items.Add(String.Format(strFormat, "Grand Total", FormatCurrency(dblGrandTotal, 2)))

    End Sub

    Sub gatherInputs(ByRef intHLength As Integer, ByRef intHWidth As Integer, _
                          ByRef intLLength As Integer, ByRef intLWidth As Integer, _
                          ByRef intHouseSF As Integer, ByRef intLandSF As Integer, _
                          ByRef intHouseAge As Integer)

        'gather all inputs from form and then compute respective square footages
        intHLength = CInt(txtHouseLength.Text)
        intHWidth = CInt(txtHouseWidth.Text)
        intLLength = CInt(txtLandLength.Text)
        intLWidth = CInt(txtLandWidth.Text)

        intHouseSF = intHLength * intHWidth
        intLandSF = intLLength * intLWidth

        'round up for house age just in case they enter 5.1, then the house is still over 5 years.
        'but if they enter 4.5 or something, then it will round up to 5, which is not greater than 5,
        'so it works out correctly

        intHouseAge = Math.Ceiling(CDbl(txtHouseAge.Text))

    End Sub

    Function calculateHomeTaxes(ByVal intSquareFeet As Integer) As Double

        Dim dblHouseTaxes As Double

        'select case statement to determine house taxes based on the sq ft of the house
        Select Case intSquareFeet
            Case 0 To 1000
                dblHouseTaxes = intSquareFeet * 0.1
            Case 1001 To 2000
                dblHouseTaxes = 100 + ((intSquareFeet - 1000) * 0.11)
            Case 2001 To 3000
                dblHouseTaxes = 210 + ((intSquareFeet - 2000) * 0.12)
            Case 3001 To 4000
                dblHouseTaxes = 330 + ((intSquareFeet - 3000) * 0.13)
            Case Is > 4001
                dblHouseTaxes = 460 + ((intSquareFeet - 4000) * 0.14)
            Case Else
                MessageBox.Show("Entry Error", "Error")
                dblHouseTaxes = 0
        End Select

        'return the property taxes for the house
        Return dblHouseTaxes

    End Function

    Function calculateLandTaxes(ByVal intSquareFeet As Integer) As Double

        Dim dblLandTaxes As Double

        'select case statement to determine the land taxes based on land sq ft
        Select Case intSquareFeet
            Case 0 To 10000
                dblLandTaxes = intSquareFeet * 0.02
            Case 10001 To 20000
                dblLandTaxes = 200 + ((intSquareFeet - 10000) * 0.03)
            Case 20001 To 30000
                dblLandTaxes = 500 + ((intSquareFeet - 20000) * 0.04)
            Case 30001 To 40000
                dblLandTaxes = 900 + ((intSquareFeet - 30000) * 0.05)
            Case Is > 40001
                dblLandTaxes = 1400 + ((intSquareFeet - 40000) * 0.06)
            Case Else
                MessageBox.Show("Entry Error", "Error")
                dblLandTaxes = 0
        End Select

        'returns property taxes from the land
        Return dblLandTaxes

    End Function

    Sub calculateDiscount(ByVal intHomeAge As Integer, ByVal dblHomeTaxes As Double, _
                                ByVal dblLandTaxes As Double, ByRef dblHouseDiscount As Double, _
                                ByRef dblLandDiscount As Double)

        'applies disount if home is greater than 5 years old, but not equal to b/c that's what the problem said
        If (intHomeAge > 5) Then

            dblHouseDiscount = -1 * (dblHomeTaxes * 0.005 * intHomeAge)
            dblLandDiscount = -1 * (dblLandTaxes * 0.01 * intHomeAge)

        End If

    End Sub

    Sub validateTextBox(ByVal txtBox As TextBox)

        'checks to see if the txtbox is an invalid numerical value
        If txtBox.Text = "" Then
            Exit Sub
        ElseIf Not IsNumeric(txtBox.Text) Then
            MessageBox.Show("Please enter a valid numerical value", "Error - Non-Numerical Value")
            txtBox.Focus()
            txtBox.SelectAll()
        ElseIf Val(txtBox.Text) < 0 Then
            MessageBox.Show("Please enter a non-negative numerical value", "Error - Negative Value")
            txtBox.Focus()
            txtBox.SelectAll()
        End If
    End Sub

    Private Sub txtHouseAge_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtHouseAge.Validating
        'pass the current text box to the created validate sub procedure in order to properly validate
        validateTextBox(txtHouseAge)
    End Sub

    Private Sub txtHouseLength_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtHouseLength.Validating
        'pass the current text box to the created validate sub procedure in order to properly validate
        validateTextBox(txtHouseLength)
    End Sub

    Private Sub txtHouseWidth_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtHouseWidth.Validating
        'pass the current text box to the created validate sub procedure in order to properly validate
        validateTextBox(txtHouseWidth)
    End Sub

    Private Sub txtLandLength_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtLandLength.Validating
        'pass the current text box to the created validate sub procedure in order to properly validate
        validateTextBox(txtLandLength)
    End Sub

    Private Sub txtLandWidth_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtLandWidth.Validating
        'pass the current text box to the created validate sub procedure in order to properly validate
        validateTextBox(txtLandWidth)
    End Sub
End Class
