﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDental
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radNew = New System.Windows.Forms.RadioButton()
        Me.radOld = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkCleaning = New System.Windows.Forms.CheckBox()
        Me.chkXRay = New System.Windows.Forms.CheckBox()
        Me.chkFillings = New System.Windows.Forms.CheckBox()
        Me.chkCaps = New System.Windows.Forms.CheckBox()
        Me.chkBreath = New System.Windows.Forms.CheckBox()
        Me.lblCleaning = New System.Windows.Forms.Label()
        Me.lblXRay = New System.Windows.Forms.Label()
        Me.lblFillings = New System.Windows.Forms.Label()
        Me.lblCaps = New System.Windows.Forms.Label()
        Me.lblBreath = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lstOutput = New System.Windows.Forms.ListBox()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.tmrTwo = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.mskBDay = New System.Windows.Forms.MaskedTextBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radOld)
        Me.GroupBox1.Controls.Add(Me.radNew)
        Me.GroupBox1.Location = New System.Drawing.Point(27, 97)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(135, 78)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Customer Type"
        '
        'radNew
        '
        Me.radNew.AutoSize = True
        Me.radNew.Location = New System.Drawing.Point(7, 20)
        Me.radNew.Name = "radNew"
        Me.radNew.Size = New System.Drawing.Size(94, 17)
        Me.radNew.TabIndex = 0
        Me.radNew.TabStop = True
        Me.radNew.Text = "New Customer"
        Me.radNew.UseVisualStyleBackColor = True
        '
        'radOld
        '
        Me.radOld.AutoSize = True
        Me.radOld.Location = New System.Drawing.Point(7, 44)
        Me.radOld.Name = "radOld"
        Me.radOld.Size = New System.Drawing.Size(88, 17)
        Me.radOld.TabIndex = 1
        Me.radOld.TabStop = True
        Me.radOld.Text = "Old Customer"
        Me.radOld.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblBreath)
        Me.GroupBox2.Controls.Add(Me.lblCaps)
        Me.GroupBox2.Controls.Add(Me.lblFillings)
        Me.GroupBox2.Controls.Add(Me.lblXRay)
        Me.GroupBox2.Controls.Add(Me.lblCleaning)
        Me.GroupBox2.Controls.Add(Me.chkBreath)
        Me.GroupBox2.Controls.Add(Me.chkCaps)
        Me.GroupBox2.Controls.Add(Me.chkFillings)
        Me.GroupBox2.Controls.Add(Me.chkXRay)
        Me.GroupBox2.Controls.Add(Me.chkCleaning)
        Me.GroupBox2.Location = New System.Drawing.Point(201, 97)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(321, 153)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Services Offered"
        '
        'chkCleaning
        '
        Me.chkCleaning.Location = New System.Drawing.Point(7, 20)
        Me.chkCleaning.Name = "chkCleaning"
        Me.chkCleaning.Size = New System.Drawing.Size(136, 24)
        Me.chkCleaning.TabIndex = 0
        Me.chkCleaning.Text = "General Cleaning"
        Me.chkCleaning.UseVisualStyleBackColor = True
        '
        'chkXRay
        '
        Me.chkXRay.Location = New System.Drawing.Point(7, 44)
        Me.chkXRay.Name = "chkXRay"
        Me.chkXRay.Size = New System.Drawing.Size(136, 24)
        Me.chkXRay.TabIndex = 1
        Me.chkXRay.Text = "Dental X-Ray"
        Me.chkXRay.UseVisualStyleBackColor = True
        '
        'chkFillings
        '
        Me.chkFillings.Location = New System.Drawing.Point(7, 68)
        Me.chkFillings.Name = "chkFillings"
        Me.chkFillings.Size = New System.Drawing.Size(136, 24)
        Me.chkFillings.TabIndex = 2
        Me.chkFillings.Text = "Cavity Fillings"
        Me.chkFillings.UseVisualStyleBackColor = True
        '
        'chkCaps
        '
        Me.chkCaps.Location = New System.Drawing.Point(7, 92)
        Me.chkCaps.Name = "chkCaps"
        Me.chkCaps.Size = New System.Drawing.Size(136, 24)
        Me.chkCaps.TabIndex = 3
        Me.chkCaps.Text = "Gold Caps"
        Me.chkCaps.UseVisualStyleBackColor = True
        '
        'chkBreath
        '
        Me.chkBreath.Location = New System.Drawing.Point(7, 116)
        Me.chkBreath.Name = "chkBreath"
        Me.chkBreath.Size = New System.Drawing.Size(136, 24)
        Me.chkBreath.TabIndex = 4
        Me.chkBreath.Text = "Stink Breath Healer"
        Me.chkBreath.UseVisualStyleBackColor = True
        '
        'lblCleaning
        '
        Me.lblCleaning.Location = New System.Drawing.Point(198, 25)
        Me.lblCleaning.Name = "lblCleaning"
        Me.lblCleaning.Size = New System.Drawing.Size(100, 23)
        Me.lblCleaning.TabIndex = 5
        Me.lblCleaning.Text = "$0.00"
        '
        'lblXRay
        '
        Me.lblXRay.Location = New System.Drawing.Point(198, 49)
        Me.lblXRay.Name = "lblXRay"
        Me.lblXRay.Size = New System.Drawing.Size(100, 23)
        Me.lblXRay.TabIndex = 6
        Me.lblXRay.Text = "$0.00"
        '
        'lblFillings
        '
        Me.lblFillings.Location = New System.Drawing.Point(198, 73)
        Me.lblFillings.Name = "lblFillings"
        Me.lblFillings.Size = New System.Drawing.Size(100, 23)
        Me.lblFillings.TabIndex = 7
        Me.lblFillings.Text = "$0.00"
        '
        'lblCaps
        '
        Me.lblCaps.Location = New System.Drawing.Point(198, 97)
        Me.lblCaps.Name = "lblCaps"
        Me.lblCaps.Size = New System.Drawing.Size(100, 23)
        Me.lblCaps.TabIndex = 8
        Me.lblCaps.Text = "$0.00"
        '
        'lblBreath
        '
        Me.lblBreath.Location = New System.Drawing.Point(198, 121)
        Me.lblBreath.Name = "lblBreath"
        Me.lblBreath.Size = New System.Drawing.Size(100, 23)
        Me.lblBreath.TabIndex = 9
        Me.lblBreath.Text = "$0.00"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(286, 256)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(128, 23)
        Me.btnCalculate.TabIndex = 2
        Me.btnCalculate.Text = "Calculate Total"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'lstOutput
        '
        Me.lstOutput.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstOutput.FormattingEnabled = True
        Me.lstOutput.ItemHeight = 14
        Me.lstOutput.Location = New System.Drawing.Point(34, 293)
        Me.lstOutput.Name = "lstOutput"
        Me.lstOutput.Size = New System.Drawing.Size(488, 144)
        Me.lstOutput.TabIndex = 4
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDate.Location = New System.Drawing.Point(13, 2)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(2, 15)
        Me.lblDate.TabIndex = 5
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTime.Location = New System.Drawing.Point(13, 25)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(2, 15)
        Me.lblTime.TabIndex = 6
        '
        'tmrTwo
        '
        Me.tmrTwo.Interval = 1000
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Enter Name:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(100, 61)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(240, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(97, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Enter Date of Birth:"
        '
        'mskBDay
        '
        Me.mskBDay.Location = New System.Drawing.Point(344, 60)
        Me.mskBDay.Mask = "00/00/0000"
        Me.mskBDay.Name = "mskBDay"
        Me.mskBDay.Size = New System.Drawing.Size(100, 20)
        Me.mskBDay.TabIndex = 10
        '
        'frmDental
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(544, 450)
        Me.Controls.Add(Me.mskBDay)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblTime)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.lstOutput)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmDental"
        Me.Text = "Dental Application"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents radOld As System.Windows.Forms.RadioButton
    Friend WithEvents radNew As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lblCleaning As System.Windows.Forms.Label
    Friend WithEvents chkBreath As System.Windows.Forms.CheckBox
    Friend WithEvents chkCaps As System.Windows.Forms.CheckBox
    Friend WithEvents chkFillings As System.Windows.Forms.CheckBox
    Friend WithEvents chkXRay As System.Windows.Forms.CheckBox
    Friend WithEvents chkCleaning As System.Windows.Forms.CheckBox
    Friend WithEvents lblBreath As System.Windows.Forms.Label
    Friend WithEvents lblCaps As System.Windows.Forms.Label
    Friend WithEvents lblFillings As System.Windows.Forms.Label
    Friend WithEvents lblXRay As System.Windows.Forms.Label
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents lstOutput As System.Windows.Forms.ListBox
    Friend WithEvents lblDate As System.Windows.Forms.Label
    Friend WithEvents lblTime As System.Windows.Forms.Label
    Friend WithEvents tmrTwo As System.Windows.Forms.Timer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents mskBDay As System.Windows.Forms.MaskedTextBox
End Class
