﻿Public Class frmLoginForm1

    'login form for Problem 4 on the take home exam

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click

        Static intX As Int16 = 1

        'check to see if password and username match. if so, then it hides this form and displays the next one
        If PasswordTextBox.Text = "GasbagRatwatte" And UsernameTextBox.Text.ToUpper = "MIS3013" Then
            Me.Hide()
            frmDental.ShowDialog()
            Application.Exit()
        Else
            'if they don't match, then that 1 is added to your count of failed tries.
            MessageBox.Show("invalid login information")
            UsernameTextBox.Focus()
            intX = intX + 1
        End If

        'if you have tried 4 times (I use > 4 instead of >= 4 because the count variable was initialized at 1 instead of 0
        If intX > 4 Then
            MessageBox.Show("stop wasting my time")
            Application.Exit()
        End If

    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

End Class
