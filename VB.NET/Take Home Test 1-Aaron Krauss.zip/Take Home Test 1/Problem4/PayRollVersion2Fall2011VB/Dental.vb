﻿Public Class frmDental

    'Aaron Krauss ID# 112-71-2284
    'this is problem 4 on take home exam 1
    'mine looks different because something happened with my flash drive and I my dental application was somehow
    'deleted. I then tried to download the GUI on d2l, but I couldn't remember the password for the zip file. 
    'I then decided to create my own GUI, so please don't count of points for that becaue I did try to get the
    'original application!

    'delcare form level constants
    Const OFFICEVISITCOST As Double = 25.0
    Const CLEANINGCOST As Double = 189.99
    Const XRAYCOST As Double = 149.99
    Const FILLINGCOST As Double = 167.99
    Const CAPSCOST As Double = 999.99
    Const BREATHCOST As Double = 500.0
    Const DISCOUNTPERCENT As Double = 0.15


    Private Sub tmrTwo_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrTwo.Tick
        'set timer for current time
        lblTime.Text = FormatDateTime(Now, DateFormat.LongTime)
    End Sub

    Private Sub frmDental_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'set default check value, date fore color, and the initial date/time labels
        radNew.Checked = True
        lblDate.ForeColor = Color.Yellow : lblTime.ForeColor = Color.White
        lblDate.Text = FormatDateTime(Now, DateFormat.LongDate)
        lblTime.Text = FormatDateTime(Now, DateFormat.ShortTime)


    End Sub

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click

        'declare local variables
        Dim strName As String
        Dim DOB As Date
        Dim todayDate As Date = Now
        Dim strFormat As String = "{0,-25}{1,-10}"

        Dim strIsNewCustomer As String
        Dim dblRegistrationFee As Double

        Dim dblCleaningCost, dblXRayCost, dblFillingCost, dblCapsCost, dblBreathCost, dblTotalServicesCost As Double
        Dim dblGrossCost As Double
        Dim dblDiscountAmt As Double
        Dim dblNetCost As Double

        lstOutput.Items.Clear()

        'checks to see if name was left out
        If (txtName.Text = "") Then

            'display message in dialog
            MessageBox.Show("Please enter PATIENT NAME", _
            "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        'checking to make sure the date is a valid date
        If IsDate(mskBDay.Text) Then
            DOB = CDate(mskBDay.Text)
        Else
            MessageBox.Show("invalid date")
            Exit Sub
        End If

        'ensures that user must check at least one service box
        If chkCleaning.Checked = False And chkXRay.Checked = False And chkFillings.Checked = False _
            And chkCaps.Checked = False And chkBreath.Checked = False Then

            'display message in dialog
            MessageBox.Show("Please check at least one box", _
            "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub

        End If

        'calculates number of months old the patient is, and then calculates the years
        Dim intDays = DateDiff(DateInterval.Day, DOB, todayDate)
        Dim intMonths = DateDiff(DateInterval.Month, DOB, todayDate)
        Dim AgeINYears = intMonths \ 12

        'check to see if the birthdate is in the current day's month, and then if the day is greater than the current day. if so, then it reduces age by 1 b/c their birthday hasn't occured yet 
        If (intMonths Mod 12 = 0 And (DOB.Day > todayDate.Day)) Then
            AgeINYears -= 1
        End If

        'gathers user name
        strName = txtName.Text

        'calculate registration fee
        If (radNew.Checked = True) Then
            strIsNewCustomer = "Yes"
            dblRegistrationFee = calculateRegistrationFee(True)
        Else
            strIsNewCustomer = "No"
            dblRegistrationFee = calculateRegistrationFee(False)
        End If

        'add on the registration fee, whether it is 0 or full price
        dblGrossCost += dblRegistrationFee
        'add on the standard office visit cost
        dblGrossCost += OFFICEVISITCOST

        'calculate the total services and pass unique services byref
        dblTotalServicesCost = calculateServices(dblCleaningCost, dblXRayCost, dblFillingCost, dblCapsCost, dblBreathCost)

        'add on the total services chosen
        dblGrossCost += dblTotalServicesCost

        'calculate the discount, which will be a negative value
        dblDiscountAmt = calculateDiscount(AgeINYears, dblGrossCost)

        'calculate the net cost
        dblNetCost = dblGrossCost + dblDiscountAmt

        'display data

        lstOutput.Items.Add(String.Format(strFormat, "Patient Name:", strName))
        lstOutput.Items.Add(String.Format(strFormat, "Age:", AgeINYears))
        lstOutput.Items.Add(String.Format(strFormat, "New Patient?", strIsNewCustomer))
        lstOutput.Items.Add(String.Format(strFormat, "Registration Fee:", FormatCurrency(dblRegistrationFee, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Office Visit Fee:", FormatCurrency(OFFICEVISITCOST, 2)))
        lstOutput.Items.Add("----------")
        lstOutput.Items.Add(String.Format(strFormat, "General Cleaning:", FormatCurrency(dblCleaningCost, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Dental X-Ray:", FormatCurrency(dblXRayCost, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Cavity Filling:", FormatCurrency(dblFillingCost, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Gold Caps:", FormatCurrency(dblCapsCost, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Stink Breath Healer", FormatCurrency(dblBreathCost, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Total Services:", FormatCurrency(dblTotalServicesCost, 2)))
        lstOutput.Items.Add("----------")
        lstOutput.Items.Add(String.Format(strFormat, "Total Gross Cost:", FormatCurrency(dblGrossCost, 2)))
        lstOutput.Items.Add(String.Format(strFormat, "Discount From Age:", FormatCurrency(dblDiscountAmt, 2)))
        lstOutput.Items.Add("----------")
        lstOutput.Items.Add(String.Format(strFormat, "Net Total:", FormatCurrency(dblNetCost, 2)))

    End Sub

    Private Function calculateDiscount(ByVal intAge As Integer, ByVal dblTotalCost As Double) As Double

        'if the user's age is under 12, then they get a child's discount

        If intAge < 12 Then
            Return (-1 * dblTotalCost * DISCOUNTPERCENT)
        Else
            Return 0
        End If

    End Function

    Private Function calculateServices(ByRef dblCleaningCost As Double, ByRef dblXRayCost As Double,
                                       ByRef dblFillingCost As Double, ByRef dblCapsCost As Double,
                                       ByRef dblBreathCost As Double) As Double

        'variable to capture cost of total services
        Dim dblTotalServicesCost As Double

        'each if statement sets the respective variables and adds them to the total services cost
        If (chkCleaning.Checked = True) Then
            dblCleaningCost = CLEANINGCOST
            dblTotalServicesCost += dblCleaningCost
        End If

        If (chkXRay.Checked = True) Then
            dblXRayCost = XRAYCOST
            dblTotalServicesCost += dblXRayCost
        End If

        If (chkFillings.Checked = True) Then
            dblFillingCost = FILLINGCOST
            dblTotalServicesCost += dblFillingCost
        End If

        If (chkCaps.Checked = True) Then
            dblCapsCost = CAPSCOST
            dblTotalServicesCost += dblCapsCost
        End If

        If (chkBreath.Checked = True) Then
            dblBreathCost = BREATHCOST
            dblTotalServicesCost += dblBreathCost
        End If

        'returns the total services cost
        Return dblTotalServicesCost

    End Function

    Private Function calculateRegistrationFee(ByVal isNewCustomer As Boolean) As Double

        'if customer is new, then charge them the registration fee
        If isNewCustomer Then
            Return 39.99
        Else
            Return 0
        End If

    End Function

    Private Sub chkChanged(ByVal chkBox As CheckBox, ByVal lblDisplay As Label, ByVal displayValue As Double)

        'display value in passed label with the passed value, depending on if the passed check box is checked
        If chkBox.Checked = True Then
            lblDisplay.Text = FormatCurrency(displayValue, 2)
        Else
            lblDisplay.Text = FormatCurrency(0, 2)
        End If

    End Sub

    Private Sub chkCleaning_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkCleaning.CheckedChanged
        'sub procedure to alter the respective label if the check box is checked/unchecked
        chkChanged(chkCleaning, lblCleaning, CLEANINGCOST)
    End Sub

    Private Sub chkXRay_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkXRay.CheckedChanged
        'sub procedure to alter the respective label if the check box is checked/unchecked
        chkChanged(chkXRay, lblXRay, XRAYCOST)
    End Sub

    Private Sub chkFillings_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFillings.CheckedChanged
        'sub procedure to alter the respective label if the check box is checked/unchecked
        chkChanged(chkFillings, lblFillings, FILLINGCOST)
    End Sub

    Private Sub chkCaps_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkCaps.CheckedChanged
        'sub procedure to alter the respective label if the check box is checked/unchecked
        chkChanged(chkCaps, lblCaps, CAPSCOST)
    End Sub

    Private Sub chkBreath_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkBreath.CheckedChanged
        'sub procedure to alter the respective label if the check box is checked/unchecked
        chkChanged(chkBreath, lblBreath, BREATHCOST)
    End Sub

    Private Sub txtName_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtName.Validating

        'checks to see if the txtbox is an invalid string value
        If txtName.Text = "" Then
            Exit Sub
        ElseIf IsNumeric(txtName.Text) Then
            MessageBox.Show("Please enter a valid value for the Name field", "Error - Numerical Value")
            txtName.Focus()
            txtName.SelectAll()
        End If

    End Sub
End Class