﻿Public Class Splash

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click
        'when the label is clicked, it hides the splash screen and displays the login form
        Me.Hide()
        frmLoginForm1.ShowDialog()
    End Sub
End Class