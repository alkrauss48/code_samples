//Aaron Krauss
//CSE 1341 honors - Fontenot
//Lab packet 4
//this is the main Gui that calls all of the methods and creates the GUI

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MinesweeperGui extends JFrame {
    
    private JLabel lblMinesLeft = new JLabel();
    
    public JButton[][] button = new JButton[16][16];
    public JLabel[][] label = new JLabel[16][16];
    int[][] boxValue = new int[16][16];
    int[][] numRClick = new int[16][16];
    Container contentPane = getContentPane();
    private JButton btnStart = new JButton();
    AwesomeCode code = new AwesomeCode();
    
    

    public MinesweeperGui() {

        this.setLayout(null);
        this.setSize(450, 450);
        this.setTitle("Uber Minesweeper!!!");
        generateBoxValues();
        userInterface();
        this.setVisible(true);
        code.clearRightClicks(numRClick);
        btnStart.addActionListener(new startButton());

    }

    public void userInterface() {

        btnStart.setBounds(180, 10, 80, 30);
        btnStart.setText("Start");
        contentPane.add(btnStart);
        
        lblMinesLeft.setBounds(300,10,100,30);
        lblMinesLeft.setText(code.totalMines + " mines left");
        contentPane.add(lblMinesLeft);

        int vertDistance = 50;

        for (int x = 0; x < 16; x++) {

            int horizDistance = 50;
            for (int y = 0; y < 16; y++) {
                JButton btn = new JButton();
                JLabel lbl = new JLabel();
                btn.setActionCommand((x * 16 + y) + "");
                lbl.setBounds(horizDistance, vertDistance, 20, 20);
                btn.setBounds(horizDistance, vertDistance, 20, 20);
                btn.addMouseListener(new ButtonHandler());
                horizDistance += 20;
                contentPane.add(lbl);
                contentPane.add(btn);
                label[x][y] = lbl;
                button[x][y] = btn;

            }
            vertDistance += 20;
        }


    }

    private class startButton implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            code.enableButtons(button, label);
            generateBoxValues();
            lblMinesLeft.setText(code.totalMines + " mines left");
           
        }
    }

    private class ButtonHandler implements MouseListener {

        

        public void mousePressed(MouseEvent e) {
                
            

            JButton btn = (JButton) e.getSource();
            int id = Integer.parseInt(btn.getActionCommand());
            int x = id / 16;
            int y = id % 16;
            int counter = 0;

            if ((e.getButton() == 1) && (numRClick[x][y] % 2) == 0) {

                if (btn.isEnabled()) {
                    if (boxValue[x][y] == 0) {

                        counter = code.changeBoard(boxValue, button, label, x, y);

                        if (counter == 0) {
                            label[x][y].setIcon(new ImageIcon("blankicon.jpg"));
                        } else {
                            label[x][y].setText(" " + counter);
                        }


                    } else {
                        button[x][y].setVisible(false);
                        label[x][y].setIcon(new ImageIcon("bombicon.jpg"));
                        code.disableButtons(button);
                    }

                }
            } else if (e.getButton() == 3) {
                numRClick[x][y]++;

                if (numRClick[x][y] % 2 == 1) {
                    
                    button[x][y].setIcon(new ImageIcon("flag.gif"));
                    code.totalMines--;
                    lblMinesLeft.setText(code.totalMines + " mines left");
                } else {  
                    button[x][y].setIcon(null);
                    code.totalMines++;
                    lblMinesLeft.setText(code.totalMines + " mines left");
                }
            }

        }

        public void mouseReleased(MouseEvent e) {
        }

        public void mouseEntered(MouseEvent e) {
        }

        public void mouseExited(MouseEvent e) {
        }

        public void mouseClicked(MouseEvent e) {
        }
    }

    public void generateBoxValues() {

        boxValue = code.generateBoard();

    }

    public static void main(String[] args) {
        new MinesweeperGui();
    }
}