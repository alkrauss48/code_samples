//Aaron Krauss
//CSE 1341 honors - Fontenot
// lab packet 4
//This is the underlying code for the minesweeper program

import java.util.Random;
import javax.swing.JButton;
import javax.swing.JLabel;




public class AwesomeCode{
    
    public int totalMines = 0;
    
    public int [][] generateBoard(){
        totalMines = 0;
        
        int board [][] = new int[16][16];
        //clear board to make sure that it is all 0
        for (int a = 0; a < 16; a++){
            for(int b = 0; b < 16; b++){
                    board[a][b] = 0;
            }
        }
        //0 = empty space
        //1 = mine
        
        Random mineGenerator = new Random();
        int numMines = 30 + mineGenerator.nextInt(20);
        
        
        Random mineBoard = new Random ();
        
        //generate mines
        for(int a = 0; a < numMines; a++){
            int x = mineBoard.nextInt(16);
            int y = mineBoard.nextInt(16);
            board[x][y] = 1;
            totalMines++;
        }
        
        //make all non-mine spaces equal to 0
        for (int a = 0; a < 16; a++){
            for(int b = 0; b < 16; b++){
                if(board[a][b] != 1)
                    board[a][b] = 0;
                System.out.print(board[a][b]);
            }
            System.out.println();
        }
        
        System.out.println(totalMines + " total mines");
        
        return board;
        
    }
    
    public void enableButtons(JButton [][] button, JLabel [][] label){
        
        for (int a = 0; a < 16; a++){
            for (int b = 0; b < 16; b++){
                
                button[a][b].setEnabled(true);               
                label[a][b].setText("");
                label[a][b].setIcon(null);
                button[a][b].setVisible(true);
                button[a][b].setIcon(null);
            }
        }
    }
    
    public void clearRightClicks(int [][] numRClicks){
        for (int a = 0; a < 16; a++){
            for (int b = 0; b < 16; b++){
                numRClicks[a][b] = 0;
            }
        }
    }
    
    public void disableButtons(JButton [][] button){
        
        for (int a = 0; a < 16; a++){
            for (int b = 0; b < 16; b++){
                button[a][b].setEnabled(false);
            }
        }
        
    }
   
    public int changeBoard(int [][] boxValue, JButton button[][], JLabel label[][], int x, int y){
        
        int counter = 0;
        button[x][y].setVisible(false);

                //check upper left corner
                if((x == 0) && (y == 0)){
                    if(boxValue[1][0] == 1)
                        counter++;
                    if(boxValue[1][1] == 1)
                        counter++;
                    if(boxValue[0][1] == 1)
                        counter++;
                }
                
                //check upper right corner
                if((x == 0) && (y == 15)){
                    if(boxValue[1][15] == 1)
                        counter++;
                    if(boxValue[1][14] == 1)
                        counter++;
                    if(boxValue[0][14] == 1)
                        counter++;
                }
                
                //check bottom left corner
                if((x == 15) && (y == 0)){
                    if(boxValue[14][0] == 1)
                        counter++;
                    if(boxValue[14][1] == 1)
                        counter++;
                    if(boxValue[15][1] == 1)
                        counter++;
                }
                
                //check bottom right corner
                if((x == 15) && (y == 15)){
                    if(boxValue[15][14] == 1)
                        counter++;
                    if(boxValue[14][14] == 1)
                        counter++;
                    if(boxValue[14][15] == 1)
                        counter++;
                }
                 //check on left side column
                if((y == 0) && ((x != 0) && (x != 15))){
                    for(int a = -1; a <= 1; a++){
                        for(int b = 0; b <= 1; b++){
                        if(boxValue[x+a][y+b] == 1)
                            counter++;
                        }
                    }
                }
                //check on top row
                if((x == 0) && ((y != 0) && (y != 15))){
                    for(int a = -1; a <= 1; a++){
                        for(int b = 0; b <= 1; b++){
                        if(boxValue[x+b][y+a] == 1)
                            counter++;
                        }
                    }
                }
                //check on right side column
                if((y == 15) && ((x != 0) && (x != 15))){
                    for(int a = -1; a <= 1; a++){
                        for(int b = -1; b <= 0; b++){
                        if(boxValue[x + a][y+b] == 1)
                            counter++;
                        }
                    }
                }
                //check on bottom row
                if((x == 15) && ((y != 0) && (y != 15))){
                    for(int a = -1; a <= 1; a++){
                        for(int b = -1; b <= 0; b++){
                        if(boxValue[x+b][y+a] == 1)
                            counter++;
                        }
                    }
                }
                
                for (int a = 1; a >= -1; a--) {
                    for (int b = 1; b >= -1; b--) {
                        if ((x != 0) && (x != 15) && (y != 0) && (y != 15))
                        {
                            if (boxValue[x + a][y + b] == 1) {
                                counter++;
                            }
                        }
                    }
                }
        
        return counter;
    }
}



    
