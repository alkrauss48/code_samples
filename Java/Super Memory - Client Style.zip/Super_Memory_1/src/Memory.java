
import java.util.Random;
import java.util.Scanner;
import javax.swing.ImageIcon;
import java.net.*;
import java.io.*;



/*
 * Memory.java
 *
 * Created on November 10, 2008, 2:05 PM
 */
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author  akrauss
 */
public class Memory extends javax.swing.JFrame {

    /** Creates new form Memory */
    public Memory() {
        initComponents();
        this.setTitle("Memory!!!");
        btnSend.setEnabled(false);
        txtMessage.setEnabled(false);
        grid[0] = new ImageIcon("animal.jpg");
        grid[1] = new ImageIcon("animal.jpg");
        grid[2] = new ImageIcon("car.jpg");
        grid[3] = new ImageIcon("car.jpg");
        grid[4] = new ImageIcon("character.jpg");
        grid[5] = new ImageIcon("character.jpg");
        grid[6] = new ImageIcon("god.jpg");
        grid[7] = new ImageIcon("god.jpg");
        grid[8] = new ImageIcon("window.jpg");
        grid[9] = new ImageIcon("window.jpg");
        grid[10] = new ImageIcon("college.jpg");
        grid[11] = new ImageIcon("college.jpg");
        grid[12] = new ImageIcon("food.jpg");
        grid[13] = new ImageIcon("food.jpg");
        grid[14] = new ImageIcon("godanimal.jpg");
        grid[15] = new ImageIcon("godanimal.jpg");

        numGrid[0] = 1;
        numGrid[1] = 1;
        numGrid[2] = 2;
        numGrid[3] = 2;
        numGrid[4] = 3;
        numGrid[5] = 3;
        numGrid[6] = 4;
        numGrid[7] = 4;
        numGrid[8] = 5;
        numGrid[9] = 5;
        numGrid[10] = 6;
        numGrid[11] = 6;
        numGrid[12] = 7;
        numGrid[13] = 7;
        numGrid[14] = 8;
        numGrid[15] = 8;

        buttonArray[0] = btn11;
        buttonArray[1] = btn12;
        buttonArray[2] = btn13;
        buttonArray[3] = btn14;
        buttonArray[4] = btn21;
        buttonArray[5] = btn22;
        buttonArray[6] = btn23;
        buttonArray[7] = btn24;
        buttonArray[8] = btn31;
        buttonArray[9] = btn32;
        buttonArray[10] = btn33;
        buttonArray[11] = btn34;
        buttonArray[12] = btn41;
        buttonArray[13] = btn42;
        buttonArray[14] = btn43;
        buttonArray[15] = btn44;

        lblMatches.setText("Total Matches: 0");
        lblTries.setText("FAILED Attempts: 0");
        lblScore.setText("Total Score: 0");

    }

    /*public void imageSet(ImageIcon image){
    Random generator = new Random(16);
    
    for(int x = 0; x <16; x++)
    {
    grid[x]= 0;
    }
    for (int x = 0; x <16; x++)
    {
    if (grid[x] == 0)
    {
    int r = generator.nextInt();
    grid [x]= r;
    }
    
    }
    }*/
    
        public void startClient() {
        
        //Store the IP address of the computer running the server
        String ip = "129.119.108.144";
        
        //Create a connection to the computer running the server version
        try {

            connection = new Socket (ip, 8858);       
            
        } catch (Exception e) {
            lblStatus.setText("Error - restart...");
        }

        //Create scanner and printwriter objects from connection
        try {
            
            //Create the output PrintWriter Object
            output = new PrintWriter(connection.getOutputStream(), true);            
            
            //Create a new thread object for the chat client
            ChatClientThread cct = new ChatClientThread(txtaData, connection);
            Thread t = new Thread(cct);
            //Start the Thread - this automatically calls the 
            //run() method in the Thread class along with some other stuff
            t.start(); 
            
            //Enable the buttons if everything goes OK
            btnSend.setEnabled(true);
            txtMessage.setEnabled(true);
            
        } catch (Exception e) {
            lblStatus.setText ("Error2...");
        }
        
    }
    public void swap() {
        Scanner s = new Scanner(System.in);
        Random generator2 = new Random(16);
        ImageIcon temp;
        int temp2;
        JButton temp3;
        int x = 0;
        int y = 0;
        System.out.println(x);
        System.out.println(y);
        int count = Integer.parseInt(JOptionPane.showInputDialog(this, "Please Enter the amount of times" +
                " that you want to shuffle the pictures" +
                "\n (preferably over 50, but below a 5 digit number)"));

        for (int i = 0; i < count; i++) {
            x = generator2.nextInt(16);
            y = generator2.nextInt(16);
            if (x != y) {

                temp = (grid[x]);
                grid[x] = grid[y];
                grid[y] = temp;

                temp2 = numGrid[x];
                numGrid[x] = numGrid[y];
                numGrid[y] = temp2;

                temp3 = buttonArray[x];
                buttonArray[x] = buttonArray[y];
                buttonArray[y] = temp3;



            }
        }
        numTries = 0;
        lblTries.setText("FAILED Attempts: " + numTries);
        numMatches = 0;
        lblMatches.setText("Total Matches: " + numMatches);
        Score = 0;
        lblScore.setText("Total Score: " + Score);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btn21 = new javax.swing.JButton();
        btn34 = new javax.swing.JButton();
        btn43 = new javax.swing.JButton();
        btn41 = new javax.swing.JButton();
        btn12 = new javax.swing.JButton();
        btn42 = new javax.swing.JButton();
        btn13 = new javax.swing.JButton();
        btn24 = new javax.swing.JButton();
        btn23 = new javax.swing.JButton();
        btn32 = new javax.swing.JButton();
        btn14 = new javax.swing.JButton();
        btn11 = new javax.swing.JButton();
        btn33 = new javax.swing.JButton();
        btn31 = new javax.swing.JButton();
        btn22 = new javax.swing.JButton();
        btn44 = new javax.swing.JButton();
        btnChange = new javax.swing.JButton();
        lblMatches = new javax.swing.JLabel();
        lblTries = new javax.swing.JLabel();
        lblScore = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtaData = new javax.swing.JTextArea();
        txtMessage = new javax.swing.JTextField();
        btnSend = new javax.swing.JButton();
        btnCloseConn = new javax.swing.JButton();
        lblStatus = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btn21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn21ActionPerformed(evt);
            }
        });

        btn34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn34ActionPerformed(evt);
            }
        });

        btn43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn43ActionPerformed(evt);
            }
        });

        btn41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn41ActionPerformed(evt);
            }
        });

        btn12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn12ActionPerformed(evt);
            }
        });

        btn42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn42ActionPerformed(evt);
            }
        });

        btn13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn13ActionPerformed(evt);
            }
        });

        btn24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn24ActionPerformed(evt);
            }
        });

        btn23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn23ActionPerformed(evt);
            }
        });

        btn32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn32ActionPerformed(evt);
            }
        });

        btn14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn14ActionPerformed(evt);
            }
        });

        btn11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn11ActionPerformed(evt);
            }
        });

        btn33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn33ActionPerformed(evt);
            }
        });

        btn31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn31ActionPerformed(evt);
            }
        });

        btn22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn22ActionPerformed(evt);
            }
        });

        btn44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn44ActionPerformed(evt);
            }
        });

        btnChange.setText("Change Order");
        btnChange.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChangeActionPerformed(evt);
            }
        });

        txtaData.setColumns(20);
        txtaData.setRows(5);
        jScrollPane1.setViewportView(txtaData);

        btnSend.setText("Send");
        btnSend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSendActionPerformed(evt);
            }
        });

        btnCloseConn.setText("Close Connection");
        btnCloseConn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCloseConnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addComponent(lblMatches, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 132, Short.MAX_VALUE)
                .addComponent(lblTries, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(96, 96, 96))
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCloseConn)
                        .addContainerGap())
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(lblScore, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                            .addComponent(btnChange)
                            .addGap(249, 249, 249))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btn41, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(65, 65, 65)
                                        .addComponent(btn42, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(67, 67, 67)
                                        .addComponent(btn43, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(72, 72, 72)
                                        .addComponent(btn44, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(btn31, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(65, 65, 65)
                                            .addComponent(btn32, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(67, 67, 67)
                                            .addComponent(btn33, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(72, 72, 72)
                                            .addComponent(btn34, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(btn21, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(65, 65, 65)
                                            .addComponent(btn22, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(67, 67, 67)
                                            .addComponent(btn23, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(72, 72, 72)
                                            .addComponent(btn24, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(btn11, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(65, 65, 65)
                                            .addComponent(btn12, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(67, 67, 67)
                                            .addComponent(btn13, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(72, 72, 72)
                                            .addComponent(btn14, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addContainerGap(54, Short.MAX_VALUE)))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(150, 150, 150)
                .addComponent(lblStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                .addComponent(btnSend)
                .addGap(49, 49, 49))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTries, javax.swing.GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
                    .addComponent(lblMatches, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn11, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn12, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn13, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn14, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn21, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn22, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn23, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn24, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn31, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn32, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn33, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn34, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn41, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn42, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn43, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn44, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(btnChange, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblScore, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(lblStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(btnSend)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCloseConn)))
                .addGap(26, 26, 26))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void btn42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn42ActionPerformed
    printPicture(btn42, 13);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn42ActionPerformed

private void btn11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn11ActionPerformed
// TODO add your handling code here:
    printPicture(btn11, 0);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn11ActionPerformed

private void btn33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn33ActionPerformed
    printPicture(btn33, 10);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn33ActionPerformed

private void btn22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn22ActionPerformed
    printPicture(btn22, 5);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn22ActionPerformed

private void btn12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn12ActionPerformed
    printPicture(btn12, 1);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn12ActionPerformed

private void btn13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn13ActionPerformed
    printPicture(btn13, 2);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn13ActionPerformed

private void btn14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn14ActionPerformed
    printPicture(btn14, 3);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn14ActionPerformed

private void btn21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn21ActionPerformed
    printPicture(btn21, 4);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn21ActionPerformed

private void btn23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn23ActionPerformed
    printPicture(btn23, 6);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn23ActionPerformed

private void btn24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn24ActionPerformed
    printPicture(btn24, 7);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn24ActionPerformed

private void btn31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn31ActionPerformed
    printPicture(btn31, 8);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn31ActionPerformed

private void btn32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn32ActionPerformed
    printPicture(btn32, 9);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn32ActionPerformed

private void btn34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn34ActionPerformed
    printPicture(btn34, 11);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn34ActionPerformed

private void btn41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn41ActionPerformed
    printPicture(btn41, 12);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn41ActionPerformed

private void btn43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn43ActionPerformed
    printPicture(btn43, 14);
    matchCheck();
    clearButtons();
}//GEN-LAST:event_btn43ActionPerformed

private void btn44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn44ActionPerformed
    printPicture(btn44, 15);
    matchCheck();
    clearButtons();

}//GEN-LAST:event_btn44ActionPerformed

private void btnChangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChangeActionPerformed
    for (int x = 0; x < 16; x++) {
        buttonArray[x].setEnabled(true);
        buttonArray[x].setIcon(null);

    }
    swap();
}//GEN-LAST:event_btnChangeActionPerformed

private void btnSendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSendActionPerformed
output.println(txtMessage.getText());
    
    //append the message to this textbox. 
    txtaData.append("YOU: " + txtMessage.getText() + "\n");
    output.println(txtMessage.getText());
    
 
    // TODO add your handling code here:
}//GEN-LAST:event_btnSendActionPerformed

private void btnCloseConnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseConnActionPerformed
// TODO add your handling code here:
      output.println("quit123");
}//GEN-LAST:event_btnCloseConnActionPerformed

    private void clearButtons() {
        if ((turn == 2) && (choice1 != choice2)) {
            lastClicked[0].setIcon(null);
            lastClicked[1].setIcon(null);

        }
        if (turn == 2) {
            turn = 0;
        }
    }

    private void matchCheck() {

        if (turn > 1) {

            if (lastClicked[0] != lastClicked[1]) {

                if (choice1 == choice2) {
                    JOptionPane.showMessageDialog(this, "Yay, you got something right!!", "Freaking Awesome!", 1);
                    lblMatches.setText("Total Matches: " + ++numMatches);
                    Score += 1000;
                    lblScore.setText("Total Score: " + Score);
                    lastClicked[0].setEnabled(false);
                    lastClicked[1].setEnabled(false);
                    choice1 = 0;
                    choice2 = 0;

                } else {
                    JOptionPane.showMessageDialog(this, "Wrong!", "Oops!", 1);
                    lblTries.setText("FAILED Attempts: " + ++numTries);
                    Score -= 200;
                    lblScore.setText("Total Score: " + Score);

                }

            } else {
                JOptionPane.showMessageDialog(this, "Dummy, don't click the same box!" +
                        "\n Point deduction for being dumb");
                turn--;
                Score -= 100;
                lblScore.setText("Total Score: " + Score);
                lastClicked[1] = null;
            }

        }
        if (numMatches == 8) {
            txtaData.append(" \nClient has won with a score of " + Score + "\n" + "Can you beat him?");
            output.println("Client has won with a score of " + Score + "\n" + "Can you beat him?");
            JOptionPane.showMessageDialog(this, "Grats to you winner! Play again now" +
                    "\n Your total score is: " + Score, "You're Awesome!", 1);
            
        }
    }

    public void printPicture(JButton btn, int x) {
        btn.setIcon(grid[x]);
        turn++;
        if (turn == 1) {
            lastClicked[0] = btn;
            choice1 = numGrid[x];
        } else {
            lastClicked[1] = btn;
            choice2 = numGrid[x];

        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                //new Memory().setVisible(true);
                Memory cs = new Memory();
                cs.setVisible(true);
                cs.startClient();
                
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn11;
    private javax.swing.JButton btn12;
    private javax.swing.JButton btn13;
    private javax.swing.JButton btn14;
    private javax.swing.JButton btn21;
    private javax.swing.JButton btn22;
    private javax.swing.JButton btn23;
    private javax.swing.JButton btn24;
    private javax.swing.JButton btn31;
    private javax.swing.JButton btn32;
    private javax.swing.JButton btn33;
    private javax.swing.JButton btn34;
    private javax.swing.JButton btn41;
    private javax.swing.JButton btn42;
    private javax.swing.JButton btn43;
    private javax.swing.JButton btn44;
    private javax.swing.JButton btnChange;
    private javax.swing.JButton btnCloseConn;
    private javax.swing.JButton btnSend;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblMatches;
    private javax.swing.JLabel lblScore;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblTries;
    private javax.swing.JTextField txtMessage;
    private javax.swing.JTextArea txtaData;
    // End of variables declaration//GEN-END:variables
    ImageIcon[] grid = new ImageIcon[16];
    int[] numGrid = new int[16];
    JButton[] buttonArray = new JButton[16];
    JButton[] lastClicked = new JButton[2];
    int choice1 = 0;
    int choice2 = 0;
    int turn = 0;
    int numMatches = 0;
    int numTries = 0;
    int Score = 0;
    Socket connection;
    Scanner input;
    PrintWriter output;
}
