
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;



public class ChatClientThread implements Runnable {

    JTextArea messages;
    Socket client;
    Scanner reader;
    
    
    public ChatClientThread (JTextArea t, Socket s) {
        messages = t;
        client = s;
    }
    
    public void run() {
        System.out.println ("In Run of Thread");
        try {
            reader = new Scanner(client.getInputStream());
        } catch (IOException ex) {
            System.out.println("Error in thread...");
        }
        
        while (true) {
            System.out.println("Waiting for a message...");
            String temp = reader.nextLine();
            if (temp.equals("quit123")) {
                return;
            } else 
                messages.append("THEM: " + temp + "\n");
            System.out.println("Just recieved: " + temp);
            
        }
        
        
    }
    
    
    
    
}