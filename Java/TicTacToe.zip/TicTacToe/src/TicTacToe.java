
import java.awt.*;
import javax.swing.*;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import java.util.Random;
 


/*
 * TicTacToe.java
 *
 * Created on November 3, 2008, 1:14 PM
 */
/**
 *
 * @author  Michael and Aaron
 */
public class TicTacToe extends javax.swing.JFrame {

    int[][] board = new int[3][3];
    int turn = 1;

    public void printArray(int[][] board) {
        for (int x = 0; x < 3; x++) {
            for (int y = 0; y < 3; y++) {
                System.out.print(board[x][y]);
            }
            System.out.println("");
        }
    }

    public void winCheck() {

        Graphics g = this.getGraphics();
        int val1 = board[0][0];
        int val2 = board[0][1];
        int val3 = board[0][2];
        int val4 = board[1][0];
        int val5 = board[1][1];
        int val6 = board[1][2];
        int val7 = board[2][0];
        int val8 = board[2][1];
        int val9 = board[2][2];

        if (val1 == val2 && val2 == val3 && val1 == 1) {
            
            jLabel2.setText("Player One Wins");
            
            buttonDisable();
            g.setColor(Color.RED);
            g.drawLine(350, 150, 50, 150);
            btnGetReward.setEnabled(true);
            
        } else if (val1 == val2 && val2 == val3 && val1 == 2) {
            
            jLabel2.setText("Player Two Wins");
           
            buttonDisable();
            g.setColor(Color.BLUE);
            g.drawLine(350, 150, 50, 150);
            btnGetReward.setEnabled(true);
            
        }
        if (val4 == val5 && val5 == val6 && val4 == 1) {
            
            jLabel2.setText("Player One Wins");
            g.setColor(Color.RED);
            g.drawLine(350, 220, 50, 220);
            buttonDisable();
            btnGetReward.setEnabled(true);
        } else if (val4 == val5 && val5 == val6 && val4 == 2) {
            
            jLabel2.setText("Player Two Wins");
            g.setColor(Color.BLUE);
            g.drawLine(350, 220, 50, 220);
            buttonDisable();
            btnGetReward.setEnabled(true);
        }
        if (val7 == val8 && val8 == val9 && val7 == 1) {
            jLabel2.setText("Player One Wins");
            g.setColor(Color.RED);
            g.drawLine(350, 305, 50, 305);
            buttonDisable();        
            btnGetReward.setEnabled(true);
        } else if (val7 == val8 && val8 == val9 && val7 == 2) {
            
            jLabel2.setText("Player Two Wins");
            g.setColor(Color.BLUE);
            g.drawLine(350, 305, 50, 305);
            buttonDisable();
            btnGetReward.setEnabled(true);
        }
        if (val1 == val4 && val4 == val7 && val1 == 1) {
            jLabel2.setText("Player One Wins");
            g.setColor(Color.RED);
            g.drawLine(100, 70, 100, 350);
            buttonDisable();
            btnGetReward.setEnabled(true);
        } else if (val1 == val4 && val4 == val7 && val1 == 2) {
            jLabel2.setText("Player Two Wins");
            g.setColor(Color.BLUE);
            g.drawLine(100, 70, 100, 350);
            buttonDisable();
            btnGetReward.setEnabled(true);
        }
        if (val2 == val5 && val5 == val8 && val2 == 1) {
            jLabel2.setText("Player One Wins");
            g.setColor(Color.RED);
            g.drawLine(180, 70, 180, 350);
            buttonDisable();
            btnGetReward.setEnabled(true);
        } else if (val2 == val5 && val5 == val8 && val2 == 2) {
            jLabel2.setText("Player Two Wins");
            g.setColor(Color.BLUE);
            g.drawLine(180, 70, 180, 350);
            buttonDisable();
            btnGetReward.setEnabled(true);
        }
        if (val3 == val6 && val6 == val9 && val3 == 1) {
            jLabel2.setText("Player One Wins");
            g.setColor(Color.RED);
            g.drawLine(260, 70, 260, 350);
            buttonDisable();
            btnGetReward.setEnabled(true);
        } else if (val3 == val6 && val6 == val9 && val3 == 2) {
            jLabel2.setText("Player Two Wins");
            g.setColor(Color.BLUE);
            g.drawLine(260, 70, 260, 350);
            buttonDisable();
            btnGetReward.setEnabled(true);
        }
        if (val1 == val5 && val5 == val9 && val1 == 1) {
            jLabel2.setText("Player One Wins");
            g.setColor(Color.RED);
            g.drawLine(50, 90, 315, 345);
            buttonDisable();
            btnGetReward.setEnabled(true);
        } else if (val1 == val5 && val5 == val9 && val1 == 2) {
            jLabel2.setText("Player Two Wins");
            g.setColor(Color.BLUE);
            g.drawLine(50, 90, 315, 345);
            buttonDisable();
            btnGetReward.setEnabled(true);
        }
        if (val3 == val5 && val5 == val7 && val3 == 1) {
            jLabel2.setText("Player One Wins");
            g.setColor(Color.RED);
            g.drawLine(50, 345, 315, 90);
            buttonDisable();
            btnGetReward.setEnabled(true);
        } else if (val3 == val5 && val5 == val7 && val3 == 2) {
            jLabel2.setText("Player Two Wins");
            g.setColor(Color.BLUE);
            g.drawLine(50, 345, 315, 90);
            buttonDisable();
            btnGetReward.setEnabled(true);
        }
        
        
    }

    public void Indicator() {
        if ((turn + 1) % 2 == 0) {
            btnIndic.setIcon(new ImageIcon("two.jpg"));
        } else {
            btnIndic.setIcon(new ImageIcon("one.jpg"));
        }
    }

    public void buttonDisable() {
        btnOne.setEnabled(false);
        btnTwo.setEnabled(false);
        btnThree.setEnabled(false);
        btnFour.setEnabled(false);
        btnFive.setEnabled(false);
        btnSix.setEnabled(false);
        btnSeven.setEnabled(false);
        btnEight.setEnabled(false);
        btnNine.setEnabled(false);
        btnStart.setEnabled(false);
        
        
    }

    /** Creates new form TicTacToe */
    public TicTacToe() {
        this.setTitle("Awesome Tic-Tac-Toe Game");
        this.setBackground(Color.WHITE);
        initComponents();
        lblRed.setBackground(Color.RED);
        lblBlue.setBackground(Color.BLUE);

        btnOne.setIcon(new ImageIcon("zero.jpg"));
        btnTwo.setIcon(new ImageIcon("zero.jpg"));
        btnThree.setIcon(new ImageIcon("zero.jpg"));
        btnFour.setIcon(new ImageIcon("zero.jpg"));
        btnFive.setIcon(new ImageIcon("zero.jpg"));
        btnSix.setIcon(new ImageIcon("zero.jpg"));
        btnSeven.setIcon(new ImageIcon("zero.jpg"));
        btnEight.setIcon(new ImageIcon("zero.jpg"));
        btnNine.setIcon(new ImageIcon("zero.jpg"));
        btnIndic.setIcon(new ImageIcon("zero.jpg"));
        
        btnOneClicked = false;
        btnTwoClicked = false;
        btnThreeClicked = false;
        btnFourClicked = false;
        btnFiveClicked = false;
        btnSixClicked = false;
        btnSevenClicked = false;
        btnEightClicked = false;
        btnNineClicked = false;
    }
    

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnOne = new javax.swing.JButton();
        btnSix = new javax.swing.JButton();
        btnSeven = new javax.swing.JButton();
        btnStart = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        btnThree = new javax.swing.JButton();
        btnNine = new javax.swing.JButton();
        btnTwo = new javax.swing.JButton();
        btnFour = new javax.swing.JButton();
        btnFive = new javax.swing.JButton();
        btnEight = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        btnIndic = new javax.swing.JButton();
        btnGetReward = new javax.swing.JToggleButton();
        lblPic = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lblRed = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lblBlue = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnOne.setEnabled(false);
        btnOne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOneActionPerformed(evt);
            }
        });

        btnSix.setEnabled(false);
        btnSix.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSixActionPerformed(evt);
            }
        });

        btnSeven.setEnabled(false);
        btnSeven.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSevenActionPerformed(evt);
            }
        });

        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        btnThree.setEnabled(false);
        btnThree.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThreeActionPerformed(evt);
            }
        });

        btnNine.setEnabled(false);
        btnNine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNineActionPerformed(evt);
            }
        });

        btnTwo.setEnabled(false);
        btnTwo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTwoActionPerformed(evt);
            }
        });

        btnFour.setEnabled(false);
        btnFour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFourActionPerformed(evt);
            }
        });

        btnFive.setEnabled(false);
        btnFive.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFiveActionPerformed(evt);
            }
        });

        btnEight.setEnabled(false);
        btnEight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEightActionPerformed(evt);
            }
        });

        btnGetReward.setText("Get Reward!");
        btnGetReward.setEnabled(false);
        btnGetReward.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGetRewardActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Player 1");

        lblRed.setBackground(new java.awt.Color(204, 0, 0));
        lblRed.setForeground(new java.awt.Color(255, 0, 0));
        lblRed.setText("Red    ");

        jLabel4.setText("Player 2");

        lblBlue.setBackground(new java.awt.Color(0, 0, 204));
        lblBlue.setForeground(new java.awt.Color(0, 0, 255));
        lblBlue.setText("Blue    ");

        jLabel3.setText("X");

        jLabel5.setText("O");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(btnGetReward))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblBlue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(lblRed, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(btnOne, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnTwo, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(btnSeven, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btnFour, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnFive, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSix, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnThree, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(btnIndic, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(93, 93, 93)
                                    .addComponent(btnEight, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnNine, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblPic, javax.swing.GroupLayout.DEFAULT_SIZE, 61, Short.MAX_VALUE)
                .addContainerGap())
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnClear, btnEight, btnFive, btnFour, btnNine, btnOne, btnSeven, btnSix, btnStart, btnThree, btnTwo});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblRed)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(24, 24, 24)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblBlue)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addContainerGap(283, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnGetReward)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(17, 17, 17)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnTwo, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnThree, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnOne, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnFive, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSix, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnFour, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnNine, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeven, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnEight, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnIndic, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(108, 108, 108))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblPic, javax.swing.GroupLayout.PREFERRED_SIZE, 478, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void btnOneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOneActionPerformed
    if(!btnOneClicked){
        turn += 1;
        Indicator();
    //    btnOne.setEnabled(false);
        if (turn % 2 == 0) {
            board[0][0] = 2;
            btnOne.setIcon(new ImageIcon("two.jpg"));
        } else {
            board[0][0] = 1;
            btnOne.setIcon(new ImageIcon("one.jpg"));
        }

        System.out.print(turn);
        winCheck();
    }
    btnOneClicked = true;
}//GEN-LAST:event_btnOneActionPerformed

private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
    printArray(board);
    Graphics clear = this.getGraphics();
    
    for (int x = 0; x < 3; x++) {
        for (int y = 0; y < 3; y++) {
            board[x][y] = 0;
        }
    }
    btnOne.setIcon(new ImageIcon("zero.jpg"));
    btnTwo.setIcon(new ImageIcon("zero.jpg"));
    btnThree.setIcon(new ImageIcon("zero.jpg"));
    btnFour.setIcon(new ImageIcon("zero.jpg"));
    btnFive.setIcon(new ImageIcon("zero.jpg"));
    btnSix.setIcon(new ImageIcon("zero.jpg"));
    btnSeven.setIcon(new ImageIcon("zero.jpg"));
    btnEight.setIcon(new ImageIcon("zero.jpg"));
    btnNine.setIcon(new ImageIcon("zero.jpg"));
    btnIndic.setIcon(new ImageIcon("zero.jpg"));

    jLabel2.setText("");

    btnOne.setEnabled(false);
    btnTwo.setEnabled(false);
    btnThree.setEnabled(false);
    btnFour.setEnabled(false);
    btnFive.setEnabled(false);
    btnSix.setEnabled(false);
    btnSeven.setEnabled(false);
    btnEight.setEnabled(false);
    btnNine.setEnabled(false);
    btnStart.setEnabled(true);
    btnGetReward.setEnabled(false);
    
    lblPic.setIcon(new ImageIcon("white.jpg"));
    this.setBounds(0,0,373,450);
    
    clear.setColor(Color.WHITE);
    clear.drawLine(350, 150, 50, 150);
    clear.drawLine(350, 220, 50, 220);
    clear.drawLine(350, 305, 50, 305);
    clear.drawLine(100, 70, 100, 350);
    clear.drawLine(180, 70, 180, 350);
    clear.drawLine(260, 70, 260, 350);
    clear.drawLine(50, 90, 315, 345);
    clear.drawLine(50, 345, 315, 90);
    
    btnOneClicked = false;
    btnTwoClicked = false;
    btnThreeClicked = false;
    btnFourClicked = false;
    btnFiveClicked = false;
    btnSixClicked = false;
    btnSevenClicked = false;
    btnEightClicked = false;
    btnNineClicked = false;
    
}//GEN-LAST:event_btnClearActionPerformed

private void btnTwoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTwoActionPerformed
    if(!btnTwoClicked){
    turn += 1;
    Indicator();
    if (turn % 2 == 0) {
        board[0][1] = 2;
        btnTwo.setIcon(new ImageIcon("two.jpg"));
    } else {
        board[0][1] = 1;
        btnTwo.setIcon(new ImageIcon("one.jpg"));
    }
    System.out.print(turn);
    
    winCheck();
               
    }
    btnTwoClicked = true;

}//GEN-LAST:event_btnTwoActionPerformed

private void btnThreeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThreeActionPerformed
   if(!btnThreeClicked){
    turn += 1;
    Indicator();
    if (turn % 2 == 0) {
        board[0][2] = 2;
        btnThree.setIcon(new ImageIcon("two.jpg"));
    } else {
        board[0][2] = 1;
        btnThree.setIcon(new ImageIcon("one.jpg"));
    }
    System.out.print(turn);
    winCheck();
   }
   btnThreeClicked = true; 
}//GEN-LAST:event_btnThreeActionPerformed

private void btnFourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFourActionPerformed
    if(!btnFourClicked){
    turn += 1;
    Indicator();
    if (turn % 2 == 0) {
        board[1][0] = 2;
        btnFour.setIcon(new ImageIcon("two.jpg"));
    } else {
        board[1][0] = 1;
        btnFour.setIcon(new ImageIcon("one.jpg"));
    }
    System.out.print(turn);
    winCheck();
    }
    btnFourClicked = true;
}//GEN-LAST:event_btnFourActionPerformed

private void btnFiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFiveActionPerformed
    if(!btnFiveClicked){
    turn += 1;
    Indicator();
    if (turn % 2 == 0) {
        board[1][1] = 2;
        btnFive.setIcon(new ImageIcon("two.jpg"));
    } else {
        board[1][1] = 1;
        btnFive.setIcon(new ImageIcon("one.jpg"));
    }
    System.out.print(turn);
    winCheck();
    }
    btnFiveClicked = true;
}//GEN-LAST:event_btnFiveActionPerformed

private void btnSixActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSixActionPerformed
    if(!btnSixClicked){
    turn += 1;
    Indicator();
    if (turn % 2 == 0) {
        board[1][2] = 2;
        btnSix.setIcon(new ImageIcon("two.jpg"));
    } else {
        board[1][2] = 1;
        btnSix.setIcon(new ImageIcon("one.jpg"));
    }
    System.out.print(turn);
    winCheck();
    }
    btnSixClicked = true;
}//GEN-LAST:event_btnSixActionPerformed

private void btnSevenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSevenActionPerformed
    if(!btnSevenClicked){
    turn += 1;
    Indicator();
    if (turn % 2 == 0) {
        board[2][0] = 2;
        btnSeven.setIcon(new ImageIcon("two.jpg"));
    } else {
        board[2][0] = 1;
        btnSeven.setIcon(new ImageIcon("one.jpg"));
    }
    System.out.print(turn);
    winCheck();
    }
    btnSevenClicked = true;
}//GEN-LAST:event_btnSevenActionPerformed

private void btnEightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEightActionPerformed
    if(!btnEightClicked){
    turn += 1;
    Indicator();
    if (turn % 2 == 0) {
        board[2][1] = 2;
        btnEight.setIcon(new ImageIcon("two.jpg"));
    } else {
        board[2][1] = 1;
        btnEight.setIcon(new ImageIcon("one.jpg"));
    }
    System.out.print(turn);
    winCheck();
    }
    btnEightClicked = true;
}//GEN-LAST:event_btnEightActionPerformed

private void btnNineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNineActionPerformed
    if(!btnNineClicked){
    turn += 1;
    
    Indicator();
    if (turn % 2 == 0) {
        board[2][2] = 2;
        btnNine.setIcon(new ImageIcon("two.jpg"));
    } else {
        board[2][2] = 1;
        btnNine.setIcon(new ImageIcon("one.jpg"));
    }
    System.out.print(turn);
    winCheck();
    }
    btnNineClicked = true;
}//GEN-LAST:event_btnNineActionPerformed

private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
    btnStart.setEnabled(false);
    btnOne.setEnabled(true);
    btnTwo.setEnabled(true);
    btnThree.setEnabled(true);
    btnFour.setEnabled(true);
    btnFive.setEnabled(true);
    btnSix.setEnabled(true);
    btnSeven.setEnabled(true);
    btnEight.setEnabled(true);
    btnNine.setEnabled(true);
    
    Indicator();
}//GEN-LAST:event_btnStartActionPerformed

private void btnGetRewardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGetRewardActionPerformed
// TODO add your handling code here:
    Random randomGenerator = new Random();
    int randomInt = randomGenerator.nextInt(3);
    this.setBounds(0,0,900,650);
    lblPic.setBounds(350,100,600,500);
    
    if(randomInt == 0)
        lblPic.setIcon(new ImageIcon ("win.jpg"));
    
    else if (randomInt == 1)
        lblPic.setIcon(new ImageIcon ("win1.jpg"));
    
    else
        lblPic.setIcon(new ImageIcon ("win2.jpg"));
    
    lblPic.setHorizontalAlignment(JLabel.CENTER);
    btnGetReward.setEnabled(false);
}//GEN-LAST:event_btnGetRewardActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new  

              Runnable() {

                 public void run() {
                new TicTacToe().setVisible(true);
                
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnEight;
    private javax.swing.JButton btnFive;
    private javax.swing.JButton btnFour;
    private javax.swing.JToggleButton btnGetReward;
    private javax.swing.JButton btnIndic;
    private javax.swing.JButton btnNine;
    private javax.swing.JButton btnOne;
    private javax.swing.JButton btnSeven;
    private javax.swing.JButton btnSix;
    private javax.swing.JButton btnStart;
    private javax.swing.JButton btnThree;
    private javax.swing.JButton btnTwo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel lblBlue;
    private javax.swing.JLabel lblPic;
    private javax.swing.JLabel lblRed;
    // End of variables declaration//GEN-END:variables
    
    private boolean btnOneClicked;
    private boolean btnTwoClicked;
    private boolean btnThreeClicked;
    private boolean btnFourClicked;
    private boolean btnFiveClicked;
    private boolean btnSixClicked;
    private boolean btnSevenClicked;
    private boolean btnEightClicked;
    private boolean btnNineClicked;
}
