import icommand.navigation.Pilot;
import icommand.nxt.ColorSensor;
import icommand.nxt.LightSensor;
import icommand.nxt.Motor;
import icommand.nxt.TouchSensor;

public class HardcoreCode {
    public static int LR = 0;
    public static int yellowTapeMax;
    public static int yellowTapeMin;
    public static int redTapeMax;
    public static int redTapeMin;
    public static int groundMax;
    public static int groundMin;



    //public static int tapeColor = 450;
    //public static int centerLineColor = 450;
    
    public static void setColorValues(int g1,int g2,int i1,int i2,int c1,int c2){
    yellowTapeMax = i2;
    yellowTapeMin = i1;
    redTapeMax = c2;
    redTapeMin = c1;
    groundMax = g2;
    groundMin = g1;
    }
    public static void parallelToLine(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException {
        cd.setSpeed(150);
        boolean yellowLine = false;

        //while (yellowLine == false) {

            while (L1.getLightValue() < groundMax && L1.getLightValue() > groundMin) {
                System.out.println("Currente light value is: " + L1.getLightValue());
                cd.forward();
                //if (T1.isPressed() == true || T2.isPressed() == true) {
                if (T1.isPressed() == true || T2.isPressed() == true) {
                    cd.travel(-350);

                cd.rotate(90);
                }
                cd.forward();
            }

            
//             if (L1.getLightValue() < yellowTapeMax && L1.getLightValue() > yellowTapeMin) {
//                System.out.println("tape light value is: " + L1.getLightValue());
//                yellowLine = true;
//            }else if (L1.getLightValue() < redTapeMax && L1.getLightValue() > redTapeMin) {
//                System.out.println("tape light value is: " + L1.getLightValue());
//                cd.travel(-800);
//                
//            }
//
//
//        }
        cd.stop();
    }
    public static void followLine(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException {
        cd.setSpeed(150);
        int numRotations = 0;

        while ((T1.isPressed() == false && T2.isPressed() == false)) {
            while (L1.getLightValue() > yellowTapeMin && L1.getLightValue() < yellowTapeMax && (T1.isPressed() == false && T2.isPressed() == false)) {
                System.out.println("Currente light value is: " + L1.getLightValue());
                
                cd.forward();
            }

            while ((L1.getLightValue() < groundMax)) {
                System.out.println("Currente light value is: " + L1.getLightValue());
                cd.setSpeed(150);
                cd.stop();
                Motor.A.rotate(10);
                numRotations++;
                if (numRotations >= 14) {
                    while ((L1.getLightValue() < groundMax)) {
                        System.out.println("Currente light value is: " + L1.getLightValue());
                        Motor.B.rotate(10);
                    }

                }
            }
            numRotations = 0;
            cd.forward();
        }
    }

    public static void afterFollowLineUntilCenterLine(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException {
        cd.setSpeed(200);
        
        cd.travel(-350);
        
        cd.setSpeed(50);
        cd.rotate(90);
        cd.setSpeed(150);
        
        //Thread.sleep(1000);
        while (L1.getLightValue() > redTapeMax || L1.getLightValue() < redTapeMin) { // this is the CENTER line Light Value - may need to be a range
            System.out.println("Current light value is: " + L1.getLightValue());
            while ((T1.isPressed() == false && T2.isPressed() == false && (L1.getLightValue() > redTapeMax || L1.getLightValue() < redTapeMin))) {
                System.out.println("Current light value is: " + L1.getLightValue());
                
                cd.forward();
            }
            if ((T1.isPressed() == true && T2.isPressed() == true)) {
                //while (T1.isPressed() == true && T2.isPressed() == true) {
                    //cd.backward();
                //}
                
                cd.travel(-130);
                cd.setSpeed(50);
                cd.rotate(180);
                cd.setSpeed(150);
                LR=1;
                
            }

        }
        
        System.out.println("found center line");
        System.out.println(L1.getLightValue());
        cd.stop();

    }

    public static void afterCenterLine(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException {
    cd.setSpeed(150);
        while (C1.getColorNumber() == 0 || C1.getColorNumber() == 17) {
            if(LR==0){
                    cd.setSpeed(50);
                cd.rotate(90);
                    cd.setSpeed(150);
                cd.travel(762);
                    cd.setSpeed(50);
                cd.rotate(-90);
                    cd.setSpeed(150);
            }
            else if(LR==1){
                    cd.setSpeed(50);
                cd.rotate(-90);
                    cd.setSpeed(150);
                cd.travel(762);
                    cd.setSpeed(50);
                cd.rotate(90);
                    cd.setSpeed(150);
            }    
            while (T1.isPressed() == false && T2.isPressed() == false) {
                cd.forward();
            }
            while(L1.getLightValue() > redTapeMax && L1.getLightValue() < redTapeMin){ //center light value
                cd.backward();
            }
            if(LR==0){
                sweepRight(cd, T1, T2, C1, L1);
            }
            if(LR==1){
                sweepLeft(cd, T1, T2, C1, L1);
            }
            while (T1.isPressed() == false && T2.isPressed() == false) {
                cd.forward();
            }
            while(L1.getLightValue() > redTapeMax && L1.getLightValue() < redTapeMin){ //center light value
                cd.backward();
            }
            if(LR==0){
                sweepRight(cd, T1, T2, C1, L1);
            }
            if(LR==1){
                sweepLeft(cd, T1, T2, C1, L1);
            }
            while (T1.isPressed() == false && T2.isPressed() == false) {
                cd.forward();
            }
            

//            if (C1.getColorNumber() == 0 || C1.getColorNumber() == 17) {
//                while (T1.isPressed() == true && T2.isPressed() == true) {
//                    cd.backward();
//                }
//                cd.rotate(180);
//                cd.forward();
//            } else if (C1.getColorNumber() == 4) {
//                while (L1.getLightValue() < 450) { //this should be the center line value, not 450. only for testing purposes is it 450
//
//                    cd.backward(); //this should be changed since the robot will have to be moved back
//                //A SET DISTANCE for the shooter to hit the box, as opposed to moving back
//                //merely to the center line
//
//                }
//            }
        }
        
    }
    public static void sweepLeft(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException{
        cd.setSpeed(50);
        cd.rotate(90);
        cd.setSpeed(150);
        cd.travel(600);
        cd.setSpeed(50);
        cd.rotate(-90);
        cd.setSpeed(150);
    }
    public static void sweepRight(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException{
        cd.setSpeed(50);
        cd.rotate(-90);
        cd.setSpeed(150);
        cd.travel(600);
        cd.setSpeed(50);
        cd.rotate(90);
        cd.setSpeed(150);
    }

    public static void shoot(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException {
        cd.setSpeed(150);
        cd.travel(-2500);
        //rotate shooter motor
        Motor.C.rotate(90);
        Motor.C.rotate(90);
        Motor.C.rotate(90);
        Motor.C.rotate(90);
        Motor.C.rotate(90);
        Motor.C.rotate(90);
        Motor.C.rotate(90);
        Motor.C.rotate(90);
        Motor.C.rotate(90);
        Motor.C.rotate(90);


    }
    public static void afterCenterLine2(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException {
        
        while(T1.isPressed()==false&&T2.isPressed()==false){
            for(int i = 0; i < 9; i++ ){
                cd.setSpeed(150);
                cd.travel(200);
                if(T1.isPressed()==true||T2.isPressed()==true)
                    return;
            }
            
            //cd.rotate(10);
            cd.travel(-1800);
            if(LR==0){
                   sweepLeft(cd, T1, T2, C1, L1);
            }
            else if(LR==1){
                    sweepRight(cd, T1, T2, C1, L1);
            }
        }    
    }
    
}

