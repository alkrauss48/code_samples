
import icommand.navigation.Pilot;
import icommand.nxt.ColorSensor;
import icommand.nxt.LightSensor;
import icommand.nxt.Motor;
import icommand.nxt.SensorPort;
import icommand.nxt.TouchSensor;
import icommand.nxt.comm.NXTCommand;

public class MainAwesomeness {

    
    public static void start(int g1, int g2, int i1, int i2, int c1, int c2) throws InterruptedException{
        
        System.out.println("start method called");
        NXTCommand.open();
        
        HardcoreCode.setColorValues(g1,g2,i1,i2,c1,c2);

        TouchSensor T1 = new TouchSensor(SensorPort.S1);
        TouchSensor T2 = new TouchSensor(SensorPort.S2);
        LightSensor L1 = new LightSensor(SensorPort.S3);
        ColorSensor C1 = new ColorSensor(SensorPort.S4);

        {
            Pilot cd = new Pilot(56, 120, Motor.A, Motor.B);

            //RobotTesting.moveBeforeBox(cd, T1, T2, C1, L1);
           // RobotTesting.testLightValue(cd, T1, T2, C1, L1);
            //RobotTesting.dTillLight(cd, T1, T2, C1, L1);
            //RobotTesting.testColorValue(cd, T1, T2, C1, L1);
                 //RobotTesting.testColor(cd, T1, T2, C1, L1);
            HardcoreCode.parallelToLine(cd, T1, T2, C1, L1);
            HardcoreCode.followLine(cd, T1, T2, C1, L1);
            HardcoreCode.afterFollowLineUntilCenterLine(cd, T1, T2, C1, L1);
                  //HardcoreCode.afterCenterLine(cd, T1, T2, C1, L1);
            HardcoreCode.afterCenterLine2(cd, T1, T2, C1, L1);
            HardcoreCode.shoot(cd, T1, T2, C1, L1);
            //RobotTesting.testDistance(cd, T1, T2, C1, L1);
            
            
        }



        NXTCommand.close();
    }
    
    public static void testLights() throws InterruptedException{
        NXTCommand.open();
        
        TouchSensor T1 = new TouchSensor(SensorPort.S1);
        TouchSensor T2 = new TouchSensor(SensorPort.S2);
        LightSensor L1 = new LightSensor(SensorPort.S3);
        ColorSensor C1 = new ColorSensor(SensorPort.S4);
         Pilot cd = new Pilot(56, 120, Motor.A, Motor.B);
         
        RobotTesting.testLightValue(cd, T1, T2, C1, L1);
        
        NXTCommand.close();
    }

//    public static void getToCenter(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) {
//        int LorR = 0;
//        System.out.println("light value: " + L1.getLightValue());
//
//        while ((L1.getLightValue() > 300) && (L1.getLightValue() < 700)) {
//            while (T1.isPressed() == false && T2.isPressed() == false) {
//                cd.forward();
//
//            }
//            if (T1.isPressed() == true && T2.isPressed() == true) {
//                LorR = 3;
//            } else if (T1.isPressed() == true && T2.isPressed() == false) {
//                LorR = 1;
//            } else if (T2.isPressed() == true && T1.isPressed() == false) {
//                LorR = 2;
//            }
//            while (T1.isPressed() == true || T2.isPressed() == true) {
//                cd.backward();
//            }
//
//            if (LorR == 3) {
//                return;
//            } else if (LorR == 1) {
//                Motor.A.rotateTo(1);
//            } else if (LorR == 2) {
//                Motor.B.rotateTo(1);
//            }
//        }
////       if(L1.getLightValue()<1000&&L1.getLightValue()>0){
////           while(T1.isPressed()==false&&T2.isPressed()==false){
////               
////           }
////       }
//    }
//
//    public static void getToCorner(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) {
//        int LorR = 0;
//        System.out.println("light value: " + L1.getLightValue());
//
//        while ((L1.getLightValue() > 300) && (L1.getLightValue() < 700)) {
//            while (T1.isPressed() == false && T2.isPressed() == false) {
//                cd.forward();
//
//            }
//            if (T1.isPressed() == true && T2.isPressed() == true) {
//                LorR = 3;
//            } else if (T1.isPressed() == true && T2.isPressed() == false) {
//                LorR = 1;
//            } else if (T2.isPressed() == true && T1.isPressed() == false) {
//                LorR = 2;
//            // if(LorR==3){
//            //   return;
//            //}
//            }
//            if (LorR == 1) {
//                while (!(T1.isPressed() == true && T2.isPressed() == true)) {
//                    Motor.B.rotate(1);
//                }
//
//            } else if (LorR == 2) {
//                while (!(T1.isPressed() == true && T2.isPressed() == true)) {
//                    Motor.A.rotate(1);
//                }
//            }
//
//            cd.backward();
//        }
//    }
//       if(L1.getLightValue()<1000&&L1.getLightValue()>0){
//           while(T1.isPressed()==false&&T2.isPressed()==false){
//               
//           }
//       }
    }


    
