
import icommand.navigation.Pilot;
import icommand.nxt.ColorSensor;
import icommand.nxt.LightSensor;
import icommand.nxt.Motor;
import icommand.nxt.SensorPort;
import icommand.nxt.TouchSensor;
import icommand.nxt.comm.NXTCommand;

public class RobotTesting {

    //public static int tapeColor = 450;
    //public static int centerLineColor = 450;
    public static void moveBeforeBox(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException {
        int x = 0;

        cd.setSpeed(400);

        while (x < 5) {

            System.out.println("Light value is: " + L1.getLightValue());
            System.out.println("Color value is: " + C1.getColorNumber());


            while ((T1.isPressed() == false) && T2.isPressed() == false) {
                cd.forward();

            }



            //System.out.println(C1.getRed());
            //System.out.println(L1.getLightValue());

            //if(L1.getLightValue() > 500)
            // break;
//            if(C1.getRed() > 20){
//                break;
//            }
            Thread.sleep(100);

            while ((T1.isPressed() == true) && T2.isPressed() == true) {
                cd.backward();
            }

            cd.rotate(160);

            x++;

        }

    }

    public static void testLightValue(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException {
        double x = cd.getTravelDistance();
        
        cd.setSpeed(150);
        System.out.println("-------------------------------------------------------------");
        while (cd.getTravelDistance() < x+300) {

            cd.forward();
            System.out.println("Test for the light value " + L1.getLightValue());



        }


    }

    public static void dTillLight(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException {
        while (L1.getLightValue() < 450) {

            cd.forward();
        }
        cd.stop();

    }

    public static void testColorValue(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException {
        boolean x = true;
        while (x == true) {


            if ((T1.isPressed() == true) || T2.isPressed() == true) {


                System.out.println("\nred: " + C1.getRed() + "\nblue: " + C1.getBlue() + "\ngreen: " + C1.getGreen());
                System.out.println("Color number: " + C1.getColorNumber());

            }
            if ((T1.isPressed() == true) && T2.isPressed() == true) {
                x = false;
            }
        }
    }

    public static void testColor(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException {
        while (C1.getColorNumber() == 0 || C1.getColorNumber() == 17) {
            cd.forward();
        }

        System.out.println("Color Value: " + C1.getColorNumber());

    }

    public static void testDistance(Pilot cd, TouchSensor T1, TouchSensor T2, ColorSensor C1, LightSensor L1) throws InterruptedException {
        cd.travel(457);
    }
}

    
