%Aaron Krauss - 24498998

x = linspace(-4,2,100);
y = exp(x) - cos(x) - 1;
x2 = linspace(-4,2,100);
y2 = x2;
plot(x, y, x2 ,y2)


