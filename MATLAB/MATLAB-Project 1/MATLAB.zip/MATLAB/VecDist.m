%Aaron Krauss - 24498998

function a = VecDist(x,y)
DIST = sqrt((y(1) - x(1)).^2 + (y(2) - x(2)).^2) %distance
end

